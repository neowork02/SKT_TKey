import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'dealcoGrp', // 거래처그룹
            dataType: ValueType.TEXT,
            //fieldDatetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'dealcoCl1', // 거래처구분
            dataType: ValueType.TEXT,
            //fieldDatetimeFormat: 'hhmmss',
        },
        {
            fieldName: 'orgNm4', // 조직명1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pcode', // p코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDt', // 거래정지미적용시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDtOld', // 거래정지미적용시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDt', // 거래정지미적용시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDtOld', // 거래정지미적용시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStatus', // 거래상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStaDt', // 거래시작일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndDt', // 거래종료일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 수정일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', // 처리자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm', //처리자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rowState', // Grid 변경 상태 - inserted, updated, deleted, none
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '60',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '##0',
        },
        {
            name: 'dealcoGrp',
            fieldName: 'dealcoGrp',
            type: 'data',
            editable: false,
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처그룹',
            dataType: ValueType.TEXT,
        },
        {
            name: 'dealcoCl1',
            fieldName: 'dealcoCl1',
            type: 'data',
            editable: false,
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처구분',
            dataType: ValueType.TEXT,
        },
        {
            name: 'orgNm4',
            fieldName: 'orgNm4',
            type: 'data',
            editable: false,
            width: '330',
            styles: {
                textAlignment: 'center',
            },
            header: '조직',
            dataType: ValueType.TEXT,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처코드',
            dataType: ValueType.TEXT,
            styleCallback(grid, dataCell) {
                let ret = {}

                if (
                    grid.getValue(dataCell.index.itemIndex, 'rowState') ==
                    'created'
                ) {
                    let dealcoCd1 = grid._view.columnByName('dealcoCd')
                    dealcoCd1.editable = false
                    dealcoCd1.button = 'action'
                    dealcoCd1.buttonVisibility = 'default'
                } else {
                    let dealcoCd1 = grid._view.columnByName('dealcoCd')
                    dealcoCd1.editable = false
                    dealcoCd1.button = 'none'
                    dealcoCd1.buttonVisibility = ''
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            header: '거래처명',
            dataType: ValueType.TEXT,
        },
        {
            name: 'pcode',
            fieldName: 'pcode',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '매장코드',
            dataType: ValueType.TEXT,
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래정지 미적용 시작일자',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            width: '150',
        },
        {
            name: 'aplyStaDtOld',
            fieldName: 'aplyStaDtOld',
            visible: false,
            type: 'data',
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래정지 미적용 종료일자',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            width: '150',
        },
        {
            name: 'aplyEndDtOld',
            fieldName: 'aplyEndDtOld',
            visible: false,
            type: 'data',
        },
        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '거래상태',
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래개시일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            width: '100',
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래종료일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            width: '100',
        },

        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            editable: true,
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            editable: false,
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '처리일시',
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            editable: false,
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '처리자ID',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            editable: false,
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '처리자명',
        },
    ],

    layout: [
        'rowNum',
        'orgNm4',
        'pcode',
        'dealcoCd',
        'dealcoNm',
        'dealcoGrp',
        'dealcoCl1',
        'aplyStaDt',
        'aplyEndDt',
        'dealStatus',
        'dealStaDt',
        'dealEndDt',
        'rmks',
        'modDtm',
        'modUserId',
        'modUserNm',
    ],
}

export const G_POPUP_HEADER = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'dealcoGrp', // 거래처그룹
            dataType: ValueType.TEXT,
            //fieldDatetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'dealcoCl1', // 거래처구분
            dataType: ValueType.TEXT,
            //fieldDatetimeFormat: 'hhmmss',
        },
        {
            fieldName: 'orgNm4', // 조직명1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pcode', // p코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDt', // 거래정지미적용시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDtOld', // 거래정지미적용시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDt', // 거래정지미적용시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDtOld', // 거래정지미적용시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStatus', // 거래상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStaDt', // 거래시작일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndDt', // 거래종료일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 수정일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', // 처리자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm', //처리자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rowState', // Grid 변경 상태 - inserted, updated, deleted, none
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '60',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '##0',
        },
        {
            name: 'dealcoGrp',
            fieldName: 'dealcoGrp',
            type: 'data',
            editable: false,
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처그룹',
            dataType: ValueType.TEXT,
        },
        {
            name: 'dealcoCl1',
            fieldName: 'dealcoCl1',
            type: 'data',
            editable: false,
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처구분',
            dataType: ValueType.TEXT,
        },
        {
            name: 'orgNm4',
            fieldName: 'orgNm4',
            type: 'data',
            editable: false,
            width: '330',
            header: '조직',
            dataType: ValueType.TEXT,
            styleName: 'left-column',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '* 거래처코드',
            dataType: ValueType.TEXT,
            styleCallback(grid, dataCell) {
                let ret = {}

                if (
                    grid.getValue(dataCell.index.itemIndex, 'rowState') ==
                    'created'
                ) {
                    let dealcoCd1 = grid._view.columnByName('dealcoCd')
                    dealcoCd1.editable = false
                    dealcoCd1.button = 'action'
                    dealcoCd1.buttonVisibility = 'default'
                } else {
                    let dealcoCd1 = grid._view.columnByName('dealcoCd')
                    dealcoCd1.editable = false
                    dealcoCd1.button = 'none'
                    dealcoCd1.buttonVisibility = ''
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            header: '거래처명',
            dataType: ValueType.TEXT,
            editable: false,
        },
        {
            name: 'pcode',
            fieldName: 'pcode',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '매장코드',
            dataType: ValueType.TEXT,
            editable: false,
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            styles: {
                textAlignment: 'center',
            },

            header: {
                text: '* 거래정지 미적용\n시작일자',
                styleName: 'multi-line-css',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            width: '150',
        },
        {
            name: 'aplyStaDtOld',
            fieldName: 'aplyStaDtOld',
            visible: false,
            type: 'data',
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 거래정지 미적용\n종료일자',
                styleName: 'multi-line-css',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            width: '150',
        },
        {
            name: 'aplyEndDtOld',
            fieldName: 'aplyEndDtOld',
            visible: false,
            type: 'data',
        },
        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '거래상태',
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래개시일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            width: '100',
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래종료일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            width: '100',
        },

        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            editable: true,
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            editable: false,
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '처리일시',
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            editable: false,
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '처리자ID',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            editable: false,
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '처리자명',
        },
    ],

    layout: [
        'rowNum',
        'orgNm4',
        'pcode',
        'dealcoCd',
        'dealcoNm',
        'dealcoGrp',
        'dealcoCl1',
        'aplyStaDt',
        'aplyEndDt',
        'dealStatus',
        'dealStaDt',
        'dealEndDt',
        'rmks',
        'modDtm',
        'modUserId',
        'modUserNm',
    ],
}
