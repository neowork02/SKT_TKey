import api from '@/api/biz/bas/prm/basPrmDealcoMgmt'
import types from './mutation-types'
import _ from 'lodash'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },

    async commonCodes_({ commit }, { option }) {
        let result = await api.commonCodes_({})
        let body = result
            //.filter((item) => item.type == 'I')
            .map((object, index) => ({
                ...object,
                idx: index,
                codeValue: object.commCdId.toString(),
                codeName: object.commCdNm.toString(),
            }))
        body.unshift({ codeValue: '', codeName: option })
        commit(types.DEFAULT_ASSIGN, {
            key: 'commCdIds',
            value: body,
        })
    },

    async dropDownCmmonCodes_({ state, commit }, { key, columnName, option }) {
        let result = await api.dropDownCmmonCodes_(key)
        let values = []
        let labels = []
        values = result.map((a) => a.commCdVal)
        labels = result.map((a) => a.commCdValNm)
        if (option != undefined) {
            values.unshift('')
            labels.unshift(option)
        }

        let obj1 = {}
        obj1[columnName] = {
            values: values,
            labels: labels,
        }
        commit(types.DEFAULT_ASSIGN, {
            key: 'commDropDown',
            value: { ...state.commDropDown, ...obj1 },
        })
    },
    async getBasPrmDealcoMgmtNewLst_({ state, commit }) {
        let resultData
        let searchParams = state.searchParams
        searchParams.pageSize = state.initPaging.pageSize
        searchParams.pageNum = state.paging.pageNum
        console.log(
            '🚀 ~ file: actions.js ~ line 87 ~ searchParams',
            searchParams
        )
        await api
            .getBasPrmDealcoMgmtNewLst_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ file: actions.js ~ line 97 ~ .then ~ data',
                    data
                )
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: data.pagingDto,
                    })
                    let body = data.gridList
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: body,
                    })
                } else {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: state.initPaging,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: [],
                    })
                }

                resultData = data
            })
            .catch((error) => {
                throw error
            })

        return resultData
    },

    async getBasPrmDealcoMgmtHstLst_({ state, commit }) {
        let resultData
        let searchParams = state.hstParams
        searchParams.pageSize = state.initPaging_2.pageSize
        searchParams.pageNum = state.paging_2.pageNum
        console.log(
            '🚀 ~ file: actions.js ~ line 101 ~ getBasPrmDealcoMgmtHstLst_',
            searchParams
        )
        // let searchParams = _.isEmpty(state.hstParams)
        //     ? state.searchParams
        //     : state.hstParams

        await api
            .getBasPrmDealcoMgmtHstLst_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ file: actions.js ~ line 112 ~ .then ~ data',
                    data
                )
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging_2',
                        value: data.pagingDto,
                    })
                    let body = data.gridList
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList_2',
                        value: body,
                    })
                } else {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging_2',
                        value: state.initPaging_2,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList_2',
                        value: [],
                    })
                }

                resultData = data
            })
            .catch((error) => {
                throw error
            })

        return resultData
    },

    async getBasPrmDealcoDtlNewList_({ state, commit }) {
        let detailData
        let reqParams = state.reqParams

        await api
            .getBasPrmDealcoDtlNewList_({ reqParams })
            .then((data) => {
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlList',
                        value: data.basPrmDealcoDtlListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlCmList',
                        value: data.basPrmDealcoDtlCmListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlCardList',
                        value: data.basPrmDealcoDtlCardListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlCrdList',
                        value: data.basPrmDealcoDtlCrdListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlDlvList',
                        value: data.basPrmDealcoDtlDlvListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlChrgrList',
                        value: data.basPrmDealcoDtlChrgrListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlEarvCntList',
                        value: data.basPrmDealcoDtlEarvCntListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoImagAccList',
                        value: data.basPrmDealcoImagAccListVo,
                    })
                    _.forEach(data.basPrmDealcoDtlListVo, (item) => {
                        // 거래처상세
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlCmListVo, (item) => {
                        // 사업자등록정보
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlCmListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlCardListVo, (item) => {
                        // 카드단말기
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlCardListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlCrdListVo, (item) => {
                        // 담보
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlCrdListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlDlvListVo, (item) => {
                        // 배송지
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlDlvListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlChrgrListVo, (item) => {
                        // 영업담당자
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlChrgrListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlEarvCntListVo, (item) => {
                        // 전자결재 진행여부
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlEarvCntListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoImagAccListVo, (item) => {
                        // 매장별가상계좌
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoImagAccListVo',
                            value: item,
                        })
                    })
                }
                detailData = data
            })
            .catch((error) => {
                throw error
            })

        return detailData
    },

    async getChgOrgReg_({ state, commit }) {
        let detailData
        let reqParams = state.reqParams

        await api
            .getChgOrgReg_({ reqParams })
            .then((data) => {
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'chgOrgRegDealco',
                        value: data,
                    })
                }
                detailData = data
            })
            .catch((error) => {
                throw error
            })

        return detailData
    },

    async getBasPrmDealcoDtlEtcList_({ state, commit }) {
        let detailData
        let reqParams = state.reqParams

        await api
            .getBasPrmDealcoDtlEtcList_({ reqParams })
            .then((data) => {
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlList',
                        value: data.basPrmDealcoDtlListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlCmList',
                        value: data.basPrmDealcoDtlCmListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlCardList',
                        value: data.basPrmDealcoDtlCardListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlCrdList',
                        value: data.basPrmDealcoDtlCrdListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlDlvList',
                        value: data.basPrmDealcoDtlDlvListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlChrgrList',
                        value: data.basPrmDealcoDtlChrgrListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlEarvCntList',
                        value: data.basPrmDealcoDtlEarvCntListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoImagAccList',
                        value: data.basPrmDealcoImagAccListVo,
                    })
                    _.forEach(data.basPrmDealcoDtlListVo, (item) => {
                        // 거래처상세
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlCmListVo, (item) => {
                        // 사업자등록정보
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlCmListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlCardListVo, (item) => {
                        // 카드단말기
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlCardListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlCrdListVo, (item) => {
                        // 담보
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlCrdListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlDlvListVo, (item) => {
                        // 배송지
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlDlvListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlChrgrListVo, (item) => {
                        // 영업담당자
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlChrgrListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlEarvCntListVo, (item) => {
                        // 전자결재 진행여부
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlEarvCntListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoImagAccListVo, (item) => {
                        // 매장별가상계좌
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoImagAccListVo',
                            value: item,
                        })
                    })
                }
                detailData = data
            })
            .catch((error) => {
                throw error
            })

        return detailData
    },

    // eslint-disable-next-line no-unused-vars
    async saveDealcoMgmt_({ state, commit }, { saveRows }) {
        console.log('🚀 ~ file: actions.js ~ line 128 ~ saveRows', saveRows)
        let result = 0
        await api
            .saveDealcoMgmt_(saveRows)
            .then((data) => {
                console.log(
                    '🚀 ~ file: actions.js ~ saveDealcoMgmt_~ .then ~ data',
                    data
                )
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async dealcoMgmtInsert_({ state }) {
        let result = 0
        let params = state.params
        await api
            .dealcoMgmtInsert_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async updateMgmtDealStatus_({ state }) {
        let result = 0
        let params = state.dealStatusParam
        await api
            .updateMgmtDealStatus_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async dealcoMgmtUpdate_({ state }) {
        let result = 0
        let params = state.params
        await api
            .dealcoMgmtUpdate_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async updateEffStaDtm_({ state }) {
        let result = 0
        let params = state.effStaDtmParams
        await api
            .updateEffStaDtm_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async acntInfoInsert_({ state }) {
        let result = 0
        let params = state.acntParams
        await api
            .acntInfoInsert_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async dealcoMgmtImgAccNO_({ state, commit }) {
        let result = []
        let params = state.acntAccNoParams
        await api
            .dealcoMgmtImgAccNO_({ params })
            .then((data) => {
                if (!_.isEmpty(state.basPrmDealcoImagAccList)) {
                    // 기존값이 존재한다면
                    let newData = []
                    newData = [...state.basPrmDealcoImagAccList, ...data]
                    result = newData
                } else {
                    result = data
                }

                commit(types.DEFAULT_ASSIGN, {
                    key: 'basPrmDealcoImagAccList',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async dealcoMgmtImgAccNO2_({ state, commit }) {
        let result = 0
        let params = state.acntAccNoParams
        await api
            .dealcoMgmtImgAccNO_({ params })
            .then((data) => {
                result = data

                // 기존 데이터
                let newData = []
                if (!_.isEmpty(state.basPrmDealcoImagAccList)) {
                    newData = [...state.basPrmDealcoImagAccList]
                }

                // 신규 데이터
                _.forEach(state.basPrmDealcoImagAccListNew, (item) => {
                    let obj = {}
                    // 응답 값
                    result.forEach((item2) => {
                        if (_.isEqual(item.bankCd, item2.bankCd)) {
                            obj.acntClCd = item.acntClCd
                            obj.bankCd = item.bankCd
                            obj.acntNo = item2.acntNo
                            obj.cmsCd = item.cmsCd
                            obj.depoNm = item.depoNm
                            obj.modUserId = item2.modUserId
                            obj.__rowState = item.__rowState
                            newData.push(obj)
                        }
                    })
                })

                // 기존데이터와 신규 데이터 unique 처리
                const oriUnique = newData.filter((x, i, arr) => {
                    return (
                        arr.findIndex((item) => item.bankCd === x.bankCd) === i
                    )
                })

                // 기존데이터와 업데이트 데이터 비교
                let updateData = []
                _.forEach(newData, (item) => {
                    let uptObj = {}
                    _.forEach(oriUnique, (item2) => {
                        if (
                            _.isEqual(item.bankCd, item2.bankCd) &&
                            _.isEqual(item.__rowState, 'updated')
                        ) {
                            uptObj.acntClCd = item.acntClCd
                            uptObj.bankCd = item.bankCd
                            uptObj.acntNo = item2.acntNo
                            uptObj.cmsCd = item.cmsCd
                            uptObj.depoNm = item.depoNm
                            uptObj.modUserId = item2.modUserId
                            uptObj.__rowState = item.__rowState
                            updateData.push(uptObj)
                        }
                    })
                })

                console.log('newData ->', newData)
                console.log('updateData ->', updateData)
                console.log('oriUnique ->', oriUnique)
                // 최종 데이터
                let rtnData = [...updateData, ...oriUnique]
                // 업데이트 데이터와 최종데이터 비교
                const unique = rtnData.filter((x, i, arr) => {
                    return (
                        arr.findIndex((item) => item.bankCd === x.bankCd) === i
                    )
                })

                commit(types.DEFAULT_ASSIGN, {
                    key: 'basPrmDealcoImagAccList',
                    value: unique,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async slcmDfrvDepo_({ state, commit }) {
        let result = 0
        let params = state.slcmParams
        await api
            .slcmDfrvDepo_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'slcmDfrvDepo',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async cltInfoInsert_({ state, commit }) {
        let result = 0
        let params = state.cltInfoParams
        await api
            .cltInfoInsert_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'basPrmDealcoDtlCrdList',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async cardInfoInsert_({ state }) {
        let result = 0
        let params = state.cardParams
        await api
            .cardInfoInsert_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async checkBizInfo_({ state, commit }) {
        let result = 0
        let params = state.bizParams
        await api
            .checkBizInfo_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'bizInfo',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    ////////////////////////////////////////////
    // 전자결재
    ////////////////////////////////////////////

    // 0.기타 인터페이스
    /**
     * 거래처 신규거래처 코드 조회
     * @param state
     * @param commit
     * @returns {Promise<number>}
     * @private
     */
    async getdealcoCd_({ state, commit }) {
        let result = 0
        let params = state.getdealcoCdParam
        await api
            .getdealcoCd_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'getdealcoCd',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * getMibiYn 서류미비상태체크
     * @param state
     * @param commit
     * @returns {Promise<number>}
     */
    async getMibiYn_({ state, commit }) {
        let result = 0
        let params = state.getMibiYnParam
        await api
            .getMibiYn_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'getMibiYn',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * checkDis 보유재고체크
     * @param state
     * @param commit
     * @returns {Promise<number>}
     */
    async checkDis_({ state, commit }) {
        let result = 0
        let params = state.checkDisParam
        await api
            .checkDis_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'checkDis',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * accHldChk 정산처재고보유처체크
     * @param state
     * @param commit
     * @returns {Promise<number>}
     * @private
     */
    async accHldChk_({ state, commit }) {
        let result = 0
        let params = state.accHldChkParam
        await api
            .accHldChk_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'accHldChk',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },

    // 1. 조회
    /**
     * requestCrdAdd 신규 전자결재 요청
     * @param state
     * @param commit
     * @returns {Promise<number>}
     * @private
     */
    async getRequestCrdAdd_({ state, commit }) {
        let result = 0
        let params = state.getRequestCrdAddParam
        await api
            .getRequestCrdAdd_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'getRequestCrdAdd',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * rquestCrdAdd4 담보갱신 전자결재 요청 정보
     * @param state
     * @param commit
     * @returns {Promise<number>}
     * @private
     */
    async getRequestCrdAdd4_({ state, commit }) {
        let result = 0
        let params = state.getRequestCrdAdd4Param
        await api
            .getRequestCrdAdd4_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'getRequestCrdAdd4',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * requestCrdAdd6 해지 전자결재 요청
     * @param state
     * @param commit
     * @returns {Promise<number>}
     * @private
     */
    async getRequestCrdAdd6_({ state, commit }) {
        let result = 0
        let params = state.getRequestCrdAdd6Param
        await api
            .getRequestCrdAdd6_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'getRequestCrdAdd6',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * getRequestCrdAdd3 전자결재 요청 상제조회 변경
     * @param state
     * @param commit
     * @returns {Promise<number>}
     * @private
     */
    async getRequestCrdAdd3_({ state, commit }) {
        let result = 0
        let params = state.getRequestCrdAdd3Param
        await api
            .getRequestCrdAdd3_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'getRequestCrdAdd3',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * getRequestCrdAdd5 전자결재 요청 상제조회 담보N담보갱신
     * @param state
     * @param commit
     * @returns {Promise<number>}
     * @private
     */
    async getRequestCrdAdd5_({ state, commit }) {
        let result = 0
        let params = state.getRequestCrdAdd5Param
        await api
            .getRequestCrdAdd5_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'getRequestCrdAdd5',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * getRequestCrdAdd7 전자결재 요청 상제조회 신규 재품의
     * @param state
     * @param commit
     * @returns {Promise<number>}
     * @private
     */
    async getRequestCrdAdd7_({ state, commit }) {
        let result = 0
        let params = state.getRequestCrdAdd7Param
        await api
            .getRequestCrdAdd7_({ params })
            .then((data) => {
                result = data
                commit(types.DEFAULT_ASSIGN, {
                    key: 'getRequestCrdAdd7',
                    value: result,
                })
            })
            .catch((error) => {
                throw error
            })
        return result
    },

    // 2. 저장
    /**
     * requestCrdAdd 신규 전자결재 요청
     * @param state
     * @returns {Promise<number>}
     * @private
     */
    async requestCrdAdd_({ state }) {
        let result = 0
        let params = state.requestCrdAddParam
        await api
            .requestCrdAdd_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * rquestCrdAdd4 담보갱신 전자결재 요청 정보
     * @param state
     * @returns {Promise<number>}
     * @private
     */
    async requestCrdAdd4_({ state }) {
        let result = 0
        let params = state.requestCrdAdd4Param
        await api
            .requestCrdAdd4_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * requestCrdAdd6 해지 전자결재 요청
     * @param state
     * @returns {Promise<number>}
     * @private
     */
    async requestCrdAdd6_({ state }) {
        let result = 0
        let params = state.requestCrdAdd6Param
        await api
            .requestCrdAdd6_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * requestCrdAdd3 변경 전자결재 요청
     * @param state
     * @returns {Promise<number>}
     * @private
     */
    async requestCrdAdd3_({ state }) {
        let result = 0
        let params = state.requestCrdAdd3Param
        await api
            .requestCrdAdd3_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * requestCrdAdd5  변경N담보갱신 전자결재 요청
     * @param state
     * @returns {Promise<number>}
     * @private
     */
    async requestCrdAdd5_({ state }) {
        let result = 0
        let params = state.requestCrdAdd5Param
        await api
            .requestCrdAdd5_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * requestCrdAdd7 신규 재품의 전자결재 요청
     * @param state
     * @returns {Promise<number>}
     * @private
     */
    async requestCrdAdd7_({ state }) {
        let result = 0
        let params = state.requestCrdAdd7Param
        await api
            .requestCrdAdd7_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },

    // 3. 저장후처리
    /**
     * 품의기안(신규계약)
     * @param state
     * @returns {Promise<number>}
     * @private
     */
    async addMgmtDealCoImsi_({ state }) {
        let result = 0
        let params = state.crdAddParams
        await api
            .addMgmtDealCoImsi_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * 품의기안
     * - 계약해지/변경/변경&담보갱신/신규게약_재품의
     * @param state
     * @returns {Promise<number>}
     * @private
     */
    async earvImsi3_({ state }) {
        let result = 0
        let params = state.params
        await api
            .earvImsi3_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    /**
     * 담보갱신
     * @param state
     * @returns {Promise<number>}
     * @private
     */
    async earvImsi4_({ state }) {
        let result = 0
        let params = state.params
        await api
            .earvImsi4_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },

    async getSknDlvDealcoCd_({ state }) {
        let result = 0
        let params = state.paramAgencyCd
        console.log('params', params)

        await api
            .getSknDlvDealcoCd_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async getAccOverBondStopMgmt_({ state, commit }) {
        let resultData
        let reqParams = state.reqParams
        console.log('🚀 ~ file: actions.js ~ line 1076 ~ reqParams', reqParams)
        await api
            .getAccOverBondStopMgmt_({ reqParams })
            .then((data) => {
                console.log(
                    '🚀 ~ file: actions.js ~ line 1084 ~ .then ~ data',
                    data
                )

                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'accOverBondList',
                        value: data,
                    })
                }

                resultData = data
            })
            .catch((error) => {
                throw error
            })

        return resultData
    },
}
