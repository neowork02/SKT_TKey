import { ValueType } from 'realgrid'

export const basBcoEndChkDealcoHeader = {
    fields: [
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
            },
        },
    ],
}
