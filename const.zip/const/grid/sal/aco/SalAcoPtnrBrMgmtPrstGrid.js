/**
 * 판매 - 일정산 > 도매일정산 > 판매점관리현황 조회 : SALCO01900
 * P179352
 */
import { ValueType } from 'realgrid'

// // 1. 기본정보
// export const SALEBASICGRIDHEADER = {
//     fields: [
//         {
//             fieldName: 'bizChrgOrgCd',
//             dataType: ValueType.TEXT, // 사업담당코드
//         },
//     ],
//     columns: [
//         {
//             name: 'opCl',
//             fieldName: 'opCl',
//             type: 'data',
//             width: '300',
//             header: {
//                 text: '구분',
//                 showTooltip: false,
//             },
//             mergeRule: {
//                 criteria: 'value',
//             },
//             footer: {
//                 text: '합계',
//             },
//         },
//     ],
// }

// 2. 판매마감처리현황
export const SALEADMINGRIDHEADER = {
    fields: [
        {
            fieldName: 'lvOrgCd1',
            dataType: ValueType.TEXT, //레벨1조직코드
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT, //레벨2조직코드
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, //조직코드
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //거래처명
        },
        {
            fieldName: 'dealcoCd1',
            dataType: ValueType.TEXT, //거래처구분코드1
        },
        {
            fieldName: 'opCl',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'opClDtl',
            dataType: ValueType.TEXT, //항목
        },
        {
            fieldName: 'sktAgencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT, //서브점코드
        },
        {
            fieldName: 'dayTotCnt',
            dataType: ValueType.NUMBER, //당일-전송
        },
        {
            fieldName: 'dayOpCnt',
            dataType: ValueType.NUMBER, //당일-처리
        },
        {
            fieldName: 'dayYetCnt',
            dataType: ValueType.NUMBER, //당일-미처리
        },
        {
            fieldName: 'dayExcCnt',
            dataType: ValueType.NUMBER, //당일-제외
        },
        {
            fieldName: 'mthTotCnt',
            dataType: ValueType.NUMBER, //당월-전송
        },
        {
            fieldName: 'mthOpCnt',
            dataType: ValueType.NUMBER, //당월-처리
        },
        {
            fieldName: 'mthYetCnt',
            dataType: ValueType.NUMBER, //당월-미처리
        },
        {
            fieldName: 'mthExcCnt',
            dataType: ValueType.NUMBER, //당월-제외
        },
    ],
    columns: [
        {
            name: 'lvOrgCd1',
            fieldName: 'lvOrgCd1',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '레벨1조직코드',
            },
        },
        {
            name: 'lvOrgCd2',
            fieldName: 'lvOrgCd2',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '레벨2조직코드',
            },
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '조직코드',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '거래처명',
            },
        },
        {
            name: 'dealcoCd1',
            fieldName: 'dealcoCd1',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '거래처구분코드1',
            },
        },
        {
            name: 'opCl',
            fieldName: 'opCl',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '구분',
            },
            mergeRule: {
                criteria: 'value',
            },
            footer: {
                text: '합계',
            },
        },
        {
            name: 'opClDtl',
            fieldName: 'opClDtl',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '항목',
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '대리점코드',
            },
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '서브점코드',
            },
        },
        {
            name: 'dayTotCnt',
            fieldName: 'dayTotCnt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '전송',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayOpCnt',
            fieldName: 'dayOpCnt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '처리',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayYetCnt',
            fieldName: 'dayYetCnt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '미처리',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayExcCnt',
            fieldName: 'dayExcCnt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '제외',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthTotCnt',
            fieldName: 'mthTotCnt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '전송',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthOpCnt',
            fieldName: 'mthOpCnt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '처리',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthYetCnt',
            fieldName: 'mthYetCnt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '미처리',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthExcCnt',
            fieldName: 'mthExcCnt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '제외',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
    ],
}
// 3. 재고마감처리현황
export const SALESTOCKADMINGRIDHEADER = {
    fields: [
        {
            fieldName: 'lvOrgCd1',
            dataType: ValueType.TEXT, //레벨1조직코드
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT, //레벨2조직코드
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, //조직코드
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //거래처명
        },
        {
            fieldName: 'dealcoCd1',
            dataType: ValueType.TEXT, //거래처구분코드1
        },
        {
            fieldName: 'opCl',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'opClDtl',
            dataType: ValueType.TEXT, //항목
        },
        {
            fieldName: 'sktAgencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT, //서브점코드
        },
        {
            fieldName: 'dayTotCnt',
            dataType: ValueType.TEXT, //당일-전송
        },
        {
            fieldName: 'dayOpCnt',
            dataType: ValueType.TEXT, //당일-처리
        },
        {
            fieldName: 'dayYetCnt',
            dataType: ValueType.TEXT, //당일-미처리
        },
        {
            fieldName: 'mthTotCnt',
            dataType: ValueType.TEXT, //당월-전송
        },
        {
            fieldName: 'mthOpCnt',
            dataType: ValueType.TEXT, //당월-처리
        },
        {
            fieldName: 'mthYetCnt',
            dataType: ValueType.TEXT, //당월-미처리
        },
    ],
    columns: [
        {
            name: 'lvOrgCd1',
            fieldName: 'lvOrgCd1',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '레벨1조직코드',
            },
        },
        {
            name: 'lvOrgCd2',
            fieldName: 'lvOrgCd2',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '레벨2조직코드',
            },
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '조직코드',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '거래처명',
            },
        },
        {
            name: 'dealcoCd1',
            fieldName: 'dealcoCd1',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '거래처구분코드1',
            },
        },
        {
            name: 'opCl',
            fieldName: 'opCl',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '구분',
            },
            mergeRule: {
                criteria: 'value',
            },
            footer: {
                text: '합계',
            },
        },
        {
            name: 'opClDtl',
            fieldName: 'opClDtl',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '항목',
            },
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '대리점코드',
            },
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '서브점코드',
            },
        },
        {
            name: 'dayTotCnt',
            fieldName: 'dayTotCnt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '예정',
            },
        },
        {
            name: 'dayOpCnt',
            fieldName: 'dayOpCnt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '확정',
            },
        },
        {
            name: 'dayYetCnt',
            fieldName: 'dayYetCnt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '미확정',
            },
        },
        {
            name: 'mthTotCnt',
            fieldName: 'mthTotCnt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '예정',
            },
        },
        {
            name: 'mthOpCnt',
            fieldName: 'mthOpCnt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '확정',
            },
        },
        {
            name: 'mthYetCnt',
            fieldName: 'mthYetCnt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '미확정',
            },
        },
    ],
}
// 4. 채권현황
export const SALEDECRAMTGRIDHEADER = {
    fields: [
        {
            fieldName: 'clsDt',
            dataType: ValueType.TEXT, //마감일자
        },
        {
            fieldName: 'lvOrgCd1',
            dataType: ValueType.TEXT, //레벨1조직코드
        },
        {
            fieldName: 'orgNm1',
            dataType: ValueType.TEXT, //사업담당
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT, //레벨2조직코드
        },
        {
            fieldName: 'orgNm2',
            dataType: ValueType.TEXT, //영업팀
        },
        {
            fieldName: 'lvOrgCd3',
            dataType: ValueType.TEXT, //레벨3조직코드
        },
        {
            fieldName: 'orgNm3',
            dataType: ValueType.TEXT, //영업파트
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, //매장코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //매장명
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT, //거래처구분코드1
        },
        {
            fieldName: 'dealCoCl',
            dataType: ValueType.TEXT, //매장유형
        },
        {
            fieldName: 'dealEndDt',
            dataType: ValueType.TEXT, //거래종료일
        },
        {
            fieldName: 'bfBondAmt',
            dataType: ValueType.TEXT, //전일채권잔액
        },
        {
            fieldName: 'tdayFeesAmt',
            dataType: ValueType.TEXT, //당일채권증가_SKT수납
        },
        {
            fieldName: 'tdayCashAmt',
            dataType: ValueType.TEXT, //당일채권증가_현금매출
        },
        {
            fieldName: 'toEtcmAmt',
            dataType: ValueType.TEXT, //당일채권증가_기타수납
        },
        {
            fieldName: 'tdayTecoAmt',
            dataType: ValueType.TEXT, //당일채권증가_T에코오감정환수
        },
        {
            fieldName: 'tdayDpstAmt',
            dataType: ValueType.TEXT, //본사송금
        },
        {
            fieldName: 'tdayRfndAmt',
            dataType: ValueType.TEXT, //오입금환불
        },
        {
            fieldName: 'tdayPpayAmt',
            dataType: ValueType.TEXT, //선급금
        },
        {
            fieldName: 'tdayRcvbAmt',
            dataType: ValueType.TEXT, //기타미수금
        },
        {
            fieldName: 'tdayPayblAmt',
            dataType: ValueType.TEXT, //미지급금_발생
        },
        {
            fieldName: 'toExpsAmt',
            dataType: ValueType.TEXT, //미지급금_지출
        },
        {
            fieldName: 'tdayBondBamt',
            dataType: ValueType.TEXT, //당일채권잔액
        },
    ],
    columns: [
        {
            name: 'clsDt',
            fieldName: 'clsDt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '마감일자',
            },
        },
        {
            name: 'lvOrgCd1',
            fieldName: 'lvOrgCd1',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '레벨1조직코드',
            },
        },
        {
            name: 'orgNm1',
            fieldName: 'orgNm1',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '사업담당',
            },
        },
        {
            name: 'lvOrgCd2',
            fieldName: 'lvOrgCd2',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '레벨2조직코드',
            },
        },
        {
            name: 'orgNm2',
            fieldName: 'orgNm2',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '영업팀',
            },
        },
        {
            name: 'lvOrgCd3',
            fieldName: 'lvOrgCd3',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '레벨3조직코드',
            },
        },
        {
            name: 'orgNm3',
            fieldName: 'orgNm3',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '영업파트',
            },
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '매장코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '매장명',
            },
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '거래처구분코드1',
            },
        },
        {
            name: 'dealCoCl',
            fieldName: 'dealCoCl',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '매장유형',
            },
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '거래종료일',
            },
        },
        {
            name: 'bfBondAmt',
            fieldName: 'bfBondAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '전일채권잔액',
            },
        },
        {
            name: 'tdayFeesAmt',
            fieldName: 'tdayFeesAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: 'SKT수납', // 당일채권증가_SKT수납
            },
        },
        {
            name: 'tdayCashAmt',
            fieldName: 'tdayCashAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '현금매출', // 당일채권증가_현금매출
            },
        },
        {
            name: 'toEtcmAmt',
            fieldName: 'toEtcmAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '기타수납', // 당일채권증가_기타수납
            },
        },
        {
            name: 'tdayTecoAmt',
            fieldName: 'tdayTecoAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: 'T에코오감정환수', // 당일채권증가_T에코오감정환수
            },
        },
        {
            name: 'tdayDpstAmt',
            fieldName: 'tdayDpstAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '본사송금',
            },
        },
        {
            name: 'tdayRfndAmt',
            fieldName: 'tdayRfndAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '오입금환불',
            },
        },
        {
            name: 'tdayPpayAmt',
            fieldName: 'tdayPpayAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '선급금',
            },
        },
        {
            name: 'tdayRcvbAmt',
            fieldName: 'tdayRcvbAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '기타미수금',
            },
        },
        {
            name: 'tdayPayblAmt',
            fieldName: 'tdayPayblAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '발생', // 미지급금_발생
            },
        },
        {
            name: 'toExpsAmt',
            fieldName: 'toExpsAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '지출', // 미지급금_지출
            },
        },
        {
            name: 'tdayBondBamt',
            fieldName: 'tdayBondBamt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당일채권잔액',
            },
        },
    ],
}

// 5. 실적현황
export const SALERECORDGRIDHEADER = {
    fields: [
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'saleRsltItm',
            dataType: ValueType.TEXT, //항목
        },
        {
            fieldName: 'saleRsltItmDtl',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'trgtQty',
            dataType: ValueType.TEXT, //목표실적
        },
        {
            fieldName: 'daySaleQty',
            dataType: ValueType.TEXT, //일실적
        },
        {
            fieldName: 'mthSaleQty',
            dataType: ValueType.TEXT, //당월실적
        },
        {
            fieldName: 'trgtAchvRt',
            dataType: ValueType.TEXT, //달성율
        },
        {
            fieldName: 'trgtGapQty',
            dataType: ValueType.TEXT, //목표GAP
        },
        {
            fieldName: 'asmptSaleQty',
            dataType: ValueType.TEXT, //예상마감
        },
        {
            fieldName: 'asmptAchvRt',
            dataType: ValueType.TEXT, //예상달성율
        },
        {
            fieldName: 'bizChrgRank',
            dataType: ValueType.TEXT, //사업담당순위
        },
        {
            fieldName: 'hqRank',
            dataType: ValueType.TEXT, //전사순위
        },
    ],
    columns: [
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'saleRsltItm',
            fieldName: 'saleRsltItm',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '항목',
            },
        },
        {
            name: 'saleRsltItmDtl',
            fieldName: 'saleRsltItmDtl',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '구분',
            },
        },
        {
            name: 'trgtQty',
            fieldName: 'trgtQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '목표실적',
            },
        },
        {
            name: 'daySaleQty',
            fieldName: 'daySaleQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '일실적',
            },
        },
        {
            name: 'mthSaleQty',
            fieldName: 'mthSaleQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당월실적',
            },
        },
        {
            name: 'trgtAchvRt',
            fieldName: 'trgtAchvRt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '달성율',
            },
        },
        {
            name: 'trgtGapQty',
            fieldName: 'trgtGapQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '목표GAP',
            },
        },
        {
            name: 'asmptSaleQty',
            fieldName: 'asmptSaleQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '예상마감',
            },
        },
        {
            name: 'asmptAchvRt',
            fieldName: 'asmptAchvRt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '예상달성율',
            },
        },
        {
            name: 'bizChrgRank',
            fieldName: 'bizChrgRank',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '사업담당순위',
            },
        },
        {
            name: 'hqRank',
            fieldName: 'hqRank',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '전사순위',
            },
        },
    ],
}

// 6. 재고현황
export const SALEINVENGRIDHEADER = {
    fields: [
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //항목
        },
        {
            fieldName: 'disClNm',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'disQty',
            dataType: ValueType.TEXT, //보유현황_현재고
        },
        {
            fieldName: 'disAmt',
            dataType: ValueType.TEXT, //보유현황_평가금액
        },
        {
            fieldName: 'dayDisInQty',
            dataType: ValueType.TEXT, //당일_입고
        },
        {
            fieldName: 'dayDisOutQty',
            dataType: ValueType.TEXT, //당일_출고
        },
        {
            fieldName: 'daySaleQty',
            dataType: ValueType.TEXT, //당일_판매
        },
        {
            fieldName: 'dayBadQty',
            dataType: ValueType.TEXT, //당일_불량
        },
        {
            fieldName: 'dayRiskQty',
            dataType: ValueType.TEXT, //당일_사고
        },
        {
            fieldName: 'dayInNonFixQty',
            dataType: ValueType.TEXT, //당일_입고미확정
        },
        {
            fieldName: 'bfMthQty',
            dataType: ValueType.TEXT, //당월_이월
        },
        {
            fieldName: 'mthDisInQty',
            dataType: ValueType.TEXT, //당월_입고
        },
        {
            fieldName: 'mthDisOutQty',
            dataType: ValueType.TEXT, //당월_출고
        },
        {
            fieldName: 'mthSaleQty',
            dataType: ValueType.TEXT, //당월_판매
        },
        {
            fieldName: 'mthBadQty',
            dataType: ValueType.TEXT, //당월_불량
        },
        {
            fieldName: 'mthRiskQty',
            dataType: ValueType.TEXT, //당월_사고
        },
        {
            fieldName: 'mthInNonFixQty',
            dataType: ValueType.TEXT, //당월_입고미확정
        },
        {
            fieldName: 'disRt',
            dataType: ValueType.TEXT, //재고보유율
        },
    ],
    columns: [
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '항목',
            },
        },
        {
            name: 'disClNm',
            fieldName: 'disClNm',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '구분',
            },
        },
        {
            name: 'disQty',
            fieldName: 'disQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '보유현황_현재고',
            },
        },
        {
            name: 'disAmt',
            fieldName: 'disAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '보유현황_평가금액',
            },
        },
        {
            name: 'dayDisInQty',
            fieldName: 'dayDisInQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당일_입고',
            },
        },
        {
            name: 'dayDisOutQty',
            fieldName: 'dayDisOutQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당일_출고',
            },
        },
        {
            name: 'daySaleQty',
            fieldName: 'daySaleQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당일_판매',
            },
        },
        {
            name: 'dayBadQty',
            fieldName: 'dayBadQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당일_불량',
            },
        },
        {
            name: 'dayRiskQty',
            fieldName: 'dayRiskQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당일_사고',
            },
        },
        {
            name: 'dayInNonFixQty',
            fieldName: 'dayInNonFixQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당일_입고미확정',
            },
        },
        {
            name: 'bfMthQty',
            fieldName: 'bfMthQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당월_이월',
            },
        },
        {
            name: 'mthDisInQty',
            fieldName: 'mthDisInQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당월_입고',
            },
        },
        {
            name: 'mthDisOutQty',
            fieldName: 'mthDisOutQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당월_출고',
            },
        },
        {
            name: 'mthSaleQty',
            fieldName: 'mthSaleQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당월_판매',
            },
        },
        {
            name: 'mthBadQty',
            fieldName: 'mthBadQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당월_불량',
            },
        },
        {
            name: 'mthRiskQty',
            fieldName: 'mthRiskQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당월_사고',
            },
        },
        {
            name: 'mthInNonFixQty',
            fieldName: 'mthInNonFixQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당월_입고미확정',
            },
        },
        {
            name: 'disRt',
            fieldName: 'disRt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '재고보유율',
            },
        },
    ],
}
// 7. 손익현황
export const SALEPROFITANDLOSSGRIDHEADER = {
    fields: [
        {
            fieldName: 'ordTyp',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'ordCl',
            dataType: ValueType.TEXT, //항목
        },
        {
            fieldName: 'ordClDtl',
            dataType: ValueType.TEXT, //상세
        },
        {
            fieldName: 'dayRslt',
            dataType: ValueType.TEXT, //당일실적
        },
        {
            fieldName: 'mthRslt',
            dataType: ValueType.TEXT, //당월실적
        },
    ],
    columns: [
        {
            name: 'ordTyp',
            fieldName: 'ordTyp',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '구분',
            },
        },
        {
            name: 'ordCl',
            fieldName: 'ordCl',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '항목',
            },
        },
        {
            name: 'ordClDtl',
            fieldName: 'ordClDtl',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '상세',
            },
        },
        {
            name: 'dayRslt',
            fieldName: 'dayRslt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당일실적',
            },
        },
        {
            name: 'mthRslt',
            fieldName: 'mthRslt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '당월실적',
            },
        },
    ],
}
// 8. 세금계산서
export const SALETAXINVOICEGRIDHEADER = {
    fields: [
        {
            fieldName: 'gubun',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'dayRowCnt',
            dataType: ValueType.TEXT, //당일_발행건수
        },
        {
            fieldName: 'daySplyPrc',
            dataType: ValueType.TEXT, //당일_발행공급가
        },
        {
            fieldName: 'dayVatAmt',
            dataType: ValueType.TEXT, //당일_발행세액
        },
        {
            fieldName: 'daySumAmt',
            dataType: ValueType.TEXT, //당일_발행합계
        },
        {
            fieldName: 'mthRowCnt',
            dataType: ValueType.TEXT, //당월_발행건수
        },
        {
            fieldName: 'mthSplyPrc',
            dataType: ValueType.TEXT, //당월_발행공급가
        },
        {
            fieldName: 'mthVatAmt',
            dataType: ValueType.TEXT, //당월_발행세액
        },
        {
            fieldName: 'mthSumAmt',
            dataType: ValueType.TEXT, //당월_발행합계
        },
    ],
    columns: [
        {
            name: 'gubun',
            fieldName: 'gubun',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '구분',
            },
        },
        {
            name: 'dayRowCnt',
            fieldName: 'dayRowCnt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '발행건수', // 당일_발행건수
            },
        },
        {
            name: 'daySplyPrc',
            fieldName: 'daySplyPrc',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '발행공급가', // 당일_발행공급가
            },
        },
        {
            name: 'dayVatAmt',
            fieldName: 'dayVatAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '발행세액', // 당일_발행세액
            },
        },
        {
            name: 'daySumAmt',
            fieldName: 'daySumAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '발행합계', // 당일_발행합계
            },
        },
        {
            name: 'mthRowCnt',
            fieldName: 'mthRowCnt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '발행건수', // 당월_발행건수
            },
        },
        {
            name: 'mthSplyPrc',
            fieldName: 'mthSplyPrc',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '발행공급가', // 당월_발행공급가
            },
        },
        {
            name: 'mthVatAmt',
            fieldName: 'mthVatAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '발행세액', // 당월_발행세액
            },
        },
        {
            name: 'mthSumAmt',
            fieldName: 'mthSumAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '발행합계', // 당월_발행합계
            },
        },
    ],
}
// 9. 직영점재고현황
export const SALEPSPPGRIDHEADER = {
    fields: [
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'totInvQty',
            dataType: ValueType.TEXT, //상품내역_합계
        },
        {
            fieldName: 'eqpInvQty',
            dataType: ValueType.TEXT, //상품내역_단말기
        },
        {
            fieldName: 'etcInvQty',
            dataType: ValueType.TEXT, //상품내역_일반상품
        },
        {
            fieldName: 'usimInvQty',
            dataType: ValueType.TEXT, //상품내역_USIM
        },
        {
            fieldName: 'totInvAmt',
            dataType: ValueType.TEXT, //금액_합계
        },
        {
            fieldName: 'eqpInvAmt',
            dataType: ValueType.TEXT, //금액_단말기
        },
        {
            fieldName: 'etcInvAmt',
            dataType: ValueType.TEXT, //금액_일반상품
        },
        {
            fieldName: 'usimInvAmt',
            dataType: ValueType.TEXT, //금액_USIM
        },
    ],
    columns: [
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'totInvQty',
            fieldName: 'totInvQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '합계', // 상품내역_합계
            },
        },
        {
            name: 'eqpInvQty',
            fieldName: 'eqpInvQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '단말기', // 상품내역_단말기
            },
        },
        {
            name: 'etcInvQty',
            fieldName: 'etcInvQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '일반상품', // 상품내역_일반상품
            },
        },
        {
            name: 'usimInvQty',
            fieldName: 'usimInvQty',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: 'USIM', // 상품내역_USIM
            },
        },
        {
            name: 'totInvAmt',
            fieldName: 'totInvAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '합계', // 금액_합계
            },
        },
        {
            name: 'eqpInvAmt',
            fieldName: 'eqpInvAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '단말기', // 금액_단말기
            },
        },
        {
            name: 'etcInvAmt',
            fieldName: 'etcInvAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '일반상품', // 금액_일반상품
            },
        },
        {
            name: 'usimInvAmt',
            fieldName: 'usimInvAmt',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: 'USIM', // 금액_USIM
            },
        },
    ],
}
