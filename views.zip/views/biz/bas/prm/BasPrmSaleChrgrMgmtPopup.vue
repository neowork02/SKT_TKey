<template>
    <TCComDialog :dialogShow.sync="activeOpenColor" size="700px">
        <template #content>
            <TCComAlert
                v-model="showSelectedRowBool"
                headerText="Row 선택 필수"
                :bodyText="alertBodyText"
            ></TCComAlert>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">사용자팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="contBoth">
                        <!-- SubTit -->
                        <div class="stitHead pop">
                            <h4 class="subTit">전체색상목록</h4>
                        </div>
                        <!-- // SubTit -->

                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="colorGrid"
                                ref="colorGrid"
                                :fields="view2.fields"
                                :columns="view2.columns"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom" v-if="!multiple">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirmCallback"
                        >
                            확인(콜백)
                        </TCComButton>
                    </div>
                    <div class="btn_area_bottom" v-if="multiple">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirmMult"
                        >
                            확인
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { GRID_COLOR_HEADER } from '@/const/grid/sample/sampleGrid'
import _ from 'lodash'

export default {
    name: 'BasUsmSaleChrgrMgmtPopup',
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        multiple: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            gridObj: {},
            objAuth: {},
            view2: GRID_COLOR_HEADER,
            selectedData: {},
            showSelectedRowBool: false,
            alertBodyText: '',
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpenColor: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    created() {},
    mounted() {
        this.gridObj = this.$refs.colorGrid // Grid Object 설정
        this.initGrid()
        this.initGridRows()
    },
    methods: {
        //GridSetData
        gridSetData() {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(-1, -1, 10, 0, '')
        },
        initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, this.multiple)
            // 그리드 이벤트 처리
            this.gridObj.gridView.onCurrentRowChanged = (
                grid,
                oldRow,
                newRow
            ) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(newRow)
                this.selectedData = jsonData
            }

            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        initGridRows() {
            const rows = [
                { colorCode: '01', colorNm: '파랑' },
                { colorCode: '02', colorNm: '빨간' },
                { colorCode: '03', colorNm: '초록' },
                { colorCode: '04', colorNm: '분홍' },
                { colorCode: '05', colorNm: '검정' },
                { colorCode: '06', colorNm: '민트' },
                { colorCode: '07', colorNm: '연파랑' },
            ]
            setTimeout(() => {
                this.gridObj.setRows(rows)
            }, 400)
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showSelectedRowBool = true
                this.alertBodyText = 'Row를 선택해주세요.'
                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onConfirmCallback() {
            if (_.isEmpty(this.selectedData)) {
                this.showSelectedRowBool = true
                this.alertBodyText = 'Row를 선택해주세요.'
                return
            }
            this.$emit('confirm', this.selectedData)
            this.onClose()
        },

        onConfirmMult() {
            const checkedRows = this.gridObj.gridView.getCheckedRows()
            if (_.isEmpty(checkedRows)) {
                this.showSelectedRowBool = true
                this.alertBodyText = 'Row를 선택해주세요.'
                return
            }
            let jsonData = []
            checkedRows.forEach((dataRow) => {
                jsonData = [
                    ...jsonData,
                    this.gridObj.dataProvider.getJsonRow(dataRow),
                ]
            })
            console.log('jsonData : ', jsonData)
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpenColor = false
        },
    },
}
</script>
