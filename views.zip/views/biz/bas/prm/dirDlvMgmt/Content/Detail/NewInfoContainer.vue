<template>
    <div>
        <!-- 신규정보 -->
        <!-- Search_div_Type4 -->
        <div class="searchLayer_wrap type04 mt20">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div3">
                    <TCComCheckBox
                        labelName=""
                        v-model="newInfo.earvType"
                        :itemList="this.docList"
                        :disabled="this.isDisabledDataEarvYn1"
                        cols="6"
                        @change="changeDoc"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div3">
                    <!-- arrayType_notit -->
                    <div class="arrayType notit">
                        <div class="colinput">
                            <TCComComboBox
                                v-model="newInfo.eravStCd"
                                :addBlankItem="true"
                                blankItemText="전송유형 선택"
                                blankItemValue=""
                                :itemList="this.eravStcdList"
                                :disabled="this.isDisabledDataEarvYn1"
                                @change="changeEravStCd"
                            />
                        </div>
                        <div class="colbtn">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_xs btn_ty05"
                                labelName="품의기안"
                                :disabled="this.isDisabledDataEarvYn1"
                                @click="earvSnd"
                            />
                            <!-- :disabled="true"-->
                        </div>
                    </div>
                    <!-- //arrayType_notit -->
                </div>
                <!-- //item 1-2 -->
            </div>
            <!-- //Search_line 1 -->
        </div>
        <!-- //Search_div_Type4 -->
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dirDlvMgmt/helpers'
import _ from 'lodash'
import CommonMixin from '@/mixins'
export default {
    name: 'NewInfoContainer',
    components: {},
    mixins: [CommonMixin],
    props: {},
    data() {
        return {
            newInfo: {
                earvType: [],
                eravStCd: '',
            },
            storeKey: 'newInfoData',
            docList: [
                {
                    commCdVal: '10',
                    commCdValNm: '신규 서류첨부',
                },
                {
                    commCdVal: '20',
                    commCdValNm: '변경 서류첨부',
                },
            ],
            eravStcdList: [
                {
                    commCdVal: '',
                    commCdValNm: '전송유형 선택',
                },
                {
                    commCdVal: '1',
                    commCdValNm: '신규계약',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '담보갱신',
                },
                {
                    commCdVal: '3',
                    commCdValNm: '계약해지',
                },
                {
                    commCdVal: '4',
                    commCdValNm: '변경',
                },
                {
                    commCdVal: '5',
                    commCdValNm: '변경&담보갱신',
                },
                {
                    commCdVal: '6',
                    commCdValNm: '신규계약_재품의',
                },
            ],
        }
    },
    computed: {
        ...serviceComputed,
        isDealStatusYn: {
            get() {
                return this.isDealStatus
            },
        },
        isDisabledDataEarvYn1: {
            get() {
                return this.isDisabledDataEarvYn
            },
        },
        earvSt: {
            get() {
                return this.earvStType
            },
        },
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        basPrmDealcoDtlCmVo: {
            get() {
                return this.basPrmDealcoDtlCmListVo // 사업자등록정보
            },
        },
        basPrmDealcoDtlCardVo: {
            get() {
                return this.basPrmDealcoDtlCardListVo // 카드단말기
            },
        },
        basPrmDealcoDtlCrdVo: {
            get() {
                return this.basPrmDealcoDtlCrdListVo // 담보
            },
        },
        basPrmDealcoDtlDlvVo: {
            get() {
                return this.basPrmDealcoDtlDlvListVo // 배송지
            },
        },
        basPrmDealcoDtlChrgrVo: {
            get() {
                return this.basPrmDealcoDtlChrgrListVo // 영업담당자
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
    },
    created() {},
    mounted() {
        this.initData()
    },
    methods: {
        ...serviceMethods,
        initData() {
            this.newInfo = {
                earvType: [],
                eravStCd: '',
            }
        },
        setData() {
            let params = { ...this.newInfo }
            this.storeSet(this.storeKey, params)
        },

        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        earvSnd() {
            if (
                _.isEmpty(this.searchParam.eravStCd) // 전송유형
            ) {
                this.showTcComAlert('전송유형을 선택하세요')
            } else {
                if (
                    _.isEmpty(this.searchParam.dealcoCd) && // 거래처그룹
                    !_.isEqual(this.searchParam.eravStCd, '1') // 전송유형 1 : 신규계약
                ) {
                    // this.newAgrmt()
                    this.showTcComAlert('품의기안(신규계약) 대상입니다.')
                } else if (
                    _.isEmpty(this.searchParam.dealcoCd) && // 거래처그룹
                    _.isEqual(this.earvSt, '2') && // 사업자정보 2: 신규
                    _.isEqual(this.searchParam.eravStCd, '1') // 전송유형 1 : 신규계약
                ) {
                    // 담보갱신_전자결재_전송
                    // TODO 내용수정 진행중
                    this.cltEarvTrms('신규계약') // BASPRM02640.xml
                } else if (
                    _.isEqual(this.earvSt, '3') && // 사업자정보 3 : 변경
                    !_.isEqual(this.searchParam.eravStCd, '4') // 전송유형 4 : 변경이 아닐 경우
                ) {
                    //변경 3
                    // 변경_제외
                    //this.chgExl()
                    this.showTcComAlert('품의기안(변경) 대상입니다.')
                } else if (
                    _.isEqual(this.earvSt, '3') && // 사업자정보 3 : 변경
                    _.isEqual(this.searchParam.eravStCd, '4') // 전송유형 4 : 변경
                ) {
                    // TODO 내용수정
                    // 변경
                    this.chg('품의기안(변경)') // BASPRM02641.xml
                } else if (
                    _.isEqual(this.earvSt, '4') && // 사업자정보 4 : 담보갱신
                    !_.isEqual(this.searchParam.eravStCd, '2') // 전송유형 2 : 담보갱신이 아닐 경우
                ) {
                    //담보갱신:2
                    // 변경_신규_제외
                    //this.chgNewExl()
                    this.showTcComAlert('품의기안(담보갱신) 대상입니다.')
                } else if (
                    _.isEqual(this.earvSt, '4') && // 사업자정보 4 : 담보갱신
                    _.isEqual(this.searchParam.eravStCd, '2') // 전송유형 2 : 담보갱신
                ) {
                    // TODO 내용수정
                    // 변경_신규
                    this.chgNew('품의기안(담보갱신)') // BASPRM02643.xml
                } else if (
                    this.isDealStatusYn && // 거래종료
                    !_.isEqual(this.searchParam.eravStCd, '3') // 전송유형 3 : 계약해지이 아닌 경우
                ) {
                    //계약해지:3
                    // 거래_종료_변경_제외
                    // this.dealEndChgExl()
                    this.showTcComAlert('품의기안(계약해지) 대상입니다.')
                } else if (
                    this.isDealStatusYn && // 거래종료
                    _.isEqual(this.earvSt, '6') && // 사업자정보 6 : 해지
                    _.isEqual(this.searchParam.eravStCd, '3') // 전송유형 3 : 계약해지
                ) {
                    // TODO 내용수정
                    // 거래_종료_변경
                    this.dealEndChg('품의기안(계약해지)') // BASPRM02644.xml
                } else if (
                    _.isEqual(this.earvSt, '5') && // 사업자정보 5 : 변경&담보갱신
                    !_.isEqual(this.searchParam.eravStCd, '5') // 전송유형 5 : 변경&담보갱신이 아닌 경우
                ) {
                    // 변경_담보_제외
                    // this.chgCltExl()
                    this.showTcComAlert('품의기안(변경&담보갱신) 대상입니다.')
                } else if (
                    _.isEqual(this.earvSt, '5') && // 사업자정보 5 : 변경&담보갱신
                    _.isEqual(this.searchParam.eravStCd, '5') // 전송유형 5 : 변경&담보갱신
                ) {
                    // TODO 내용수정
                    // 변경_담보
                    this.chgClt('품의기안(변경&담보갱신)') // BASPRM02642.xml
                } else if (
                    _.isEqual(this.earvSt, '7') && // 사업자정보 7 : 품의기안(신규_재품의)
                    !_.isEqual(this.searchParam.eravStCd, '6') // 전송유형 6 :신규계약_재품의이 아닌 경우
                ) {
                    //재품의
                    // 신규_재품의_제외
                    // this.newReEarvExt()
                    this.showTcComAlert('품의기안(신규계약_재품의) 대상입니다.')
                } else if (
                    _.isEqual(this.earvSt, '7') && // 사업자정보 7 : 품의기안(신규_재품의)
                    _.isEqual(this.searchParam.eravStCd, '6') // 전송유형 6 :신규계약_재품의
                ) {
                    // TODO 내용수정
                    // 신규_재품의
                    this.newReEarv('품의기안(신규계약_재품의)') // BASPRM02646.xml
                } else {
                    this.showTcComAlert('전자결재 전송 대상이 아닙니다.')
                }
            }
        },
        changeDoc(docType) {
            if (docType.length > 1) {
                this.showTcComAlert('동시 체크를 할 수 없습니다.')
                this.newInfo.earvType = []
            } else {
                _.forEach(docType, (data) => {
                    if (_.isEqual(data, '20')) {
                        this.newInfo.earvType = []
                        this.showTcComAlert(
                            '변경 데이터가 있을때 사용 할 수 없습니다.'
                        )
                    }
                })
            }
            let param = { ...this.newInfo }
            this.storeSet(this.storeKey, param)
        },
        changeEravStCd(code) {
            this.newInfo.eravStCd = code
            let param = { ...this.newInfo }
            this.storeSet(this.storeKey, param)
        },
        /**
         * 신규계약
         * _.isEmpty(this.searchParam.dealcoCd) &&
         * !_.isEqual(this.searchParam.eravStCd, '1')
         */
        newAgrmt() {},
        /**
         * 담보갱신_전자결재_전송
         * _.isEmpty(this.searchParam.dealcoCd) &&
         * _.isEqual(this.earvSt, '2') &&
         * _.isEqual(this.searchParam.eravStCd, '1')
         * BASPRM02640.xml
         */
        cltEarvTrms(value) {
            this.defaultAssign_({
                key: 'initParams.pIsNew',
                value: false,
            })
            alert('TODO' + value + '팝업')
        },
        /**
         * 변경_제외
         * _.isEqual(this.earvSt, '3') &&
         * !_.isEqual(this.searchParam.eravStCd, '4')
         */
        chgExl() {},
        /**
         * 변경
         * _.isEqual(this.earvSt, '3') &&
         * _.isEqual(this.searchParam.eravStCd, '4')
         *  BASPRM02641.xml
         */
        chg(value) {
            alert('TODO' + value + '팝업')
        },
        /**
         * 변경_신규_제외
         * _.isEqual(this.earvSt, '4') &&
         * !_.isEqual(this.searchParam.eravStCd, '2')
         */
        chgNewExl() {},
        /**
         * 변경_신규
         * _.isEqual(this.earvSt, '4') &&
         * !_.isEqual(this.searchParam.eravStCd, '2')
         * BASPRM02643.xml
         */
        chgNew(value) {
            alert('TODO' + value + '팝업')
        },
        /**
         * 거래_종료_변경_제외
         * this.isDealStatusYn &&
         * !_.isEqual(this.searchParam.eravStCd, '3')
         */
        dealEndChgExl() {},
        /**
         * 거래_종료_변경
         * _.isEqual(this.earvSt, '4') &&
         * !_.isEqual(this.searchParam.eravStCd, '2')
         * BASPRM02644.xml
         */
        dealEndChg(value) {
            alert('TODO' + value + '팝업')
        },
        /**
         * 변경_담보갱신_제외
         * _.isEqual(this.earvSt, '5') &&
         * !_.isEqual(this.searchParam.eravStCd, '5')
         */
        chgCltExl() {},
        /**
         * 변경_담보갱신
         * _.isEqual(this.earvSt, '5') &&
         * _.isEqual(this.searchParam.eravStCd, '5')
         * BASPRM02642.xml
         */
        chgClt(value) {
            alert('TODO' + value + '팝업')
        },
        /**
         * 신규_재품의_제외
         * _.isEqual(this.earvSt, '7') &&
         * !_.isEqual(this.searchParam.eravStCd, '6')
         */
        newReEarvExt() {},
        /**
         * 신규_재품의
         * _.isEqual(this.earvSt, '7') &&
         * _.isEqual(this.searchParam.eravStCd, '6')
         * BASPRM02646.xml
         */
        newReEarv(value) {
            alert('TODO' + value + '팝업')
        },
    },
    watch: {
        basPrmDealcoDtlVo: {
            handler: function (values) {
                let detailData = this.newInfo // 데이터 Set

                _.forEach(Object.keys(detailData), (key) => {
                    if (!_.isEmpty(key)) {
                        // 기본정보셋팅
                        let value = values[key]
                        //let isValue = false
                        //let currentDate = moment(new Date()).format('YYYY-MM-DD')
                        if (
                            _.isEqual(value, undefined) ||
                            _.isEqual(value, null) ||
                            _.isEqual(value, '')
                        ) {
                            if (typeof detailData[key] === 'object') {
                                value = []
                            } else {
                                value = ''
                            }
                        } else {
                            //isValue = true
                        }

                        // 필터정보셋팅
                        detailData[key] = value
                    }
                })

                let param = { ...detailData }
                this.storeSet(this.storeKey, param)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
