import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'checkBox',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dataClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wireClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcProdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'checkBox',
            fieldName: 'checkBox',
            type: 'data',
            width: '50',
            editable: false,
            renderer: {
                type: 'check',
            },
            header: {
                text: '선택',
            },
        },
        {
            name: 'dataClCd',
            fieldName: 'dataClCd',
            header: {
                text: '포털통합ID',
            },
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'U.Key ID',
            },
        },
        {
            name: 'prodId',
            fieldName: 'prodId',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '성명',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            header: {
                text: '사용자구분',
            },
        },
        {
            name: 'wireClCd',
            fieldName: 'wireClCd',
            header: {
                text: '소속조직',
            },
        },
        {
            name: 'svcProdNm',
            fieldName: 'svcProdNm',
            header: {
                text: '소속대리점',
            },
        },
        {
            name: 'prodStCd',
            fieldName: 'prodStCd',
            header: {
                text: '이동전화',
            },
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            header: {
                text: '상태',
            },
        },
    ],
}
