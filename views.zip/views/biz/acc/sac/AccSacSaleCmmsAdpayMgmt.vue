<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccSacSaleCmmsAdpayMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <AccHeadline title="판매수수료 선지급 관리" />

        <AccSearchField
            ref="accSearchField"
            :offset="[
                'btn-left-excelUpload',
                'btn-left-confirm',
                'btn-left-forceConfirm',
                'btn-right-reset',
                'btn-right-view',
                'btn-right-save',
                'btn-right-delete',
                'search-accMth',
                'search-orgCd',
                '!search-dealcoCd',
                { slotSearch: 'search-procUserId' },
                '!search-clsMth',
            ]"
            :initValue="initValue"
            :popupParamOrgCd="popupParamOrgCd"
            :popupParamDealcoCd="popupParamDealcoCd"
            :preventEvent="['clickExcelUpload']"
            :statusDisableBtn="statusDisableBtn"
            @changeAccMth="changeAccMth"
            @changeOrgCd="changeOrgCd"
            @excelUpload="excelUpload"
            @confirm="confirmRow"
            @forceConfirm="forceConfirmRow"
            @reset="resetForm"
            @view="viewForm"
            @save="saveForm"
            @delete="deleteForm"
        >
            <template slot="search-procUserId" slot-scope="slotProps">
                <div
                    class="formitem"
                    :class="`div${slotProps.divideCellCount}`"
                >
                    <TCComInput
                        labelName="처리자"
                        v-model="formAccSacSaleCmmsAdpayList.query.procUserId"
                    />
                </div>
            </template>
        </AccSearchField>

        <AccGridTable
            ref="accGridTable"
            isEditable
            isCheckbox
            isColumnNo
            noPaging
            :offset="['btn-addRow', 'btn-deleteRow', 'btn-excelDownload']"
            :preventEvent="['clickAddRow']"
            :gridMeta="GRID_HEADER"
            :data="formAccSacSaleCmmsAdpayList.data"
            :pagingInfo="formAccSacSaleCmmsAdpayList.pagingInfo"
            :exportInfo="{
                uri: `/api/v1/backend-max/resource/acc/sac/accs-excel-download`,
                query: formAccSacSaleCmmsAdpayList.query,
            }"
            @rowEditing="rowEditing"
            @addRow="openOrgPopup"
            @movePage="movePage"
            @changePageSize="changePageSize"
        />

        <!-- 내부거래처(권한조직) 팝업: 그리드 데이터 추가용 -->
        <BasBcoDealcosPopup
            v-if="basBcoDealcosPopup.status.show"
            :parentParam="popupParamDealcos"
            :dialogShow.sync="basBcoDealcosPopup.status.show"
            @confirm="confirmBasBcoDealcosPopup"
        />

        <AccSacSaleCmmsAdpayMgmtExcelUpload
            name="판매수수료지급업로드"
            :status.sync="accSacSaleCmmsAdpayMgmtExcelUpload.status.show"
            :query="accSacSaleCmmsAdpayMgmtExcelUpload.query"
            @close="getAccSacSaleCmmsAdpayList"
        />
    </div>
</template>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import {
    getTodayDate,
    distanceDate,
    errorHandle,
    filter,
} from '@/utils/accUtil'

import AccHeadline from '@/components/biz/common/acc/AccHeadline'
import AccSearchField from '@/components/biz/common/acc/AccSearchField'
import AccGridTable from '@/components/biz/common/acc/AccGridTable'
import AccSacSaleCmmsAdpayMgmtExcelUpload from '@/components/biz/acc/sac/AccSacSaleCmmsAdpayMgmtExcelUpload'

import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'

import { AccUtil } from '@/views/biz/acc'
import sacApi from '@/api/biz/acc/sac'
import commonApi from '@/api/common/commonCode'

import { GRID_HEADER } from '@/const/grid/acc/sac/accSacSaleCmmsAdpayMgmtGrid'

export default {
    name: 'AccSacSaleCmmsAdpayMgmt',
    mixins: [CommonMixin, accMixin],
    components: {
        AccHeadline,
        AccSearchField,
        AccGridTable,
        AccSacSaleCmmsAdpayMgmtExcelUpload,
        BasBcoDealcosPopup,
    },
    data() {
        return {
            statusDisableBtn: {
                forceConfirm: true,
            },

            GRID_HEADER,

            initValue: {
                accMth: getTodayDate('YYYY-MM'),
                pageSize: 15,
                pageNum: 1,
            },

            formAccSacSaleCmmsAdpayList: {
                data: [],
                query: {},
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formAccSacSaleCmmsAdpaySave: {
                query: {},
            },

            formAccSacSaleCmmsAdpayDelete: {
                query: {},
            },

            formAccSacSaleCmmsAdpayConfirm: {
                query: {},
            },

            basBcoDealcosPopup: {
                status: {
                    show: false,
                },
            },

            popupParamOrgCd: {
                basMth: '',
            },

            popupParamDealcos: {
                orgNm: '', // 조직이름
                orgCd: '', // 조직코드
                basDay: '', // 기준년월
                dealcoGrpCd: '', // 거래처구분코드
                dealcoClCd1: '', // 거래처구분코드
            },

            popupParamDealcoCd: {},

            accSacSaleCmmsAdpayMgmtExcelUpload: {
                status: {
                    show: false,
                },

                query: {
                    accMth: '',
                },
            },
        }
    },

    computed: {},

    created() {},
    mounted() {
        //  강제승인권한
        this.getForceFixAuthCodeList()
    },

    methods: {
        async getForceFixAuthCodeList() {
            //  강제확정버튼 사용여부
            var allForceFixAuthCodeList = []
            allForceFixAuthCodeList = await commonApi.getCommonCodeListById(
                'ZBAS_USER_S'
            )

            this.statusDisableBtn.forceConfirm = true
            for (var i in allForceFixAuthCodeList) {
                if (
                    allForceFixAuthCodeList[i].commCdVal ==
                    this.userInfo.portalUserId
                ) {
                    this.statusDisableBtn.forceConfirm = false
                    break
                }
            }
        },

        resetForm() {
            this.formAccSacSaleCmmsAdpayList.data = []

            this.changeAccMth(this.initValue.accMth)
            this.changeOrgCd({ orgCd: '', orgNm: '', orgLvl: '' })
        },

        deleteForm() {
            const rows = this.accGridTable.getCheckedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`선택된 항목이 없습니다.`)
            } else {
                const invalidList = []
                rows.forEach((row) => {
                    if (
                        distanceDate(
                            getTodayDate().date,
                            AccUtil.dateToFormat(
                                new Date(row.modDtm),
                                'YYYYMMDD'
                            )
                        ) !== 0
                    ) {
                        invalidList.push({
                            msg: `당일 저장건만 삭제가능합니다.`,
                            list: row,
                        })
                    }

                    row.fixYn = '1'
                    row.accMth = AccUtil.dateToFormat(
                        new Date(row.accMth),
                        'YYYYMM'
                    ).substr(0, 6)
                })

                if (invalidList.length) {
                    return invalidList.forEach((arr) =>
                        this.showTcComAlert(arr.msg)
                    )
                }

                rows.forEach((arr) => {
                    arr.__rowState = 'deleted'
                })

                this.showTcComConfirm('삭제하시겠습니까?').then((confirm) => {
                    if (confirm) {
                        this.formAccSacSaleCmmsAdpayDelete.query.adpayMgmtVoList =
                            rows
                        return this.deleteAccSacSaleCmmsAdpayList()
                    }
                })
            }
        },

        viewForm(query) {
            if (!query.orgCd) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            }

            Object.assign(this.formAccSacSaleCmmsAdpayList.query, query)

            return this.getAccSacSaleCmmsAdpayList()
        },

        saveForm() {
            const rows = this.accGridTable.getChangedRow()
            if (rows.length == 0) {
                return this.showTcComAlert(`수정된 항목이 없습니다.`)
            } else {
                const invalidList = []
                rows.forEach((row) => {
                    if (
                        row.status == 'updated' &&
                        distanceDate(
                            getTodayDate().date,
                            AccUtil.dateToFormat(
                                new Date(row.modDtm),
                                'YYYYMMDD'
                            )
                        ) !== 0
                    ) {
                        invalidList.push({
                            msg: `당일 저장건만 수정가능합니다.`,
                            list: row,
                        })
                    }

                    if (!row.preAccAmt) {
                        invalidList.push({
                            msg: '선지급금액을 입력해주세요.',
                            list: row,
                        })
                    }

                    row.accMth = AccUtil.dateToFormat(
                        new Date(row.accMth),
                        'YYYYMM'
                    ).substr(0, 6)
                })

                if (invalidList.length) {
                    return invalidList.forEach((arr) =>
                        this.showTcComAlert(arr.msg)
                    )
                }

                rows.forEach((arr) => {
                    arr.payReqDt = getTodayDate('YYYYMMDD')
                })

                this.formAccSacSaleCmmsAdpaySave.query.adpayMgmtVoList = rows
                return this.postAccSacSaleCmmsAdpayList().then(
                    this.getAccSacSaleCmmsAdpayList
                )
            }
        },

        excelUpload() {
            this.accSacSaleCmmsAdpayMgmtExcelUpload.status.show = true
        },

        async confirmRow() {
            const rows = this.accGridTable.getCheckedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`확정할 데이터를 선택해주세요.`)
            } else {
                const invalidList = []
                rows.forEach((row) => {
                    if (!row.preAccAmt) {
                        invalidList.push({
                            msg: '선지급금액을 입력해주세요.',
                            list: row,
                        })
                    }

                    if (row.accSt == '정산확정' || row.accSt == '추정') {
                        invalidList.push({
                            msg: `${row.accDealcoNm}은(는) ${filter.accSt(
                                row.accSt
                            )} 상태입니다.\n확인후 다시 처리하십시오.`,
                            list: row,
                        })
                    }

                    if (row.verifyObjYn == 'Y') {
                        if (
                            row.chkAccMth == '000000' &&
                            row.chkAccPlc == '000000'
                        ) {
                            invalidList.push({
                                msg: `지출 조건에 부합하지 않는 거래처가 있습니다.(${row.accDealcoNm})\n=>지출대상 미검증`,
                                list: row,
                            })
                        }

                        if (row.expObjYn == 'N' && row.forceAprvYn == 'N') {
                            invalidList.push({
                                msg: `지출 조건에 부합하지 않는 거래처가 있습니다.(${row.accDealcoNm})\n=>지출대상아님`,
                                list: row,
                            })
                        }

                        if (
                            parseInt(row.preAccAmt, 10) >
                            parseInt(row.expDueAmt, 10)
                        ) {
                            invalidList.push({
                                msg: `지출 조건에 부합하지 않는 거래처가 있습니다.(${row.accDealcoNm})\n=>지출가능최대금액초과`,
                                list: row,
                            })
                        }
                    }

                    row.fixYn = '1'
                    row.accMth = AccUtil.dateToFormat(
                        new Date(row.accMth),
                        'YYYYMM'
                    ).substr(0, 6)
                })

                if (invalidList.length) {
                    return invalidList.forEach((arr) =>
                        this.showTcComAlert(arr.msg)
                    )
                }

                if (
                    await this.showTcComConfirm(
                        `판매수수료선지급을 확정하시겠습니까?`
                    )
                ) {
                    this.formAccSacSaleCmmsAdpayConfirm.query.adpayMgmtVoList =
                        rows
                    return this.postConfirmAccSacSaleCmmsAdpayList()
                }
            }
        },

        async forceConfirmRow() {
            const rows = this.accGridTable.getCheckedRow()
            console.log('KYJ FORCED => ', rows)
            // ADMIN 권한일 경우 선지급검증 없이 확정가능
            if (rows.length == 0) {
                return this.showTcComAlert(`확정할 데이터를 선택해주세요.`)
            } else {
                const invalidList = []
                rows.forEach((row) => {
                    if (!row.preAccAmt) {
                        invalidList.push({
                            msg: '선지급금액을 입력해주세요.',
                            list: row,
                        })
                    }

                    if (row.accSt == '정산확정' || row.accSt == '추정') {
                        invalidList.push({
                            msg: `${row.accDealcoNm}은(는) ${filter.accSt(
                                row.accSt
                            )} 상태입니다.\n확인후 다시 처리하십시오.`,
                            list: row,
                        })
                    }

                    row.fixYn = '1'
                    row.accMth = AccUtil.dateToFormat(
                        new Date(row.accMth),
                        'YYYYMM'
                    ).substr(0, 6)
                })

                if (invalidList.length) {
                    return invalidList.forEach((arr) =>
                        this.showTcComAlert(arr.msg)
                    )
                }

                if (
                    await this.showTcComConfirm(
                        `강제확정버튼을 클릭했습니다. 선지급검증없이 확정처리됩니다.\n확정하시겠습니까?`
                    )
                ) {
                    this.formAccSacSaleCmmsAdpayConfirm.query.adpayMgmtVoList =
                        rows
                    return this.postConfirmAccSacSaleCmmsAdpayList()
                }
            }
        },

        changeAccMth(date) {
            this.popupParamOrgCd.basMth = date
            this.popupParamDealcos.basDay = date
            this.popupParamDealcoCd.basDay = date

            this.accSacSaleCmmsAdpayMgmtExcelUpload.query.accMth = date
        },

        changeOrgCd(query) {
            const { orgCd, orgNm, orgLvl } = query

            this.popupParamDealcos.orgLvl = orgLvl
            this.popupParamDealcos.orgCd = orgCd
            this.popupParamDealcos.orgNm = orgNm

            this.popupParamDealcoCd.orgLvl = orgLvl
            this.popupParamDealcoCd.orgCd = orgCd
            this.popupParamDealcoCd.orgNm = orgNm

            this.popupParamOrgCd.orgCd = orgCd
            this.popupParamOrgCd.orgNm = orgNm
        },

        movePage(query) {
            Object.assign(this.formAccSacSaleCmmsAdpayList.query, query)
            this.getAccSacSaleCmmsAdpayList()
        },

        changePageSize(query) {
            this.accSearchField.setQuery(query)
            // Object.assign(this.formAccSacSaleCmmsAdpayList.query, query)
        },

        rowEditing(row, rowIdx, rowInfo) {
            if (row.accSt == '정산확정') {
                console.info('정산확정 cancel', row, rowIdx, rowInfo)
                this.accGridTable.gridView.cancelEditor()
            }
        },

        openOrgPopup() {
            const currentQuery = this.accSearchField.getQuery()

            if (!currentQuery.orgCd) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            } else {
                this.basBcoDealcosPopup.status.show = true
            }
        },

        confirmBasBcoDealcosPopup(rowData) {
            const currentQuery = this.accSearchField.getQuery()
            const query = {}

            Object.assign(query, currentQuery, rowData)

            query.fixYn = 'A'
            query.accMth = query.accMth.replace(/-/g, '')
            query.__rowState = 'create'

            return sacApi.getAccSacSaleCmmsAdpayNewList(query).then((res) => {
                console.log('response', res)

                res.adpayMgmtVoList.forEach((row) => {
                    console.log('row ===> ', row)
                    this.accGridTable.addRowData(row, 'last')
                })
            })
        },

        getAccSacSaleCmmsAdpayList() {
            return sacApi
                .getAccSacSaleCmmsAdpayList(
                    this.formAccSacSaleCmmsAdpayList.query
                )
                .then((res) => {
                    this.formAccSacSaleCmmsAdpayList.data = [
                        ...res['adpayMgmtVoList'],
                    ]
                })
        },

        postAccSacSaleCmmsAdpayList() {
            return sacApi
                .postAccSacSaleCmmsAdpayList(
                    this.formAccSacSaleCmmsAdpaySave.query
                )
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                })
        },

        postConfirmAccSacSaleCmmsAdpayList() {
            return sacApi
                .postConfirmAccSacSaleCmmsAdpayList(
                    this.formAccSacSaleCmmsAdpayConfirm.query
                )
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                    this.getAccSacSaleCmmsAdpayList()
                })
        },

        deleteAccSacSaleCmmsAdpayList() {
            return sacApi
                .deleteAccSacSaleCmmsAdpayList(
                    this.formAccSacSaleCmmsAdpayDelete.query
                )
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                    this.getAccSacSaleCmmsAdpayList()
                })
                .catch(errorHandle)
        },
    },
}
</script>
