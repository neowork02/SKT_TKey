<template>
    <TCComDialog :dialogShow.sync="activeOpenChrgrDealcos" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">담보거래처조회 팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="searchParam.orgNm"
                                    :codeVal.sync="searchParam.orgCd"
                                    :eRequired="true"
                                    labelName="조직"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onDynamicOrgTreesEnterKey"
                                    @appendIconClick="
                                        onDynamicOrgTreesIconClick
                                    "
                                    @input="onDynamicOrgTreesInput"
                                />
                                <BasBcoDynamicOrgTreesPopup
                                    v-if="showDynamicOrgTrees"
                                    :parentParam="searchDynamicOrgTreesForm"
                                    :rows="resultDynamicOrgTreesRows"
                                    :dialogShow.sync="showDynamicOrgTrees"
                                    @confirm="onDynamicOrgTreesReturnData"
                                />
                            </div>

                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchParam.bizNo"
                                    :eRequired="true"
                                    labelName="사업자번호"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchParam.dealcoCd"
                                    labelName="거래처코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchParam.dealcoNm"
                                    labelName="거래처명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <!-- // input -->
                            <div class="formitem div3">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            :objAuth="objAuth"
                                            @click="onSearch"
                                        >
                                            =
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="ChrgrDealcosGrid"
                                ref="ChrgrDealcosGrid"
                                :editable="true"
                                :fields="header.fields"
                                :columns="header.columns"
                                @hook:mounted="gridMounted"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                    <TCComAlert
                        v-model="showAlertBool"
                        :headerText="headerText"
                        :bodyText="alertBodyText"
                    ></TCComAlert>
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'

import basBcoCtlDealcos from '@/api/biz/bas/bco/bacBcoCtlDealcos'
import commonApi from '@/api/common/commonCode'
//import { SacCommon } from '@/views/biz/sac/js'
import CommonMixin from '@/mixins'
import moment from 'moment'

//====================내부조직팝업-조회조건====================
import BasBcoDynamicOrgTreesPopup from '@/components/common/BasBcoDynamicOrgTreesPopup'
import basBcoDynamicOrgTreesApi from '@/api/biz/bas/bco/basBcoDynamicOrgTrees'
//====================//내부조직팝업-조회조건==================
import _ from 'lodash'
import { BAS_BCO_CTL_DEALCOS_HEADER } from '@/const/grid/bas/bco/basBcoCtlDealcosHeader'

export default {
    name: 'BasBcoCtlDealcosPopup',
    mixins: [CommonMixin],
    components: {
        BasBcoDynamicOrgTreesPopup,
    },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: {
            type: Object,
            default: () => {},
            required: false,
        },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            header: BAS_BCO_CTL_DEALCOS_HEADER,
            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
            searchParam: {
                orgCd: '',
                orgLvl: '',
                orgNm: '',
                dealCoGrp: '', // 내부거래처그룹
                dealcoClCd1: '', // 내부거래처구분
                dealCd: '', // 내부거래처코드
                nm: '', // 내부거래처명
                bizNo: '',
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
            },
            commChrgrDealcosPtn: [],
            //====================내부조직팝업-조회조건====================
            showDynamicOrgTrees: false,
            searchDynamicOrgTreesForm: {
                orgCd: '', // 거래처코드
                orgNm: '', // 거래처명
                orgLvl: '', // 거래처명
            },
            resultDynamicOrgTreesRows: [],
            //====================//내부조직팝업-조회조건==================
        }
    },
    computed: {
        activeOpenChrgrDealcos: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('value ->', value)
                this.searchParam.dealcoCd =
                    value['dealcoCd'] == undefined ? '' : value['dealcoCd']
                this.searchParam.dealcoNm =
                    value['dealcoNm'] == undefined ? '' : value['dealcoNm']
                this.searchParam.orgNm =
                    value['orgNm'] == undefined ? '' : value['orgNm']
                this.searchParam.orgCd =
                    value['orgCd'] == undefined ? '' : value['orgCd']
                this.searchParam.orgLvl =
                    value['orgCd'] == undefined ? '' : value['orgLvl']
                /*
this.searchParam.nm =
    value['nm'] == undefined ? '' : value['nm']
let basDay = value['basDay'] == undefined ? '' : value['basDay']
basDay = CommonUtil.replaceDash(basDay)
if (basDay.length < 6) {
    basDay = CommonUtil.replaceDash(SacCommon.getToday())
    basDay = basDay.substring(0, 6)
    this.searchParam.basDayTemp = basDay
} else if (basDay.length == 6) {
    this.searchParam.basDayTemp = basDay
} else {
    basDay = basDay.substring(0, 6)
    this.searchParam.basDayTemp = basDay
}

*/
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.init()
    },
    mounted() {
        this.gridObj = this.$refs.ChrgrDealcosGrid // Grid Object 설정
        this.initGrid()
    },
    methods: {
        async init() {
            this.gridData = this.gridSetData()
            this.searchParam.searchDateModel = moment().format('YYYY-MM-DD')
        },
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        async initGrid() {
            /*
const commDealcoGrpNm = await this.getCommCodeList('DEAL_CO_GRP')
const commDealCoClCd1Nm = await this.getCommCodeList('ZBAS_C_00240')
const commDealCoClCd2Nm = await this.getCommCodeList('ZBAS_C_00110')

this.gridObj.gridView.columnByName('dealcoGrpCd').values =
    CommonUtil.convListToGridLovValues(commDealcoGrpNm, 'commCdVal')
this.gridObj.gridView.columnByName('dealcoGrpCd').labels =
    CommonUtil.convListToGridLovLabels(
        commDealcoGrpNm,
        'commCdValNm'
    )

this.gridObj.gridView.columnByName('dealcoClCd1').values =
    CommonUtil.convListToGridLovValues(
        commDealCoClCd1Nm,
        'commCdVal'
    )
this.gridObj.gridView.columnByName('dealcoClCd1').labels =
    CommonUtil.convListToGridLovLabels(
        commDealCoClCd1Nm,
        'commCdValNm'
    )

this.gridObj.gridView.columnByName('dealcoClCd2').values =
    CommonUtil.convListToGridLovValues(
        commDealCoClCd2Nm,
        'commCdVal'
    )
this.gridObj.gridView.columnByName('dealcoClCd2').labels =
    CommonUtil.convListToGridLovLabels(
        commDealCoClCd2Nm,
        'commCdValNm'
    )
    
*/
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj.setGridState(false, false, false)
            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },

        gridMounted() {
            console.log('gridMounted')
        },

        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },

        getChrgrDealcosList() {
            /*
this.searchParam.searchDate = CommonUtil.replaceDash(
    this.searchParam.searchDateTemp
)*/
            if (this.searchParam.bizNo === '') {
                this.showTcComAlert('사업자번호를 선택해주세요.')
                return false
            }
            console.log('this.searchParam.orgCd:%s', this.searchParam.orgCd)
            if (this.searchParam.orgCd === '') {
                this.showTcComAlert('조직을 선택해주세요.', {
                    //header: '내부거래처',
                    size: '500',
                    confirmLabel: 'OK',
                })

                return false
            }
            /*
let basDayTemp = CommonUtil.replaceDash(this.searchParam.basDayTemp)

if ('' == basDayTemp) {
    let today = SacCommon.getToday()
    this.searchParam.basDay = CommonUtil.replaceDash(today)
} else {
    if (basDayTemp.length == 6) {
        let lastDay = SacCommon.uf_monthLastDay(basDayTemp)
        this.searchParam.basDay = basDayTemp + lastDay
    } else if (this.searchParam.basDayTemp.length > 6) {
        let today = SacCommon.getToday()
        this.searchParam.basDay = CommonUtil.replaceDash(today)
    }
}

 */
            basBcoCtlDealcos.getDealcosList(this.searchParam).then((res) => {
                console.log('getChrgrDealcosList then : ', res)
                this.gridObj.setRows(res)
            })
        },
        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpenChrgrDealcos = false
        },

        onSearch() {
            this.getChrgrDealcosList()
        },

        onEnterKey() {
            this.onSearch()
        },
        //===================== 내부조직팝업-조회조건팝업관련 methods ================================
        // 내부거래처-조회조건 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-조회조건 팝업 오픈
        getDynamicOrgTreeList() {
            basBcoDynamicOrgTreesApi
                .getDynamicOrgTreeList(this.searchDynamicOrgTreesForm)
                .then((res) => {
                    console.log('getDynamicOrgTreeList then : ', res)
                    // 검색된 내부거래처-조회조건 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-조회조건 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-조회조건 팝업 오픈
                    if (res.length === 1) {
                        this.searchDynamicOrgTreesForm.orgCd = _.get(
                            res[0],
                            'orgCd'
                        )
                        this.searchDynamicOrgTreesForm.orgNm = _.get(
                            res[0],
                            'orgNm'
                        )
                        this.searchDynamicOrgTreesForm.orgLvl = _.get(
                            res[0],
                            'orgLvl'
                        )
                    } else {
                        this.resultDynamicOrgTreesRows = res
                        this.showDynamicOrgTrees = true
                    }
                })
        },
        // 내부거래처-조회조건 TextField 돋보기 Icon 이벤트 처리
        onDynamicOrgTreesIconClick() {
            // 내부거래처-조회조건 팝업 Row 설정 Prop 변수 초기화
            this.resultDynamicOrgTreesRows = []
            // 검색조건 내부거래처-조회조건명이 빈값이 아니면 내부거래처-조회조건 정보 조회
            // 그 이외는 내부거래처-조회조건 팝업 오픈
            if (!_.isEmpty(this.searchParam.orgNm)) {
                this.getDynamicOrgTreeList()
            } else {
                this.showDynamicOrgTrees = true
            }
        },
        // 내부거래처-조회조건 TextField 엔터키 이벤트 처리
        onDynamicOrgTreesEnterKey() {
            // 내부거래처-조회조건 팝업 Row 설정 Prop 변수 초기화
            this.resultDynamicOrgTreesRows = []
            // 검색조건 내부거래처-조회조건명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParam.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-조회조건명 입력해주세요.'
                return
            }
            // 내부거래처-조회조건 정보 조회
            this.getDynamicOrgTreeList()
        },
        // 내부거래처-조회조건 TextField Input 이벤트 처리
        onDynamicOrgTreesInput() {
            // 입력되는 값이 있으면 내부거래처-조회조건 코드 초기화
            this.searchParam.orgCd = ''
        },
        // 내부거래처-조회조건 팝업 리턴 이벤트 처리
        onDynamicOrgTreesReturnData(retrunData) {
            console.log('DynamicOrgTreesReturnData retrunData: ', retrunData)
            this.searchParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchParam.orgNm = _.get(retrunData, 'orgNm')
            this.searchParam.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업-조회조건팝업관련 methods ================================
    },
}
</script>
