<template>
    <div>
        <search-container ref="searchContainer" />
        <table-container @Refresh="Refresh" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/apm/intgAprvMgmt/helpers'

import SearchContainer from './SearchContainer.vue'
import TableContainer from './TableContainer.vue'

export default {
    name: 'MainContent',
    components: {
        SearchContainer,
        TableContainer,
    },
    data() {
        return {
            objAuth: {},
        }
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
        Refresh() {
            this.$refs.searchContainer.search()
        },
    },
}
</script>

<style scoped></style>
