import api from '@/api/biz/bas/req/basReqDocRgst'
import types from './mutation-types'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },
    // eslint-disable-next-line no-unused-vars
    async getBasReqDocRgstList_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getBasReqDocRgstList_', searchParams)
        await api.getBasReqDocRgstList_({ searchParams }).then((data) => {
            console.log('🚀 ~ getBasReqDocRgstList_ ~ .then ~ data', data)
            resultData = data
        })
        return resultData
    },
    // // eslint-disable-next-line no-unused-vars
    // async saveDocRgst_({ state, commit }, formData) {
    //     console.log('🚀 ~ saveDocRgst_ ~ formData', formData)
    //     let result = await api.saveDocRgst_(formData)
    //     return result
    // },
    // eslint-disable-next-line no-unused-vars
    async saveDocRgst_({ state, commit }, { saveRows }) {
        console.log('🚀 ~ file: actions.js ~ saveDocRgst_ ~ saveRows', saveRows)
        let result = 0
        await api
            .saveDocRgst_(saveRows)
            .then((data) => {
                console.log(
                    '🚀 ~ file: actions.js ~ saveDocRgst_~ .then ~ data',
                    data
                )
                result = data
            })
            .catch((error) => {
                throw error
            })
        // const _sleep = (delay) =>
        //     new Promise((resolve) => setTimeout(resolve, delay))
        // const timer = async () => {
        //     await _sleep(1000)
        // }
        // await timer()
        return result
    },
    // eslint-disable-next-line no-unused-vars
    async saveAttachFile_({ state, commit }, formData) {
        console.log('🚀 ~ saveAttachFile_ ~ formData', formData)
        let result = await api.saveAttachFile_(formData)
        return result
    },
    // eslint-disable-next-line no-unused-vars
    async getAttachFile_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getAttachFile_', searchParams)
        await api.getAttachFile_({ searchParams }).then((data) => {
            console.log('🚀 ~ getAttachFile_ ~ .then ~ data', data)
            resultData = data
        })
        return resultData
    },
}
