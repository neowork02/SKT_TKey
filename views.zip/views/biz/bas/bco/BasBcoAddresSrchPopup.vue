<!-----------------------------------------------
 * 업무그룹명: 도로명/건물명 조회팝업
 * 서브업무명: 도로명/건물명 조회팝업
 * 설명: 도로명/건물명 조회한다.
 * 작성자: P179229
 * 작성일: 2022.10.27
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="500px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">{{ title }} 찾기</p>
                <div class="layerCont">
                    <!-- gridWrap -->
                    <div class="gridWrap">
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="addresPopupGridHeader"
                                ref="addresPopupGridHeader"
                                :gridObj="gridObj"
                            />
                            <TCRealGrid
                                id="addresPopupGrid"
                                ref="addresPopupGrid"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                        </div>
                    </div>
                    <!-- //gridWrap -->
                    <!-- btn -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!-- // btn -->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { BasBcoProdAddresSrchGRID_HEADER } from '@/const/grid/bas/bco/basBcoAddresSrchPopupHeader'
import CommonMixin from '@/mixins'
import store from '@/store'
import _ from 'lodash'

export default {
    name: 'BasBcoAddresSrchPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        parentParam: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            gridData: this.gridSetData(),
            objAuth: {},
            view: BasBcoProdAddresSrchGRID_HEADER,
            gridObj: {},
            gridHeaderObj: {},
            addr: '',
            title: '',
            gubun: '',
            search: '',
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.gubun = value['gubun']
                this.search = value['search']
                this.addr = value['addr']
                if (value['gubun'] === 'st') {
                    this.title = '도로명'
                    this.getStreet()
                } else if (value['gubun'] === 'bld') {
                    this.title = '건물명'
                    this.getBuilding()
                }
            },
            deep: true,
            immediate: true,
        },
    },
    created() {},
    mounted() {
        this.gridObj = this.$refs.addresPopupGrid
        this.gridHeaderObj = this.$refs.addresPopupGridHeader
        this.gridObj.setGridState(false, false, true)
        this.gridObj.gridView.setCheckBar({
            exclusive: true,
        })
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked
    },
    methods: {
        /* 그리드 설정 */
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(-1, 10, '', '')
        },
        onClose: function () {
            this.activeOpen = false
        },
        //도로명 조회
        getStreet() {
            this.xmlhttpPost('/getStreet.do', this.search, 'setStreet')
        },
        //도로명 setting
        setStreet(responseText) {
            let streetJson = []
            let streetList = JSON.parse(responseText)
            streetList.forEach((data) => {
                let streetData = {}
                let addresName = _.get(data, 'DO_NM')
                addresName += ' ' + _.get(data, 'CT_NM')
                addresName += ' ' + _.get(data, 'B_DNG_NM')
                addresName += ' ' + _.get(data, 'RD_NM')
                addresName += ' ' + _.get(data, 'UNDR_GRND_NM')
                streetData.addresName = addresName
                streetData.selectDo = _.get(data, 'DO_NM')
                streetData.selectSi = _.get(data, 'CT_NM')
                streetData.stName = _.get(data, 'RD_NM')
                streetData.gubun = this.gubun
                streetJson.push(streetData)
            })
            this.gridObj.dataProvider.fillJsonData(streetJson, {})
            this.gridObj.gridView.checkItem(0, true)
        },
        //건물명 조회
        getBuilding() {
            this.xmlhttpPost('/getBuilding.do', this.search, 'setBuilding')
        },
        //건물명 setting
        setBuilding(responseText) {
            let buildingJson = []
            let buildingList = JSON.parse(responseText)
            buildingList.forEach((data) => {
                let buildingData = {}
                let addresName = _.get(data, 'DO_NM')
                addresName += ' ' + _.get(data, 'CT_NM')
                addresName += ' ' + _.get(data, 'B_DNG_NM')
                addresName += ' ' + _.get(data, 'RD_NM')
                addresName += ' ' + _.get(data, 'UNDR_GRND_NM')
                addresName += ' ' + _.get(data, 'BLD_NM_CT')
                buildingData.addresName = addresName
                buildingData.selectDo = _.get(data, 'DO_NM')
                buildingData.selectSi = _.get(data, 'CT_NM')
                buildingData.bldName = _.get(data, 'BLD_NM_CT')
                buildingData.gubun = this.gubun
                buildingJson.push(buildingData)
            })
            this.gridObj.dataProvider.fillJsonData(buildingJson, {})
            this.gridObj.gridView.checkItem(0, true)
        },
        /* 확인 */
        onConfirm() {
            const checkedRows = this.gridObj.gridView.getCheckedRows(true)
            if (!checkedRows.length) {
                this.showTcComAlert('주소를 선택해주세요.')
                return
            }
            let jsonData = {}
            checkedRows.forEach((item) => {
                jsonData = this.gridObj.dataProvider.getJsonRow(item)
            })
            this.$emit('confirm', jsonData)
            this.onClose()
        },
        /* 그리드 설정 -셀 더블클릭 시 부모로 값 이동 */
        onCellDblClicked() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('주소를 선택해주세요.')
                return
            }
            let jsonData = this.gridObj.dataProvider.getJsonRow(current.dataRow)
            this.$emit('confirm', jsonData)
            this.onClose()
        },
        xmlhttpPost(url, search, rtn) {
            store.dispatch('setApiLoading', true)
            var xmlHttpReq = this.createXMLHttpRequest()
            xmlHttpReq.open('POST', this.addr + url, true)
            xmlHttpReq.setRequestHeader(
                'Content-Type',
                'application/x-www-form-urlencoded; charset=utf-8'
            )
            xmlHttpReq.onreadystatechange = () => {
                if (xmlHttpReq.readyState === XMLHttpRequest.DONE) {
                    if (xmlHttpReq.status === 200) {
                        //console.log(xmlHttpReq.responseText)
                        if (rtn === 'setStreet') {
                            this.setStreet(xmlHttpReq.responseText)
                        } else if (rtn === 'setBuilding') {
                            this.setBuilding(xmlHttpReq.responseText)
                        }
                        store.dispatch('setApiLoading', false)
                    } else {
                        console.log(xmlHttpReq.status, xmlHttpReq.statusText)
                        store.dispatch('setApiLoading', false)
                    }
                } else {
                    store.dispatch('setApiLoading', false)
                }
            }
            xmlHttpReq.send(search)
        },
        createXMLHttpRequest() {
            var xmlHttp = null
            if (window.XMLHttpRequest) {
                xmlHttp = new XMLHttpRequest()
            }
            return xmlHttp
        },
    },
}
</script>
