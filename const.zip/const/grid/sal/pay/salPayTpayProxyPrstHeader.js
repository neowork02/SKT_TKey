import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'orgNm', //영업팀
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'teamOrgCd', //영업팀명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'newOrgNm', //영업파트
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', //영업파트명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, //조직트리
        },
        {
            fieldName: 'agencyCd', //Swing대리점
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd', //Swing서브점
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm', //_대리점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubNm', //Swing서브점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', //정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', //정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payObjAmt', //_수납의뢰처금액
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payReqDealcoCd', //수납의뢰처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payReqDealcoNm', //수납의뢰처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgrId', //_판매담당자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgNm', //영업담당자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wcktDealTypYn', //분실납여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payClCd', //수납구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pm02Amt', //기타수납
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pm01Amt', //현금수납
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pm04Amt', //현금+기타수납
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pm03Amt', //상품권수납
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            header: {
                text: '영업팀',
                excelName: '영업팀',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'teamOrgCd',
            fieldName: 'teamOrgCd',
            type: 'data',
            header: {
                text: '영업팀명',
                excelName: '영업팀명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'newOrgNm',
            fieldName: 'newOrgNm',
            type: 'data',
            header: {
                text: '영업파트',
                excelName: '영업파트',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            header: {
                text: '영업파트명',
                excelName: '영업파트명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직트리',
            },
            visible: true,
            width: '330',
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: {
                text: 'Swing대리점',
                excelName: 'Swing대리점',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            header: {
                text: 'Swing서브점',
                excelName: 'Swing서브점',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: {
                text: '_대리점명',
                excelName: '_대리점명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'sktSubNm',
            fieldName: 'sktSubNm',
            type: 'data',
            header: {
                text: 'Swing서브점명',
                excelName: 'Swing서브점명',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            header: {
                text: '정산처',
                excelName: '정산처',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            header: {
                text: '정산처명',
                excelName: '정산처명',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'payObjAmt',
            fieldName: 'payObjAmt',
            type: 'data',
            header: {
                text: '_수납의뢰처금액',
                excelName: '_수납의뢰처금액',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'payReqDealcoCd',
            fieldName: 'payReqDealcoCd',
            type: 'data',
            header: {
                text: '수납의뢰처',
                excelName: '수납의뢰처',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'payReqDealcoNm',
            fieldName: 'payReqDealcoNm',
            type: 'data',
            header: {
                text: '수납의뢰처명',
                excelName: '수납의뢰처명',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'saleChrgrId',
            fieldName: 'saleChrgrId',
            type: 'data',
            header: {
                text: '_판매담당자ID',
                excelName: '_판매담당자ID',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'saleChrgNm',
            fieldName: 'saleChrgNm',
            type: 'data',
            header: {
                text: '영업담당자명',
                excelName: '영업담당자명',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'wcktDealTypYn',
            fieldName: 'wcktDealTypYn',
            type: 'data',
            header: {
                text: '분실납여부',
                excelName: '분실납여부',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'payClCd',
            fieldName: 'payClCd',
            type: 'data',
            header: {
                text: '수납구분',
                excelName: '수납구분',
            },
            editable: false,
            visible: true,
            width: '150',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'pm02Amt',
            fieldName: 'pm02Amt',
            type: 'data',
            header: {
                text: '기타수납',
                excelName: '기타수납',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
        },
        {
            name: 'pm01Amt',
            fieldName: 'pm01Amt',
            type: 'data',
            header: {
                text: '현금수납',
                excelName: '현금수납',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
        },
        {
            name: 'pm04Amt',
            fieldName: 'pm04Amt',
            type: 'data',
            header: {
                text: '현금+기타수납',
                excelName: '현금+기타수납',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
        },
        {
            name: 'pm03Amt',
            fieldName: 'pm03Amt',
            type: 'data',
            header: {
                text: '상품권수납',
                excelName: '상품권수납',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
        },
    ],
}

export const GRID_DETAIL_HEADER = {
    fields: [
        {
            fieldName: 'payDtm', //Swing수납일자 TOBE:수납일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payDt', //수납일자 TOBE:수납일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd', //Swing대리점 TOBE:SKT대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd', //Swing서브점 TOBE:SKT서브점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubNm', //Swing서브점명 TOBE:SKT서브점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', //정산처 TOBE:거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', //정산처명 TOBE:거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payReqDealcoCd', //수납의뢰처 TOBE:수납의뢰처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payReqDealcoNm', //수납의뢰처명 TOBE:수납의뢰처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payClNm', //수납구분 TOBE:수납구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNm', //고객명 TOBE:고객명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNum', //개통번호 TOBE:개통번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', //수납관리번호 TOBE:서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlWayCd', //결제조건 TOBE:결제수단코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wcktDealTypYn', //분실납여부 TOBE:SKT청구거래유형여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'revItmNm', //매출항목 TOBE:매출항목명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payObjAmt', //수납금액 TOBE:수납의뢰처금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pm01Amt', //현금수납 TOBE:현금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pm02Amt', //기타수납 TOBE:대납
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pm04Amt', //현금+기타수납 TOBE:pm04Amt
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pm03Amt', //상품권수납 TOBE:상품권
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ifYn', //사용자등록여부 TOBE:전무자료저장구분여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUser', //최초처리자 TOBE:입력사용자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm', //최초처리일자 TOBE:입력일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUser', //처리자 TOBE:수정사용자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', //처리일자 TOBE:수정일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChargeNo', //_SKT수납대행번호 TOBE:SKT수납대행번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm', //_SKT대리점명 TOBE:SKT대리점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgrId', //_판매담당자ID TOBE:판매담당자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgNm', //_판매담당자명 TOBE:판매담당자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payClCd', //_수납구분코드 TOBE:수납구분코드
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            header: {
                text: 'Swing수납일자', //TOBE:수납일시
                excelName: 'Swing수납일자',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'payDt',
            fieldName: 'payDt',
            type: 'data',
            header: {
                text: '수납일자', //TOBE:수납일자
                excelName: '수납일자',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: {
                text: 'Swing대리점', //TOBE:SKT대리점코드
                excelName: 'Swing대리점',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            header: {
                text: 'Swing서브점', //TOBE:SKT서브점코드
                excelName: 'Swing서브점',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'sktSubNm',
            fieldName: 'sktSubNm',
            type: 'data',
            header: {
                text: 'Swing서브점명', //TOBE:SKT서브점명
                excelName: 'Swing서브점명',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            header: {
                text: '정산처', //TOBE:거래처코드
                excelName: '정산처',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            header: {
                text: '정산처명', //TOBE:거래처명
                excelName: '정산처명',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'payReqDealcoCd',
            fieldName: 'payReqDealcoCd',
            type: 'data',
            header: {
                text: '수납의뢰처', //TOBE:수납의뢰처코드
                excelName: '수납의뢰처',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'payReqDealcoNm',
            fieldName: 'payReqDealcoNm',
            type: 'data',
            header: {
                text: '수납의뢰처명', //TOBE:수납의뢰처명
                excelName: '수납의뢰처명',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'payClNm',
            fieldName: 'payClNm',
            type: 'data',
            header: {
                text: '수납구분', //TOBE:수납구분명
                excelName: '수납구분',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            header: {
                text: '고객명', //TOBE:고객명
                excelName: '고객명',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'svcNum',
            fieldName: 'svcNum',
            type: 'data',
            header: {
                text: '개통번호', //TOBE:개통번호
                excelName: '개통번호',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            header: {
                text: '서비스관리번호', //TOBE:서비스관리번호
                excelName: '서비스관리번호',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'settlWayCd',
            fieldName: 'settlWayCd',
            type: 'data',
            header: {
                text: '결제조건', //TOBE:결제수단코드
                excelName: '결제조건',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'wcktDealTypYn',
            fieldName: 'wcktDealTypYn',
            type: 'data',
            header: {
                text: '분실납여부', //TOBE:SKT청구거래유형여부
                excelName: '분실납여부',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'revItmNm',
            fieldName: 'revItmNm',
            type: 'data',
            header: {
                text: '매출항목', //TOBE:매출항목명
                excelName: '매출항목',
            },
            editable: false,
            visible: true,
            width: '150',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'payObjAmt',
            fieldName: 'payObjAmt',
            type: 'data',
            header: {
                text: '수납금액', //TOBE:수납의뢰처금액
                excelName: '수납금액',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'pm01Amt',
            fieldName: 'pm01Amt',
            type: 'data',
            header: {
                text: '현금수납', //TOBE:현금
                excelName: '현금수납',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'pm02Amt',
            fieldName: 'pm02Amt',
            type: 'data',
            header: {
                text: '기타수납', //TOBE:대납
                excelName: '기타수납',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'pm04Amt',
            fieldName: 'pm04Amt',
            type: 'data',
            header: {
                text: '현금+기타수납', //TOBE:pm04Amt
                excelName: '현금+기타수납',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'pm03Amt',
            fieldName: 'pm03Amt',
            type: 'data',
            header: {
                text: '상품권수납', //TOBE:상품권
                excelName: '상품권수납',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'ifYn',
            fieldName: 'ifYn',
            type: 'data',
            header: {
                text: '사용자등록여부', //TOBE:전무자료저장구분여부
                excelName: '사용자등록여부',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'insUser',
            fieldName: 'insUser',
            type: 'data',
            header: {
                text: '최초처리자', //TOBE:입력사용자
                excelName: '최초처리자',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            header: {
                text: '최초처리일자', //TOBE:입력일시
                excelName: '최초처리일자',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'modUser',
            fieldName: 'modUser',
            type: 'data',
            header: {
                text: '처리자', //TOBE:수정사용자
                excelName: '처리자',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            header: {
                text: '처리일자', //TOBE:수정일시
                excelName: '처리일자',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'sktChargeNo',
            fieldName: 'sktChargeNo',
            type: 'data',
            header: {
                text: '_SKT수납대행번호', //TOBE:SKT수납대행번호
                excelName: '_SKT수납대행번호',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: {
                text: '_SKT대리점명', //TOBE:SKT대리점명
                excelName: '_SKT대리점명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'saleChrgrId',
            fieldName: 'saleChrgrId',
            type: 'data',
            header: {
                text: '_판매담당자ID', //TOBE:판매담당자ID
                excelName: '_판매담당자ID',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'saleChrgNm',
            fieldName: 'saleChrgNm',
            type: 'data',
            header: {
                text: '_판매담당자명', //TOBE:판매담당자명
                excelName: '_판매담당자명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'payClCd',
            fieldName: 'payClCd',
            type: 'data',
            header: {
                text: '_수납구분코드', //TOBE:수납구분코드
                excelName: '_수납구분코드',
            },
            editable: false,
            visible: false,
            width: '150',
        },
    ],
}
