import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'rowNum', // 순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoCl1Nm', // 거래처구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pcode', // 채널코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStatus', // 거래상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStaDt', // 거래개시일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndDt', // 거래종료일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgr', // 영업담당
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'baseDt', // 날짜
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'overBondAmt', // 연체채권
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'bfBondAmt', // 전일채권잔액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toFeesAmt', // 당일채권증가_SKT수납
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toCashAmt', // 당일채권증가_현금매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toFreeAmt', // 당일채권증가_공기기매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toRfndAmt', // 당일채권증가_오입금환불
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toTecoAmt', // 당일채권증가_T에코환수
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toRcvbAmt', // 당일채권증가_기타미수금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toDpstAmt', // 당일채권증가_입금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'bondTotAmt', // 당일채권증가_당일합계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'manualAdjAmt', // 수기조정
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'manualAdjRsn', // 수기조정사유
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'toBondAmt', // 당일채권잔액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleCmms', // 판매수수료
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'toExpsAmt', // 지출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toPpayAmt', // 선지급
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'base20BondAmt', // 20일기준채권잔액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'baseEndBondAmt', // 말일기준채권잔액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'modYn', // 연체채권초과여부
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'insUserId', //처리자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rowState', // Grid 변경 상태 - inserted, updated, deleted, none
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            editable: false,
            header: '순번',
            type: 'data',
            width: '50',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            header: '조직코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            header: '조직',
            editable: false,
            type: 'data',
            width: '380',
            styleName: 'left-column',
        },
        {
            name: 'dealCoCl1Nm',
            fieldName: 'dealCoCl1Nm',
            header: '거래처구분',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            header: '거래처코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            header: '거래처명',
            editable: false,
            type: 'data',
            width: '150',
            styleName: 'left-column',
        },
        {
            name: 'pcode',
            fieldName: 'pcode',
            header: '매장코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            header: '거래상태',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            editable: false,
            header: {
                text: '거래개시일',
                showTooltip: false,
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            editable: false,
            header: {
                text: '거래종료일',
                showTooltip: false,
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'saleChrgr',
            fieldName: 'saleChrgr',
            editable: false,
            header: '영업담당',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'baseDt',
            fieldName: 'baseDt',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '날짜',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'overBondAmt',
            fieldName: 'overBondAmt',
            editable: false,
            header: '연체채권',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'bfBondAmt',
            fieldName: 'bfBondAmt',
            editable: false,
            header: '전일채권잔액',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toFeesAmt',
            fieldName: 'toFeesAmt',
            editable: false,
            header: 'SKT수납',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toCashAmt',
            fieldName: 'toCashAmt',
            editable: false,
            header: '현금매출',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toFreeAmt',
            fieldName: 'toFreeAmt',
            editable: false,
            header: '공기기매출',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toRfndAmt',
            fieldName: 'toRfndAmt',
            editable: false,
            header: '오입금환불',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toTecoAmt',
            fieldName: 'toTecoAmt',
            editable: false,
            header: 'T에코환수',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toRcvbAmt',
            fieldName: 'toRcvbAmt',
            editable: false,
            header: '기타미수금',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toDpstAmt',
            fieldName: 'toDpstAmt',
            editable: false,
            header: '입금',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'bondTotAmt',
            fieldName: 'bondTotAmt',
            editable: false,
            header: '당일합계',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'manualAdjAmt',
            fieldName: 'manualAdjAmt',
            //editable: true,
            header: '* 수기조정',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            styleCallback(grid, dataCell) {
                let ret = {}
                let errMsg = grid.getValue(dataCell.index.itemIndex, 'modYn')
                if (errMsg != '' && errMsg != null && errMsg == 'Y') {
                    // console.log('non editable', errMsg)
                    // ret.editor = {
                    //     type: 'number',
                    //     editFormat: '#,##0',
                    // }
                    ret.editable = false
                } else {
                    // console.log('editable', errMsg)
                    //ret.editable = false
                    ret.editor = {
                        type: 'number',
                        editFormat: '#,##0',
                    }
                }

                return ret
            },
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'manualAdjRsn',
            fieldName: 'manualAdjRsn',
            editable: true,
            header: {
                text: '* 수기조정\n사유',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '80',
            dataType: ValueType.TEXT,
            styleCallback(grid, dataCell) {
                let ret = {}
                let errMsg = grid.getValue(dataCell.index.itemIndex, 'modYn')
                if (errMsg != '' && errMsg != null && errMsg == 'Y') {
                    ret.editable = false
                    ret.styleName = 'orange-column'
                } else {
                    ret.editable = true
                }
                return ret
            },
        },
        {
            name: 'toBondAmt',
            fieldName: 'toBondAmt',
            editable: false,
            header: {
                text: '당일\n채권잔액',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'saleCmms',
            fieldName: 'saleCmms',
            editable: false,
            header: '판매수수료',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toExpsAmt',
            fieldName: 'toExpsAmt',
            editable: false,
            header: '지출',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toPpayAmt',
            fieldName: 'toPpayAmt',
            editable: false,
            header: '선지급',
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'base20BondAmt',
            fieldName: 'base20BondAmt',
            editable: false,
            header: {
                text: '20일기준\n채권잔액',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'baseEndBondAmt',
            fieldName: 'baseEndBondAmt',
            editable: false,
            header: {
                text: '말일기준\n채권잔액',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '80',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'modYn',
            fieldName: 'modYn',
            header: {
                text: '연체채권\n초과여부',
                styleName: 'multi-line-css',
            },
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            visible: false,
            type: 'data',
        },
        {
            name: 'rowState',
            fieldName: 'rowState',
            visible: false,
            type: 'data',
        },
    ],
    layout: [
        'rowNum',
        'orgNm',
        //'orgCd',
        'pcode',
        'dealcoCd',
        'dealcoNm',
        'dealCoCl1Nm',
        'dealStatus',
        'dealStaDt',
        'dealEndDt',
        'saleChrgr',
        'baseDt',
        'overBondAmt',
        'bfBondAmt',
        {
            name: '당일채권증가 ',
            direction: 'horizontal',
            items: [
                'toFeesAmt',
                'toCashAmt',
                'toFreeAmt',
                'toRfndAmt',
                'toTecoAmt',
                'toRcvbAmt',
                'toDpstAmt',
                'bondTotAmt',
            ],
        },
        'manualAdjAmt',
        'manualAdjRsn',
        'toBondAmt',
        'saleCmms',
        'toExpsAmt',
        'toPpayAmt',
        'base20BondAmt',
        'baseEndBondAmt',
    ],
}
