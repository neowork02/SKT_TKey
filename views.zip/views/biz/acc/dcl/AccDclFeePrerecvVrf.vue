<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccSacWireEtcUpld.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <AccHeadline title="요금예수금비교검증" />

        <AccSearchField
            ref="accSearchField"
            divideCellCount="3"
            :offset="[
                'btn-right-reset',
                'btn-right-view',
                'search-aplyDt',
                '!search-ukeyAgencyCd',
            ]"
            :initValue="initValue"
            @reset="resetForm"
            @view="viewForm"
        />

        <AccGridTable
            ref="accGridTable"
            title="예수금현황"
            class="accGridTable"
            :offset="['btn-excelDownload']"
            :gridMeta="GRID_HEADER"
            :data="formGetChargeDayCls.data"
            :pagingInfo="formGetChargeDayCls.pagingInfo"
            :exportInfo="{
                uri: `/api/v1/backend-max/resource/acc/dcl/charge-day-cls-excel-down-load`,
                query: formGetChargeDayCls.query,
            }"
            @movePage="movePage"
            @changePageSize="changePageSize"
            @clickCell="clickCell"
        />

        <AccDclFeePrerecvVrfPopup1
            name="T수납대행IF상세"
            :status.sync="accDclFeePrerecvVrfPopup1.status.show"
            :data="accDclFeePrerecvVrfPopup1.data"
        />

        <AccDclFeePrerecvVrfPopup2
            name="예수금IF상세"
            :status.sync="accDclFeePrerecvVrfPopup2.status.show"
            :data="accDclFeePrerecvVrfPopup2.data"
        />

        <AccDclFeePrerecvVrfPopup3
            name="예수금미등록상세"
            :status.sync="accDclFeePrerecvVrfPopup3.status.show"
            :data="accDclFeePrerecvVrfPopup3.data"
        />
    </div>
</template>
<style scoped>
:deep(.accGridTable) .rg-header .rg-table tr td.emphasis .rg-header-renderer {
    color: #0388fc;
}
</style>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import {
    getCalcDays,
    distanceDate,
    isSameDate,
    errorHandle,
} from '@/utils/accUtil'

import AccHeadline from '@/components/biz/common/acc/AccHeadline'
import AccSearchField from '@/components/biz/common/acc/AccSearchField'
import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import AccDclFeePrerecvVrfPopup1 from '@/components/biz/acc/dcl/AccDclFeePrerecvVrfPopup1'
import AccDclFeePrerecvVrfPopup2 from '@/components/biz/acc/dcl/AccDclFeePrerecvVrfPopup2'
import AccDclFeePrerecvVrfPopup3 from '@/components/biz/acc/dcl/AccDclFeePrerecvVrfPopup3'

import dclApi from '@/api/biz/acc/dcl'

import {
    GRID_HEADER,
    MOCK_DATA,
} from '@/const/grid/acc/dcl/accDclFeePrerecvVrfGrid'

export default {
    name: 'AccSacWireEtcUpld',
    mixins: [CommonMixin, accMixin],
    components: {
        AccHeadline,
        AccSearchField,
        AccGridTable,
        AccDclFeePrerecvVrfPopup1,
        AccDclFeePrerecvVrfPopup2,
        AccDclFeePrerecvVrfPopup3,
    },
    data() {
        return {
            GRID_HEADER,

            initValue: {
                aplyDt: [
                    getCalcDays(
                        'today',
                        { count: -1, per: 'days' },
                        'YYYY-MM-DD'
                    ),
                    getCalcDays(
                        'today',
                        { count: -1, per: 'days' },
                        'YYYY-MM-DD'
                    ),
                ],
                pageSize: 15,
                pageNum: 1,
            },

            formGetChargeDayCls: {
                query: {},
                data: [],
                pagingInfo: {
                    pageSize: 15,
                },
            },

            accDclFeePrerecvVrfPopup1: {
                status: {
                    show: false,
                },
                query: {},
                data: [],
            },

            accDclFeePrerecvVrfPopup2: {
                status: {
                    show: false,
                },
                query: {},
                data: [],
            },

            accDclFeePrerecvVrfPopup3: {
                status: {
                    show: false,
                },
                query: {},
                data: [],
            },
        }
    },

    computed: {
        accGridTable() {
            return this.$refs.accGridTable
        },

        gridView() {
            return this.$refs.accGridTable.gridView
        },

        dataProvider() {
            return this.$refs.accGridTable.dataProvider
        },
    },

    created() {
        this.initPage()
        console.log(dclApi, MOCK_DATA)
    },
    methods: {
        initPage() {},

        resetForm() {
            this.formGetChargeDayCls.data = []
        },

        viewForm(query) {
            if (distanceDate(query.aplyStaDt, query.aplyEndDt) > 0) {
                return this.showTcComAlert(
                    `종료일(은)는 시작일보다 커야 합니다`
                )
            }

            if (!isSameDate(query.aplyStaDt, query.aplyEndDt, 'months')) {
                return this.showTcComAlert(
                    `시작일자와 종료일자을 동일한 월로 지정하세요`
                )
            }

            Object.assign(this.formGetChargeDayCls.query, query)
            return this.getChargeDayCls()
        },

        movePage(query) {
            Object.assign(this.formGetChargeDayCls.query, query)
            this.getChargeDayCls()
        },

        changePageSize(query) {
            this.accSearchField.setQuery(query)
            // Object.assign(this.formGetChargeDayCls.query, query)
        },

        clickCell(row, rowIdx, rowInfo) {
            const { fieldName } = rowInfo
            const query = {
                ...this.formGetChargeDayCls.query,
                pageNum: 1,
                pageSize: 15,
                ukeyAgencyCd: row.ukeyAgencyCd,
                ukeySubCd: row.ukeySubCd,
            }

            if (fieldName == 'ncChargeAmt') {
                this.accDclFeePrerecvVrfPopup1.query = query
                this.getTsalnsktChargeDtl().then(() => {
                    this.accDclFeePrerecvVrfPopup1.status.show = true
                })
            }

            if (fieldName == 'ncPrprcAmt') {
                this.accDclFeePrerecvVrfPopup2.query = query
                this.getChargeDayClsIf().then(() => {
                    this.accDclFeePrerecvVrfPopup2.status.show = true
                })
            }

            if (fieldName == 'sktPrprcNopayAmt') {
                this.accDclFeePrerecvVrfPopup3.query = query
                this.getNotRegister().then(() => {
                    this.accDclFeePrerecvVrfPopup3.status.show = true
                })
            }
        },

        getChargeDayCls() {
            // this.formGetChargeDayCls.data = [
            //     ...MOCK_DATA.resultGridDto.gridList,
            // ]
            // this.formGetChargeDayCls.pagingInfo =
            //     MOCK_DATA.resultGridDto.pagingDto

            // return Promise.resolve()

            return dclApi
                .getChargeDayCls(this.formGetChargeDayCls.query)
                .then((res) => {
                    if (res.resultGridDto.gridList) {
                        this.formGetChargeDayCls.data = [
                            ...res.resultGridDto.gridList,
                        ]
                        this.formGetChargeDayCls.pagingInfo =
                            res.resultGridDto.pagingDto
                    }
                })
                .catch(errorHandle)
        },

        getTsalnsktChargeDtl() {
            // this.accDclFeePrerecvVrfPopup1.data = [
            //     ...MOCK_DATA.resultGridDto.gridList,
            // ]
            // this.accDclFeePrerecvVrfPopup1.pagingInfo =
            //     MOCK_DATA.resultGridDto.pagingDto

            // return Promise.resolve()

            return dclApi
                .getTsalnsktChargeDtl(this.accDclFeePrerecvVrfPopup1.query)
                .then((res) => {
                    this.accDclFeePrerecvVrfPopup1.data = [
                        ...res.resultGridDto.gridList,
                    ]
                    this.accDclFeePrerecvVrfPopup1.pagingInfo =
                        res.resultGridDto.pagingDto
                })
                .catch(errorHandle)
        },

        getChargeDayClsIf() {
            // this.accDclFeePrerecvVrfPopup2.data = [
            //     ...MOCK_DATA.resultGridDto.gridList,
            // ]
            // this.accDclFeePrerecvVrfPopup2.pagingInfo =
            //     MOCK_DATA.resultGridDto.pagingDto

            // return Promise.resolve()

            return dclApi
                .getChargeDayClsIf(this.accDclFeePrerecvVrfPopup2.query)
                .then((res) => {
                    this.accDclFeePrerecvVrfPopup2.data = [
                        ...res.resultGridDto.gridList,
                    ]
                    this.accDclFeePrerecvVrfPopup2.pagingInfo =
                        res.resultGridDto.pagingDto
                })
                .catch(errorHandle)
        },

        getNotRegister() {
            // this.accDclFeePrerecvVrfPopup3.data = [
            //     ...MOCK_DATA.resultGridDto.gridList,
            // ]
            // this.accDclFeePrerecvVrfPopup3.pagingInfo =
            //     MOCK_DATA.resultGridDto.pagingDto

            // return Promise.resolve()

            return dclApi
                .getNotRegister(this.accDclFeePrerecvVrfPopup3.query)
                .then((res) => {
                    this.accDclFeePrerecvVrfPopup3.data = [
                        ...res.resultGridDto.gridList,
                    ]
                    this.accDclFeePrerecvVrfPopup3.pagingInfo =
                        res.resultGridDto.pagingDto
                })
                .catch(errorHandle)
        },
    },
}
</script>
