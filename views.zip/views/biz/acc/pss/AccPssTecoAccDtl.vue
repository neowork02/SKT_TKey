<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1500px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">T에코폰 파일 UPLOAD 내역</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <ul class="btn_area top">
                        <li class="right">
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="init"
                                >초기화</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onSearch"
                                >조회</TCComButton
                            >

                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onClose"
                                >닫기</TCComButton
                            >
                        </li>
                    </ul>
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div5">
                                <TCComDatePicker
                                    calType="M"
                                    v-model="accYm_"
                                    labelName="정산월"
                                    :eRequired="true"
                                >
                                </TCComDatePicker>
                            </div>
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    v-model="searchSaleDealcoParam.orgNm"
                                    :codeVal.sync="searchSaleDealcoParam.orgCd"
                                    labelName="매장"
                                    :disabled="true"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @appendIconClick="onSaleDealcoIconClick"
                                    @input="onSaleDealcoInput"
                                />
                                <BasBcoSaleDealcoPopup
                                    v-if="showSaleDealco"
                                    :rows="resultSaleDealcoRows"
                                    :dialogShow.sync="showSaleDealco"
                                    @confirm="onSaleDealcoReturnData"
                                />
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParams.srchDedtTypNm"
                                    :codeVal.sync="searchParams.srchDedtTypCd"
                                    labelName="공제유형"
                                    placeholder=""
                                    :disabled="true"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                />
                            </div>
                        </div>
                        <!-- // Search_line 1 -->
                    </div>
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridHeader1"
                                ref="gridHeader1"
                                gridTitle="파일내역"
                                :isPageRows="true"
                                :isExceldown="true"
                                :gridObj="gridHeaderObj"
                                @excelDownBtn="downloadExcelAll"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="grid1"
                                ref="grid1"
                                :editable="false"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>
                    <TCComPaging
                        :totalPage="gridData.totalPage"
                        :apiFunc="getTEcoExcelListByAccYm"
                        :rowCnt="rowCnt"
                        @input="chgRowCnt"
                    />

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import _ from 'lodash'
//====================매장팝업====================
import BasBcoSaleDealcoPopup from '@/components/common/BasBcoSaleDealcoPopup'
import basBcoSaleDealcoApi from '@/api/biz/bas/bco/basBcoSaleDealcoPop'
//====================//매장팝업====================
import moment from 'moment'
import CommonMixin from '@/mixins'
import { CommonGrid, CommonUtil } from '@/utils'
import tecoApi from '@/api/biz/acc/pss/accPssTecoAccMgmt'
import { GRID_HEADER } from '@/const/grid/acc/pss/AccPssTecoAccDtlGrid'

export default {
    name: 'AccPssTecoAccXls',
    mixins: [CommonMixin],
    title: 'T에코폰 정산 파일 UPLOAD',
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    components: {
        BasBcoSaleDealcoPopup,
    },
    data() {
        return {
            //====================매장팝업관련====================
            showSaleDealco: false, // 팝업 오픈 여부
            searchSaleDealcoParam: {
                orgLvl: '', // 조직레벨
                OrgCd: '', // 조직코드
                orgNm: '', // 조직명
            },
            resultSaleDealcoRows: [], // 팝업 오픈 여부
            //====================//매장팝업관련==================
            view: GRID_HEADER,
            objAuth: {},
            list: [],
            gridData: this.gridSetData(this.rowcnt),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '350px', //그리드 높이 조절
            },

            searchForms: {},
            resultData: '',
            res: {},
            rowData: '',
            rowCnt: 15,
            accYm_: '',

            searchParams: {
                srchAccYm: '', // 정산월,
                pageSize: '',
                pageNum: 1,
                srchDedtTypNm: '',
                srchAccDealcoCd: '',
            },
            requiredGrid: {
                svcMgmtNum: '시리얼번호',
            },
        }
    },
    computed: {
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        console.log('mounted')
        this.accYm_ = moment(this.popupParams.accYm_).format('YYYY-MM')
        this.searchParams.srchDedtTypNm = this.popupParams.srchDedtTypNm
        this.searchSaleDealcoParam.orgCd = this.popupParams.accDealcoCd
        this.searchParams.srchAccDealcoCd = this.searchSaleDealcoParam.orgCd
        this.searchSaleDealcoParam.orgNm = this.popupParams.accDealcoNm
        // grid 기본세팅
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, false, false)
        this.gridObj.gridView.setRowIndicator({
            visible: true,
            headText: '번호',
        })
        this.onSearch()
    },
    methods: {
        //초기화 버튼 이벤트
        init: function () {
            this.accYm_ = moment(this.popupParams.accYm_).format('YYYY-MM')
            this.onSearch()
        },
        gridSetData: function (rowCnt) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, rowCnt, '', '')
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        //===================== 매장팝업관련 methods ================================
        // 매장 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 매장 팝업 오픈
        getWorkPlaceList() {
            basBcoSaleDealcoApi
                .getWorkPlaceList(this.searchSaleDealcoParam)
                .then((res) => {
                    console.log('getWorkPlaceList then : ', res)
                    // 검색된 매장 정보가 1건이면 TextField에 바로 설정
                    // 검색된 매장 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                    if (res.length === 1) {
                        this.searchSaleDealcoParam.orgCd = _.get(
                            res[0],
                            'orgCd'
                        )
                        this.searchSaleDealcoParam.orgNm = _.get(
                            res[0],
                            'orgNm'
                        )
                    } else {
                        this.resultSaleDealcoRows = res
                        this.showBcoSaleDealco = true
                    }
                })
        },
        // 매장 TextField 돋보기 Icon 이벤트 처리
        onSaleDealcoIconClick() {
            // 매장 팝업 Row 설정 Prop 변수 초기화
            this.resultUserRows = []
            this.showSaleDealco = true
        },
        // 매장 TextField Input 이벤트 처리
        onSaleDealcoInput() {
            // 입력되는 값이 있으면 매장 코드 초기화
            this.searchSaleDealcoParam.orgCd = ''
        },
        // 매장 팝업 리턴 이벤트 처리
        onSaleDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchSaleDealcoParam.orgCd = _.get(retrunData, 'dealcoCd')
            this.searchSaleDealcoParam.orgNm = _.get(retrunData, 'dealcoNm')
        },

        //================================================
        // 전체 조회 :::: getTEcoExcelListByAccYm
        //================================================
        onSearch() {
            const srchAccYm = this.accYm_
            if (_.isEmpty(srchAccYm)) {
                this.showTcComAlert('정산월을 확인하세요.')
            } else {
                this.confirmDate_ = moment(this.accYm_)
                    .endOf('month')
                    .format('YYYY-MM-DD')
                this.searchForms = { ...this.searchParams }
                this.searchForms.pageSize = this.rowCnt
                this.searchForms.pageNum = 1
                this.searchForms.srchAccYm = CommonUtil.onlyNumber(this.accYm_)
                this.searchForms.confirmDate = CommonUtil.onlyNumber(
                    this.confirmDate_
                )
                this.getTEcoExcelListByAccYm(this.searchForms.pageNum)
                console.log('전체리스트조회 ::::::: 시작')
            }
        },
        async getTEcoExcelListByAccYm(page) {
            this.searchForms.pageNum = page
            await tecoApi
                .getTEcoExcelListByAccYm(this.searchForms)
                .then((res) => {
                    console.log(res)
                    if (res) {
                        console.log('전체리스트조회 ::::::: ', res)
                        this.tecoAccListDtl = res
                        this.gridObj.setRows(res.gridList)
                        this.gridObj.setGridIndicator(res.pagingDto)
                        this.gridData = this.gridSetData()
                        this.gridData.totalPage = res.pagingDto.totalPageCnt
                        this.gridHeaderObj.setPageCount(res.pagingDto)
                        console.log('전체리스트조회 ::::::: 끝')
                    } else {
                        this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                    }
                })
        },
        //================================================
        // EXCEL DOWNLOAD
        //================================================

        downloadExcelAll: function () {
            console.log('>>>>>>>>>>>>>> EXCEL')
            tecoApi.downloadTEcoAccDtlListExcel(this.searchForms)
        },

        onClose: function () {
            this.activeOpenAgency = false
        },
        // exportGridBtn: function () {
        //     this.gridData =
        //         this.gridHeaderObj.exportGrid('test.xls')
        // },
    },
}
</script>
