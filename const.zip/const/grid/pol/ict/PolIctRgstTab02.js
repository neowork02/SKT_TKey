import { ValueType } from 'realgrid'

export const GRID_INFO_UP_LEFT = {
    fields: [
        {
            fieldName: 'orgGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'supChnlClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'supChnlClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'subChnlClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'subChnlClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlClNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'saleChnlClCd',
            fieldName: 'saleChnlClCd',
            type: 'data',
            header: {
                text: '채널코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleChnlClNm',
            fieldName: 'saleChnlClNm',
            type: 'data',
            header: {
                text: '채널명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_DOWN_LEFT = {
    fields: [
        {
            fieldName: 'orgGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'supChnlClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'supChnlClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'subChnlClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'subChnlClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlClNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'saleChnlClCd',
            fieldName: 'saleChnlClCd',
            type: 'data',
            header: {
                text: '채널코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleChnlClNm',
            fieldName: 'saleChnlClNm',
            type: 'data',
            header: {
                text: '채널명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_RIGHT = {
    fields: [
        {
            fieldName: 'orgGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'orgTree',
            fieldName: 'orgTree',
            type: 'data',
            header: {
                text: '조직',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_RIGHT_GRP = {
    fields: [
        {
            fieldName: 'orgGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'grpNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'dealcoGrpNm',
            fieldName: 'dealcoGrpNm',
            type: 'data',
            header: {
                text: '그룹명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealCnt',
            fieldName: 'dealCnt',
            type: 'number',
            header: {
                text: '거래처수',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            header: {
                text: '거래처그룹설명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_RIGHT_DEAL = {
    fields: [
        {
            fieldName: 'orgGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'dealcoClNm',
            fieldName: 'dealcoClNm',
            type: 'data',
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: {
                text: '매장명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'orgTree',
            fieldName: 'orgTree',
            width: '420',
            type: 'data',
            header: {
                text: '조직',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_BOTTOM = {
    fields: [
        {
            fieldName: 'orgGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAprvNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAprvNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polClNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'saleAprvNo',
            fieldName: 'saleAprvNo',
            type: 'data',
            header: {
                text: '영업승인번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleAprvNm',
            fieldName: 'saleAprvNm',
            type: 'data',
            header: {
                text: '영업승인번호명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'polClNm',
            fieldName: 'polClNm',
            type: 'data',
            header: {
                text: '정책구분명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_MID = {
    fields: [
        {
            fieldName: 'orgGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'grpNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'grpNo',
            fieldName: 'grpNo',
            type: 'data',
            header: {
                text: '그룹번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealcoGrpNm',
            fieldName: 'dealcoGrpNm',
            type: 'data',
            header: {
                text: '그룹명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_MID_BOTTOM = {
    fields: [
        {
            fieldName: 'orgGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        // {
        //     name: 'orgTree',
        //     fieldName: 'orgTree',
        //     type: 'data',
        //     width: '420',
        //     header: {
        //         text: '조직',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        {
            name: 'dealcoClNm',
            fieldName: 'dealcoClNm',
            type: 'data',
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: {
                text: '매장명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
}
