<template>
    <div>
        <ul class="btn_area top">
            <!-- <li class="left">
                <v-btn outlined class="btn_ty">삭제</v-btn>
            </li> -->
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="initBtn"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div3">
                    <!-- <TCComDatePicker
                        v-model="aplyStaDt"
                        :calType="calType5"
                        labelName="조회년월"
                    >
                    </TCComDatePicker> -->
                    <TCComInputSearchText
                        labelName="소속조직"
                        :appendIconClass="''"
                        @appendIconClick="searchCommon('org')"
                        :objAuth="this.objAuth"
                        v-model="formSearchParams.orgNm"
                        :codeVal.sync="formSearchParams.orgCd"
                        :disabledAfter="true"
                        @input="onAuthOrgTreeInput"
                        :eRequired="true"
                    />
                </div>
                <div class="formitem div3">
                    <!-- <TCComComboBox
                        labelName="대리점유형"
                        v-model="formSearchParams.agencyTypCd"
                        :objAuth="objAuth"
                        @change="selectChange"
                        codeId="AGENCY_TYP"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox> -->
                    <TCComInput
                        v-model="formSearchParams.sktChnlCd"
                        labelName="채널코드"
                        :size="150"
                        :maxlength="10"
                        :objAuth="this.objAuth"
                        @input="inputEvent()"
                        :inputRuleType="'UPEN'"
                    ></TCComInput>
                </div>
                <div class="formitem div3">
                    <!-- <TCComInputSearchText
                        labelName="대리점"
                        :appendIconClass="''"
                        @appendIconClick="searchCommon('agency')"
                        :objAuth="this.objAuth"
                        v-model="agencyNm"
                        :codeVal="formSearchParams.agencyCd"
                        :disabledAfter="true"
                    /> -->
                    <TCComInput
                        v-model="formSearchParams.mblPhonNo"
                        labelName="수신번호"
                        :size="150"
                        :maxlength="14"
                        :objAuth="this.objAuth"
                        inputRuleType="N"
                        @input="inputEvent()"
                    />
                </div>
            </div>
        </div>
        <BasBcoAuthOrgTreesPopup
            v-if="showBcoAuthOrgTrees"
            :parentParam="formSearchParams"
            :rows="resultAuthOrgTreeRows"
            :dialogShow.sync="showBcoAuthOrgTrees"
            @confirm="onAuthOrgTreeReturnData"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/cmu/smsStrdMgmt/smsTrmsStrdMgmt/helpers'
// eslint-disable-next-line no-unused-vars
// import moment from 'moment'
//import CommonUtil from '@/utils/CommonUtil.js'
// eslint-disable-next-line no-unused-vars
import { msgTxt } from '@/const/msg.Properties.js'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
//====================//내부조직팝업(권한)팝업====================
import _ from 'lodash'
import CommonMixin from '@/mixins'

export default {
    components: {
        //TCComComboBox,
        BasBcoAuthOrgTreesPopup,
    },
    mixins: [CommonMixin],

    async created() {
        await this.initControls()
        await this.initData()
    },
    data() {
        return {
            objAuth: {},
            //calType5: 'M',
            //aplyStaDt: '',
            //agencyNm: '',
            formSearchParams: {
                //aplyStaDt: '', //조회년월
                //agencyTypCd: '', //대리점유형
                //agencyCd: '', //대리점코드
                orgLvlCd: '',
                orgCd: '', //조직아이디
                orgNm: '', //조직명
                sktChnlCd: '', //UKEY채널코드
                mblPhonNo: '', //수신번호
            },
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            popupParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
        }
    },
    async mounted() {
        //화면초기 로딩시 바로 검색
        // this.searchBtn()
    },
    computed: {
        ...serviceComputed,
        commCdIds1: {
            get() {
                return this.commCdIds
            },
            //set(value) {},
        },
        saveDone1: {
            get() {
                return this.saveDoneA && this.saveDoneB
            },
            //set(value) {},
        },
        resultListCopy1: {
            get() {
                return this.resultListCopy
            },
        },
    },
    methods: {
        ...serviceMethods,
        async initControls() {
            //await this.commonCodes_({ option: '전체' })
            //this.defaultAssign_({ key: 'plantCd', value: this.user.plantCd }); //watch call searchList()
        },
        async initData() {
            //let today = moment(new Date()).format('YYYY-MM')
            //this.aplyStaDt = today
            //this.agencyNm = '' //대리점명
            //this.formSearchParams.agencyCd = '' //대리점코드
            // this.formSearchParams.aplyStaDt = moment(new Date()).format(
            //     'YYYYMM'
            // ) //조회년월
            //this.formSearchParams.agencyTypCd = ''

            this.formSearchParams.orgCd = ''
            this.formSearchParams.orgLvlCd = ''
            this.formSearchParams.orgNm = ''
            this.formSearchParams.sktChnlCd = ''
            this.formSearchParams.mblPhonNo = ''
            await this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
            await this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
        },
        selectChange(val) {
            console.log('🚀 ~ file: selectChange ~ line 58 ~ selectChange', val)
        },
        searchCommon(flag) {
            // TODO 공통팝업 호출
            if (flag === 'mfact') {
                alert('제조사')
            } else if (flag === 'org') {
                //alert('조직')
                if (this.formSearchParams.orgNm == '') {
                    this.formSearchParams.orgId = ''
                }
                this.resultAuthOrgTreeRows = []
                this.showBcoAuthOrgTrees = true
            } else if (flag === 'prod') {
                alert('모델')
            } else if (flag === 'outPlc') {
                alert('보유처')
            }
        },
        async initBtn() {
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 122 ~ data ',
                this.$data
            )
            await this.initData()
            //CommonUtil.clearPage(this.$router)
        },
        async searchBtn() {
            // let fromDt = new Date(this.aplyStaDt[0])
            // let toDt = new Date(this.aplyStaDt[1])
            // if (fromDt > toDt) {
            //     this.showAlert_({
            //         title: '세금계산서일자 오류',
            //         message: '시작일자가 마지막일자 보다 큽니다.',
            //     })
            //     return
            // }
            // if (
            //     moment(fromDt).format('YYYY-MM') !=
            //     moment(toDt).format('YYYY-MM')
            // ) {
            //     this.showAlert_({
            //         title: '세금계산서일자 오류',
            //         message: '같은 월 검색만 됩니다.',
            //     })
            //     return
            // }
            //this.formSearchParams.aplyStaDt = this.aplyStaDt.replace(/-/g, '')
            if (_.isEmpty(this.formSearchParams.orgCd)) {
                await this.showTcComAlert('조직코드를 입력해 주세요.')
                return
            }

            await this.defaultAssign_({ key: 'paging', value: this.initPaging })
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 197 ~ searchBtn ~ this.formSearchParams',
                this.formSearchParams
            )
            await this.defaultAssign_({
                key: 'searchParams',
                value: _.clone(this.formSearchParams),
            })
            await this.searchData()
        },
        async searchData() {
            await this.getBasCmuSmsTrmsStrdMgmtList_()
        },
        async saveBtn() {
            //this.formSearchParams.aplyStaDt = this.aplyStaDt.replace(/-/g, '')
            //console.log('🚀 ~ file: saveBtn~ line 122 ~ data ', this.$data)
            await this.defaultAssign_({
                key: 'saveAction',
                value: true,
            })
        },
        async inputEvent() {
            this.formSearchParams.orgNm =
                this.formSearchParams.orgNm.toUpperCase()
            this.formSearchParams.sktChnlCd =
                this.formSearchParams.sktChnlCd.toUpperCase()
            this.formSearchParams.mblPhonNo =
                this.formSearchParams.mblPhonNo.toUpperCase()
            console.log('input key', this.formSearchParams)
            if (
                this.formSearchParams.orgNm == '' &&
                this.formSearchParams.sktChnlCd == '' &&
                this.formSearchParams.mblPhonNo == ''
            ) {
                await this.setUnFiltering_()
            } else {
                let pass = {
                    orgNm: this.formSearchParams.orgNm,
                    sktChnlCd: this.formSearchParams.sktChnlCd,
                    mblPhonNo: this.formSearchParams.mblPhonNo,
                }
                await this.setFiltering_(pass)
            }
        },
        //====================내부조직팝업(권한)팝업관련====================
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.formSearchParams.orgCd = ''
            this.inputEvent()
        },
        onAuthOrgTreeReturnData(retrunData) {
            console.log('popup retrunData: ', retrunData)
            this.formSearchParams.orgNm = retrunData.orgNm
            this.formSearchParams.orgCd = retrunData.orgCd
            this.formSearchParams.orgLvlCd = retrunData.orgLvl
        },
        //====================내부조직팝업(권한)팝업관련====================
        async setFiltering_({ orgNm, sktChnlCd, mblPhonNo }) {
            // eslint-disable-next-line no-unused-vars
            let resultList1 = _.clone(this.resultListCopy1)
            if (orgNm != undefined && orgNm != null && orgNm != '') {
                resultList1 = resultList1.filter((x) => {
                    return x['orgNm'] != null && x['orgNm'].indexOf(orgNm) > -1
                })
            }
            if (
                sktChnlCd != undefined &&
                sktChnlCd != null &&
                sktChnlCd != ''
            ) {
                resultList1 = resultList1.filter(
                    (x) =>
                        x['sktChnlCd'] != null &&
                        x['sktChnlCd'].indexOf(sktChnlCd) > -1
                )
            }
            if (
                mblPhonNo != undefined &&
                mblPhonNo != null &&
                mblPhonNo != ''
            ) {
                resultList1 = resultList1.filter(
                    (x) =>
                        (x['mblPhonNo1'] != null &&
                            x['mblPhonNo1'].indexOf(mblPhonNo) > -1) ||
                        (x['mblPhonNo2'] != null &&
                            x['mblPhonNo2'].indexOf(mblPhonNo) > -1) ||
                        (x['mblPhonNo3'] != null &&
                            x['mblPhonNo3'].indexOf(mblPhonNo) > -1) ||
                        (x['mblPhonNo4'] != null &&
                            x['mblPhonNo4'].indexOf(mblPhonNo) > -1) ||
                        (x['mblPhonNo5'] != null &&
                            x['mblPhonNo5'].indexOf(mblPhonNo) > -1) ||
                        (x['mblPhonNo6'] != null &&
                            x['mblPhonNo6'].indexOf(mblPhonNo) > -1) ||
                        (x['mblPhonNo7'] != null &&
                            x['mblPhonNo7'].indexOf(mblPhonNo) > -1) ||
                        (x['mblPhonNo8'] != null &&
                            x['mblPhonNo8'].indexOf(mblPhonNo) > -1) ||
                        (x['mblPhonNo9'] != null &&
                            x['mblPhonNo9'].indexOf(mblPhonNo) > -1) ||
                        (x['mblPhonNo10'] != null &&
                            x['mblPhonNo10'].indexOf(mblPhonNo) > -1)
                )
            }
            await this.defaultAssign_({
                key: 'resultList',
                value: resultList1,
            })
        },
        async setUnFiltering_() {
            let resultList1 = _.clone(this.resultListCopy1)
            await this.defaultAssign_({
                key: 'resultList',
                value: resultList1,
            })
        },
    },
    watch: {
        async saveDone1(val, oldVal) {
            if (val == true) {
                console.log('saveDone1: ', val, oldVal)
                //saveAction 작업들이 모두 완료 되면 default 상태로 변환
                await this.defaultAssign_({
                    key: 'saveAction',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: false,
                })
            }
        },
    },
}
</script>
<style>
.rightBox {
    display: flex;
    flex-direction: row;
    gap: 0.5em;
    height: 35px;
}
.rightBox .iteminput {
    width: 150px !important;
    flex-direction: row;
    flex-grow: 1;
    flex-shrink: 1;
}
.rightBox .v-input__slot {
    width: 140px !important;
    flex-direction: row;
    flex-grow: 1;
    flex-shrink: 1;
}
</style>
