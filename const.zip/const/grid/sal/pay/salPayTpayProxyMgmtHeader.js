/*****************************************
 * 업무그룹명: 판매관리
 * 서브업무명: T수납대행관리
 * 설 명 : 판매관리-T수납대행관리-SKT수납대행관리 Grid 헤더
 * 작성자: P179234
 * 작성일: 2022.07.28
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'ifOpStCd', // 처리상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procClCd', // 수납구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payDtm', // 처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyCd', // SKT대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd', // SKT서브점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubNm', // SKT서브점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd', // 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payReqPlcNm', // 수납의뢰처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payReqPlcCd', // 수납의뢰처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payClCd', // 수납구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNm', // 고객명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNumMask', // 개통번호MASK
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', // 서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlWayCd', // SKT결제수단코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payObjAmt', // 수납대상금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'wcktDealTypYn', // 청구여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'revItmNm', // SKT매출항목
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opMthdCd', // 처리방식
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procChgrgUserId', // 처리자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procChgrgUserNm', // 처리자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm', // 사용자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errorClCd', // 오류구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'slClCd', // 영업구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'linkey', // KEY값
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opStCd', // 처리상태코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opDt', // 전문일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opTm', // 처리시간
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seq', // 전문순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', // 업데이트횟수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wcktDealTypCd', // 청구거래유형코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chk', // chk
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'chk',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'ifOpStCd',
            fieldName: 'ifOpStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            styleName: 'multi-line-css',
            header: {
                text: '처리상태',
                showTooltip: false,
            },
        },
        {
            name: 'procClCd',
            fieldName: 'procClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납구분',
                showTooltip: false,
            },
        },
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
            editor: {
                type: 'number', //숫자 편집기 설정
                showStepButton: true, //숫자 편집 버튼 표시 여부
                direction: 'horizontal', //버튼 표시 방향 설정, "vertical" 설정 시 세로방향
                step: 100, // 버튼 클릭 시 값 단위
                min: 20, //최소값
                max: 999, //최대값
                delay: 100, //버튼을 누르고 있을 때 값 적용 간격
            },
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT대리점코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT서브점코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sktSubNm',
            fieldName: 'sktSubNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT서브점명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payReqPlcNm',
            fieldName: 'payReqPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납의뢰처명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payReqPlcCd',
            fieldName: 'payReqPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납의뢰처코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payClCd',
            fieldName: 'payClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납구분코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '고객명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'svcNumMask',
            fieldName: 'svcNumMask',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통번호MASK',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'settlWayCd',
            fieldName: 'settlWayCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT결제수단코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payObjAmt',
            fieldName: 'payObjAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '수납대상금액',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'wcktDealTypYn',
            fieldName: 'wcktDealTypYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '청구여부',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'revItmNm',
            fieldName: 'revItmNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT매출항목',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'opMthdCd',
            fieldName: 'opMthdCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리방식',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'procChgrgUserId',
            fieldName: 'procChgrgUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'procChgrgUserNm',
            fieldName: 'procChgrgUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사용자명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'errorClCd',
            fieldName: 'errorClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류구분코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'slClCd',
            fieldName: 'slClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업구분코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'linkey',
            fieldName: 'linkey',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'KEY값',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'opStCd',
            fieldName: 'opStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리상태코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전문일자',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'opTm',
            fieldName: 'opTm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리시간',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전문순번',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '업데이트횟수',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'wcktDealTypCd',
            fieldName: 'wcktDealTypCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '청구거래유형코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
    ],
}

export const GRID_HEADER_SW = {
    fields: [
        {
            fieldName: 'userNm', // 이름
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId', // SWing ID
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이름',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'userId',
            fieldName: 'userId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing ID',
                showTooltip: false,
            },
            editable: true,
        },
    ],
}

export const GRID_COLOR_HEADER = {
    fields: [
        {
            fieldName: 'colorCode',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'colorCode',
            fieldName: 'colorCode',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
    ],
}
