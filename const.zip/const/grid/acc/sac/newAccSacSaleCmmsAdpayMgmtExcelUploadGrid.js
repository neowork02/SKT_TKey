import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'accSt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'preAccAmt',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accCl',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            Name: 'accSt',
            fieldName: 'accSt',
            header: { text: '정산상태' },
            type: 'data',
        },
        {
            Name: 'orgCd',
            fieldName: 'orgCd',
            header: { text: '영업파트코드' },
            type: 'data',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            header: { text: '영업파트' },
            type: 'data',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            header: { text: '정산처' },
            type: 'data',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            header: { text: '정산처명' },
            type: 'data',
            styleName: 'left-column',
        },
        {
            name: 'preAccAmt',
            fieldName: 'preAccAmt',
            header: { text: '선지급금액' },
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            header: { text: '오류내용' },
            width: 500,
            type: 'data',
            styleName: 'left-column',
        },
        {
            naame: 'accCl',
            fieldName: 'accCl',
            header: { text: '정산구분' },
            type: 'data',
        },
    ],
}
