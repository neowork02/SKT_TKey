import { ValueType } from 'realgrid'

export const DisOutRtnOutProcPrst_GRID_HEADER = {
    fields: [
        {
            fieldName: 'outClNm',
            dataType: ValueType.TEXT, // 출고구분명
        },
        {
            fieldName: 'outFixYn',
            dataType: ValueType.TEXT, // 처리상태
        },
        {
            fieldName: 'dayRank',
            dataType: ValueType.NUMBER, // 차수
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직
        },
        {
            fieldName: 'outSktCd',
            dataType: ValueType.TEXT, // 출고처매장코드
        },
        {
            fieldName: 'outPlcCd',
            dataType: ValueType.TEXT, // 출고처코드
        },
        {
            fieldName: 'outPlcNm',
            dataType: ValueType.TEXT, // 출고처
        },
        // {
        //     fieldName: 'inSktCd',
        //     dataType: ValueType.TEXT, // 반품처매장코드
        // },
        {
            fieldName: 'inPlcCd',
            dataType: ValueType.TEXT, // 반품처코드
        },
        {
            fieldName: 'inPlcNm',
            dataType: ValueType.TEXT, // 반품처
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'outSchdDt',
            dataType: ValueType.TEXT, // 출고예정일
        },
        {
            fieldName: 'outFixDt',
            dataType: ValueType.TEXT, // 출고확정일
        },
        {
            fieldName: 'outSchdCnt',
            dataType: ValueType.NUMBER, // 출고예정수량
        },
        {
            fieldName: 'fixCrdtPrchsPrc',
            dataType: ValueType.NUMBER, // 여신매입가
        },
        {
            fieldName: 'realPrchsPrc',
            dataType: ValueType.NUMBER, // 실제매입가
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, // 출고사유
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT, // 처리자
        },
        {
            fieldName: 'outClCd',
            dataType: ValueType.TEXT, // 출고구분코드
        },
    ],
    columns: [
        {
            name: 'outClNm',
            fieldName: 'outClNm',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고구분',
                showTooltip: false,
            },
        },
        {
            name: 'outFixYn',
            fieldName: 'outFixYn',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고확정여부',
                showTooltip: false,
            },
        },
        {
            name: 'dayRank',
            fieldName: 'dayRank',
            type: 'data',
            width: 80,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '차수',
                showTooltip: false,
            },
            numberFormat: '##0',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: 300,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'outSktCd',
            fieldName: 'outSktCd',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcCd',
            fieldName: 'outPlcCd',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처코드',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcNm',
            fieldName: 'outPlcNm',
            type: 'data',
            width: 200,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처',
                showTooltip: false,
            },
        },
        // {
        //     name: 'inSktCd',
        //     fieldName: 'inSktCd',
        //     type: 'data',
        //     width: 140,
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '반품처매장코드',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'inPlcCd',
            fieldName: 'inPlcCd',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반품처코드',
                showTooltip: false,
            },
        },
        {
            name: 'inPlcNm',
            fieldName: 'inPlcNm',
            type: 'data',
            width: 200,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반품처',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: 150,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'outSchdDt',
            fieldName: 'outSchdDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'outFixDt',
            fieldName: 'outFixDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고확정일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'outSchdCnt',
            fieldName: 'outSchdCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고예정수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'fixCrdtPrchsPrc',
            fieldName: 'fixCrdtPrchsPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신매입가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'realPrchsPrc',
            fieldName: 'realPrchsPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '실제매입가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: 200,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고사유',
                showTooltip: false,
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
        {
            name: 'outClCd',
            fieldName: 'outClCd',
            type: 'data',
            visible: false,
        },
    ],
}
