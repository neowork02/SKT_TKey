<!-----------------------------------------------
 * 업무그룹명: 기준정보>기타
 * 서브업무명: 대용량자료요청-OnDemand관리
 * 설명: 대용량자료요청-OnDemand관리 조회/입력/수정/삭제 한다.
 * 작성자: P180392
 * 작성일: 2022.07.14
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <!-- <div class="content"> -->
    <div>
        <main-content ref="mainContent" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/odm/ondemandMt/ondemandMgmt/helpers'
import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/odm/ondemandMt/ondemandMgmt'

export default {
    name: 'BasOdmOndemandMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (this.$store.hasModule('bas.odm.ondemandMgmtStore') != true) {
            this.$store.registerModule('bas.odm.ondemandMgmtStore', store)
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.odm.ondemandMgmtStore') == true) {
            this.$store.unregisterModule('bas.odm.ondemandMgmtStore')
        }
    },

    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>

<style></style>
