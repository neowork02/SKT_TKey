<template>
    <div class="content">
        <h1>대형유통채권관리</h1>
        <ul class="btn_area top">
            <li class="left"></li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="screenInit"
                    :objAuth="objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="loadData"
                    :objAuth="objAuth"
                    >조회</TCComButton
                >
            </li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="일자"
                        calType="DP"
                        v-model="searchDpstDt"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchFormData.searchOrgNm"
                        :codeVal.sync="searchFormData.searchOrgCd"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchFormData"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchFormData.searchDealCoNm"
                        :codeVal.sync="searchFormData.searchDealCoCd"
                        labelName="거래처"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchFormData"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div4"></div>
            </div>
        </div>
        <!-- //Search_div -->

        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="대형유통채권관리"
                :gridObj="gridObj"
                :isPageRows="true"
                :isNextPage="false"
                :isPageCnt="true"
                :isExceldown="true"
                @excelDownBtn="exportExcelDown"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :editable="false"
                :movable="false"
                :columnMovable="false"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :gridObj="gridObj"
                :apiFunc="getLargeDstrbBondList"
                :rowCnt="rowCnt"
                @input="chgRowCnt"
            />
        </div>
        <!-- //gridWrap -->

        <!-- Dialog -->
        <TCComAlert
            v-model="showAlertBool"
            headerText="알림"
            :bodyText="alertBodyText"
        ></TCComAlert>
        <!-- //Dialog -->
    </div>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import pacApi from '@/api/biz/acc/pac'
import moment from 'moment'
import _ from 'lodash'
import CommonMixin from '@/mixins'
import { GRID_HEADER } from '@/const/grid/acc/pac/accPacLargDstrbBondMgmtGrid'

//  내부조직팝업(권한)
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//  내부조직팝업(권한)

//  내부거래처(권한조직)
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
//  내부거래처(권한조직)

export default {
    name: 'accPacLargDstrbBondMgmt',
    title: '대형유통채권관리',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup, //  내부조직팝업(권한)
        BasBcoDealcosPopup, //  내부거래처(권한조직)
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            list: [],
            listCount: 0,

            gridData: this.gridSetData(this.rowCnt),
            gridObj: {},
            gridHeaderObj: {},
            rowCnt: 15,
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },
            searchDpstDt: [
                moment(new Date()).format('YYYY-MM-01'),
                moment(new Date()).format('YYYY-MM-DD'),
            ],
            searchFormData: {
                searchDpstStartDt: '',
                searchDpstEndDt: '',
                searchOrgCd: '',
                searchOrgNm: '',
                searchOrgLvl: '',
                searchDealCoCd: '',
                searchDealCoNm: '',
                pageSize: '',
                pageNum: 1,
            },

            //  내부조직팝업(권한)
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchParam: {
                vLevel: '3', // 디스플레이제한레벨
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //  내부조직팝업(권한)

            //  내부거래처(권한조직)
            basBcoDealcoShow: false,
            resultDealcoRows: [],
            //  내부거래처(권한조직)

            //  알림
            showAlertBool: false,
            alertBodyText: '',
        }
    },
    mounted() {
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.$refs.grid1.setGridState(false)
        this.$refs.grid1.setRows([])
        this.gridObj.gridView.setRowIndicator({
            visible: true,
            headText: '번호',
        })
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
    },
    methods: {
        // 화면초기화
        screenInit: function () {
            CommonUtil.clearPage(this.$router)
        },
        loadData: function () {
            if (
                _.isEmpty(this.searchDpstDt[0]) ||
                _.isEmpty(this.searchDpstDt[1])
            ) {
                this.showAlertBool = true
                this.alertBodyText = '일자를 입력하십시오.'
                return
            }

            // if (_.isEmpty(this.searchFormData.searchOrgCd)) {
            //     this.showAlertBool = true
            //     this.alertBodyText = '조직을 입력하십시오.'
            //     return
            // }

            // 일자 세팅
            this.searchFormData.searchDpstStartDt =
                this.searchDpstDt[0].replace(/-/g, '')
            this.searchFormData.searchDpstEndDt = this.searchDpstDt[1].replace(
                /-/g,
                ''
            )

            this.gridData.totalPage = 0
            this.searchFormData.pageSize = this.rowCnt
            this.searchFormData.pageNum = 1

            //  대상건 조회
            this.getLargeDstrbBondList(this.searchFormData.pageNum)
        },
        async getLargeDstrbBondList(page) {
            this.searchFormData.pageNum = page

            await pacApi
                .getAccPacLargDstrbBondMgmtList(this.searchFormData)
                .then((resultData) => {
                    this.$refs.grid1.setRows(resultData.gridList)
                    this.$refs.grid1.setGridIndicator(resultData.pagingDto)

                    this.gridData = this.gridSetData()
                    this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(resultData.pagingDto)
                    if (resultData.pagingDto.totalDataCnt == 0) {
                        this.showAlertBool = true
                        this.alertBodyText = '조회된 데이터가 없습니다.'
                    }
                })
        },

        //===================== //내부조직팝업(권한)
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchFormData.searchOrgCd = _.get(res[0], 'orgCd')
                        this.searchFormData.searchOrgNm = _.get(res[0], 'orgNm')
                        this.searchFormData.searchOrgLvl = _.get(
                            res[0],
                            'vLevel'
                        )
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchFormData.searchOrgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchFormData.searchOrgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchFormData.searchOrgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchFormData.searchOrgCd = _.get(retrunData, 'orgCd')
            this.searchFormData.searchOrgNm = _.get(retrunData, 'orgNm')
            this.searchFormData.searchOrgLvl = _.get(retrunData, 'orgLvl')
            console.log('this.searchFormData: ', this.searchFormData)
        },
        //===================== //내부조직팝업(권한)

        //===================== 내부거래처(권한조직)) methods ================================
        onDealcoIconClick() {
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 팝업오픈
            this.basBcoDealcoShow = true
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchFormData.dealcoCd = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchFormData.searchDealCoCd = _.get(retrunData, 'dealcoCd')
            this.searchFormData.searchDealCoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================

        exportExcelDown: function () {
            pacApi
                .accPacLargDstrbBondExcelDownload(this.searchFormData)
                .then(() => {
                    this.showAlertBool = true
                    this.alertBodyText =
                        '대형유통채권관리 Excel 다운로드 완료되었습니다.'
                })
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
    },
}
</script>

<style scoped>
.grid {
    height: 550px;
}
</style>
