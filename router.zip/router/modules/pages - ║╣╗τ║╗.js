import Vue from 'vue'
import VueRouter from 'vue-router'
import TBaseLayout from '@/views/pages/layout/TBaseLayout'
import Main from '@/views/pages/basic/Main' /* 메인 */
import Login from '@/views/pages/basic/Login' /* 로그인 */
import errorPage from '@/views/pages/basic/errorPage' /* 에러페이지 */
import MblLayout from '@/views/pages/mobile/layout/MblLayout' /* 모바일 레이아웃 */

Vue.use(VueRouter)

const routes = [
    {
        path: '/pages/basic/Main',
        component: Main,
    },
    {
        path: '/pages/basic/Login',
        component: Login,
    },
    {
        path: '/pages/basic/errorPage',
        component: errorPage,
    },
    {
        path: '/',
        component: TBaseLayout,
        redirect: '/main',
        meta: {
            breadcrumb: 'pages',
            key: 'TDCS.pages',
        },

        children: [
            {
                path: '/pages/basic/dashboardAcc',
                name: '/pages/basic/dashboardAcc',
                component: () =>
                    import(
                        '@/views/pages/basic/dashboardAcc.vue'
                    ) /* 대시보드_정산 */,
            },
            {
                path: '/pages/basic/dashboardDis',
                name: '/pages/basic/dashboardDis',
                component: () =>
                    import(
                        '@/views/pages/basic/dashboardDis.vue'
                    ) /* 대시보드_재고 */,
            },
            {
                path: '/pages/basic/dashboardPol',
                name: '/pages/basic/dashboardPol',
                component: () =>
                    import(
                        '@/views/pages/basic/dashboardPol.vue'
                    ) /* 대시보드_정책 */,
            },
            {
                path: '/pages/basic/dashboardRm',
                name: '/pages/basic/dashboardRm',
                component: () =>
                    import(
                        '@/views/pages/basic/dashboardRm.vue'
                    ) /* 대시보드_RM */,
            },
            {
                path: '/pages/basic/dashboardSal',
                name: '/pages/basic/dashboardSal',
                component: () =>
                    import(
                        '@/views/pages/basic/dashboardSal.vue'
                    ) /* 대시보드_판매 */,
            },
            {
                path: '/pages/basic/dashboardStore',
                name: '/pages/basic/dashboardStore',
                component: () =>
                    import(
                        '@/views/pages/basic/dashboardStore.vue'
                    ) /* 대시보드_판매점관리 */,
            },
            //{
            //path: '/pages/basic/errorPage',
            // name: '/pages/basic/errorPage',
            //component: () =>
            //import(
            //'@/views/pages/basic/errorPage.vue'
            //) /* 에러페이지 */,
            //},
            {
                path: '/pages/dis/DISACT00100',
                component: () =>
                    import(
                        '@/views/pages/dis/DISACT00100.vue'
                    ) /* 재고 - 재고실사관리 */,
            },
            {
                path: '/pages/dis/DISACT00130',
                component: () =>
                    import(
                        '@/views/pages/dis/DISACT00130.vue'
                    ) /* 재고 - 2차원바코드입력 팝업 */,
            },
            {
                path: '/pages/dis/DISBEQ00200',
                component: () =>
                    import(
                        '@/views/pages/dis/DISBEQ00200.vue'
                    ) /* 재고 - 불량기기등록 팝업 */,
            },
            {
                path: '/pages/dis/DISBEQ00300',
                component: () =>
                    import(
                        '@/views/pages/dis/DISBEQ00300.vue'
                    ) /* 재고 - 불량해제등록 팝업 */,
            },
            {
                path: '/pages/dis/DISBEQ00500',
                component: () =>
                    import(
                        '@/views/pages/dis/DISBEQ00500.vue'
                    ) /* 재고 - Swimg교품신청결과상세 팝업 */,
            },
            {
                path: '/pages/dis/DISBEQ00600',
                component: () =>
                    import(
                        '@/views/pages/dis/DISBEQ00600.vue'
                    ) /* 재고 - 분실, 도난 단말기 관리 */,
            },
            {
                path: '/pages/dis/DISBEQ00610',
                component: () =>
                    import(
                        '@/views/pages/dis/DISBEQ00610.vue'
                    ) /* 재고 - 사고기기유심엑셀업로드 팝업 */,
            },
            {
                path: '/pages/dis/DISBEQ00700',
                component: () =>
                    import(
                        '@/views/pages/dis/DISBEQ00700.vue'
                    ) /* 재고 - RISK기기등록 팝업 */,
            },
            {
                path: '/pages/dis/DISBEQ00800',
                component: () =>
                    import(
                        '@/views/pages/dis/DISBEQ00800.vue'
                    ) /* 재고 - 사고기기 해제등록 팝업 */,
            },
            {
                path: '/pages/dis/DISBEQ00900',
                component: () =>
                    import(
                        '@/views/pages/dis/DISBEQ00900.vue'
                    ) /* 재고 - 사고단말기 상태변경 팝업 */,
            },
            {
                path: '/pages/dis/DISBEQ01100',
                component: () =>
                    import(
                        '@/views/pages/dis/DISBEQ01100.vue'
                    ) /* 재고 - 사고단말기등록 팝업 */,
            },
            {
                path: '/pages/dis/DISBEQ01200',
                component: () =>
                    import(
                        '@/views/pages/dis/DISBEQ01200.vue'
                    ) /* 재고 - 사고단말기 회수대상 목록 팝업 */,
            },
            {
                path: '/pages/dis/DISBEQ01300',
                component: () =>
                    import(
                        '@/views/pages/dis/DISBEQ01300.vue'
                    ) /* 재고 - 분실도난 단말기 상태해제 팝업 */,
            },
            {
                path: '/pages/dis/DISBEQ01400',
                component: () =>
                    import(
                        '@/views/pages/dis/DISBEQ01400.vue'
                    ) /* 재고 - 사고기기 ERP I/F 전송 */,
            },
            {
                path: '/pages/dis/DISDCO00100',
                component: () =>
                    import(
                        '@/views/pages/dis/DISDCO00100.vue'
                    ) /* 재고 - 상품입력(입고) */,
            },
            {
                path: '/pages/dis/DISDCO00800',
                component: () =>
                    import(
                        '@/views/pages/dis/DISDCO00800.vue'
                    ) /* 재고 - 재고상품 팝업 */,
            },
            {
                path: '/pages/dis/DISDEM01000',
                component: () =>
                    import(
                        '@/views/pages/dis/DISDEM01000.vue'
                    ) /* 재고 - 시연재고 관리 */,
            },
            {
                path: '/pages/dis/DISDEM01100',
                component: () =>
                    import(
                        '@/views/pages/dis/DISDEM01100.vue'
                    ) /* 재고 - 시연재고등록 팝업 */,
            },
            {
                path: '/pages/dis/DISDEM01300',
                component: () =>
                    import(
                        '@/views/pages/dis/DISDEM01300.vue'
                    ) /* 재고 - 시연재고해제 팝업 */,
            },
            {
                path: '/pages/dis/DISDTR00300',
                component: () =>
                    import(
                        '@/views/pages/dis/DISDTR00300.vue'
                    ) /* 재고 - 매출출고지시등록 > 상품입력 팝업 */,
            },
            {
                path: '/pages/dis/DISDTR00800',
                component: () =>
                    import(
                        '@/views/pages/dis/DISDTR00800.vue'
                    ) /* 재고 - 이동입고확정등록 팝업 */,
            },
            {
                path: '/pages/dis/DISIIO00610',
                component: () =>
                    import(
                        '@/views/pages/dis/DISIIO00610.vue'
                    ) /* 재고 - 매출출고지시등록 팝업 */,
            },
            {
                path: '/pages/dis/DISIIO00710',
                component: () =>
                    import(
                        '@/views/pages/dis/DISIIO00710.vue'
                    ) /* 재고 - 매출출고확정등록 팝업 */,
            },
            {
                path: '/pages/dis/DISINN00400',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN00400.vue'
                    ) /* 재고 - 입고등록 */,
            },
            {
                path: '/pages/dis/DISINN00700',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN00700.vue'
                    ) /* 재고 - 입고상세 팝업 */,
            },
            {
                path: '/pages/dis/DISINN00710',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN00710.vue'
                    ) /* 재고 - 교품입고 */,
            },
            {
                path: '/pages/dis/DISINN00800',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN00800.vue'
                    ) /* 재고 - 입고정보관리 */,
            },
            {
                path: '/pages/dis/DISINN00820',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN00820.vue'
                    ) /* 재고 - 색상변경 팝업 */,
            },
            {
                path: '/pages/dis/DISINN01000',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN01000.vue'
                    ) /* 재고 - 교품입고예정업로드 */,
            },
            {
                path: '/pages/dis/DISINN01310',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN01310.vue'
                    ) /* 재고 - SKIN 배정정보 */,
            },
            {
                path: '/pages/dis/DISINN01500',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN01500.vue'
                    ) /* 재고 - 재고엑셀업로드 */,
            },
            {
                path: '/pages/dis/DISINN01700',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN01700.vue'
                    ) /* 재고 - SKIN주문-입고-주문이력현황 */,
            },
            {
                path: '/pages/dis/DISINN03000',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN03000.vue'
                    ) /* 재고 - 기준회전일관리 */,
            },
            {
                path: '/pages/dis/DISINN03100',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN03100.vue'
                    ) /* 재고 - 본부 별 목표 관리(도매) */,
            },
            {
                path: '/pages/dis/DISINN03120',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN03120.vue'
                    ) /* 재고 - 도/소매 목표 업로드 화면 */,
            },
            {
                path: '/pages/dis/DISINN03400',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN03400.vue'
                    ) /* 재고 - 배정대상 확정관리 */,
            },
            {
                path: '/pages/dis/DISINN03500',
                component: () =>
                    import(
                        '@/views/pages/dis/DISINN03500.vue'
                    ) /* 재고 - 주문대상관리 */,
            },
            {
                path: '/pages/dis/DISOPN00200',
                component: () =>
                    import(
                        '@/views/pages/dis/DISOPN00200.vue'
                    ) /* 재고 - 개봉상태등록 팝업 */,
            },
            {
                path: '/pages/dis/DISOUT00200',
                component: () =>
                    import(
                        '@/views/pages/dis/DISOUT00200.vue'
                    ) /* 재고 - 출고등록팝업 */,
            },
            {
                path: '/pages/dis/DISUER02100',
                component: () =>
                    import(
                        '@/views/pages/dis/DISUER02100.vue'
                    ) /* 재고 - 재고보상현황관리 */,
            },
            {
                path: '/pages/dis/DISUER02200',
                component: () =>
                    import(
                        '@/views/pages/dis/DISUER02200.vue'
                    ) /* 재고 - 재고보상대상관리 */,
            },
            {
                path: '/pages/dis/DISUER02210',
                component: () =>
                    import(
                        '@/views/pages/dis/DISUER02210.vue'
                    ) /* 재고 - 재고보상 발생 단말 상세 리스트 팝업 */,
            },
            {
                path: '/pages/dis/DISUER02300',
                component: () =>
                    import(
                        '@/views/pages/dis/DISUER02300.vue'
                    ) /* 재고 - 재고보상 Data 검증 */,
            },
            {
                path: '/pages/sal/SALSTD00200',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSTD00200.vue'
                    ) /* 판매 - Swing 전문관리 */,
            },
            {
                path: '/pages/sal/SALSCO02900',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSCO02900.vue'
                    ) /* 판매 - 카드승인요청내역 */,
            },
            {
                path: '/pages/sal/SALSEL00103',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00103.vue'
                    ) /* 판매 - T판매 55번전문 팝업 */,
            },
            {
                path: '/pages/sal/SALSEL00100',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00100.vue'
                    ) /* 판매 - T판매관리 */,
            },
            {
                path: '/pages/sal/SALSEL00110',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00110.vue'
                    ) /* 판매 - T판매등록상세 팝업 */,
            },
            {
                path: '/pages/sal/SALSEL00111',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00111.vue'
                    ) /* 판매 - 보상매입정보 팝업 */,
            },
            {
                path: '/pages/sal/SALSEL00112',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00112.vue'
                    ) /* 판매 - 판매가정보 팝업 */,
            },
            {
                path: '/pages/sal/SALSEL00114',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00114.vue'
                    ) /* 판매 - D-Fax 관리이력 팝업 */,
            },
            {
                path: '/pages/sal/SALSEL00120',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00120.vue'
                    ) /* 판매 - T판매변경상세 팝업 */,
            },
            {
                path: '/pages/sal/SALSEL00130',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00130.vue'
                    ) /* 판매 - T판매변경 팝업 */,
            },
            {
                path: '/pages/sal/SALSEL00140',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00140.vue'
                    ) /* 판매 - T판매변경 기기교환사유팝업 */,
            },
            {
                path: '/pages/sal/SALSEL00160',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00160.vue'
                    ) /* 판매 - 판매매장 팝업 */,
            },
            {
                path: '/pages/sal/SALSEL00200',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00200.vue'
                    ) /* 판매 - T판매 P임대등록 팝업 */,
            },
            {
                path: '/pages/sal/SALSEL00500',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00500.vue'
                    ) /* 판매 - 디바이스판매상세 */,
            },
            {
                path: '/pages/sal/SALSEL00510',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSEL00510.vue'
                    ) /* 판매 - 스마트홈/디바이스판매 사용자취소 팝업 */,
            },
            {
                path: '/pages/sal/SALACO00100',
                component: () =>
                    import(
                        '@/views/pages/sal/SALACO00100.vue'
                    ) /* 판매 - 기타수납관리상세 팝업 */,
            },
            {
                path: '/pages/sal/SALACO00200',
                component: () =>
                    import(
                        '@/views/pages/sal/SALACO00200.vue'
                    ) /* 판매 - 소매매출수납관리 */,
            },
            {
                path: '/pages/sal/SALACO00300',
                component: () =>
                    import(
                        '@/views/pages/sal/SALACO00300.vue'
                    ) /* 판매 - 소매/위탁매출수납관리상세 */,
            },
            {
                path: '/pages/sal/SALACO01400',
                component: () =>
                    import(
                        '@/views/pages/sal/SALACO01400.vue'
                    ) /* 판매 - 소매현금일보 */,
            },
            {
                path: '/pages/sal/SALACO02900',
                component: () =>
                    import(
                        '@/views/pages/sal/SALACO02900.vue'
                    ) /* 판매 - BO매출수납관리 상세 팝업 */,
            },
            {
                path: '/pages/sal/SALACO03000',
                component: () =>
                    import(
                        '@/views/pages/sal/SALACO03000.vue'
                    ) /* 판매 - 현금영수증발행관리 */,
            },
            //{
            //path: '/pages/sal/SALACO03000_test',
            //component: () =>
            //import(
            //'@/views/pages/sal/SALACO03000_test.vue'
            //) /* 판매 - 현금영수증발행관리 */ ,
            //},
            {
                path: '/pages/sal/SALACO03010',
                component: () =>
                    import(
                        '@/views/pages/sal/SALACO03010.vue'
                    ) /* 판매 - 현금영수증 발행 이력 상세 팝업 */,
            },
            {
                path: '/pages/sal/SALACO03011',
                component: () =>
                    import(
                        '@/views/pages/sal/SALACO03011.vue'
                    ) /* 판매 - 현금영수증 수정발행 정보 입력 팝업 */,
            },
            {
                path: '/pages/sal/SALACO03020',
                component: () =>
                    import(
                        '@/views/pages/sal/SALACO03020.vue'
                    ) /* 판매 - 현금영수증 적정성관리 팝업 */,
            },
            {
                path: '/pages/sal/SALGNR00100',
                component: () =>
                    import(
                        '@/views/pages/sal/SALGNR00100.vue'
                    ) /* 판매 - 일반상품 판매현황 */,
            },
            {
                path: '/pages/sal/SALGNR00200',
                component: () =>
                    import(
                        '@/views/pages/sal/SALGNR00200.vue'
                    ) /* 판매 - 일반상품 판매관리 */,
            },
            {
                path: '/pages/sal/SALGNR00300',
                component: () =>
                    import(
                        '@/views/pages/sal/SALGNR00300.vue'
                    ) /* 판매 - 일반상품판매상세 */,
            },
            {
                path: '/pages/sal/SALGNR00310',
                component: () =>
                    import(
                        '@/views/pages/sal/SALGNR00310.vue'
                    ) /* 판매 - 일반상품판매 수탁상품일괄등록 팝업 */,
            },
            {
                path: '/pages/sal/SALGNR00320',
                component: () =>
                    import(
                        '@/views/pages/sal/SALGNR00320.vue'
                    ) /* 판매 - 일반상품판매엑셀업로드 팝업 */,
            },
            {
                path: '/pages/sal/SALGNR00400',
                component: () =>
                    import(
                        '@/views/pages/sal/SALGNR00400.vue'
                    ) /* 판매 - 일반상품판매일관판매등록 팝업 */,
            },
            {
                path: '/pages/sal/SALPAY00100',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY00100.vue'
                    ) /* 판매 - T수납대행관리 */,
            },
            {
                path: '/pages/sal/SALPAY00101',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY00101.vue'
                    ) /* 판매 - Swing I/F 수납자변경 팝업 */,
            },
            {
                path: '/pages/sal/SALPAY00200',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY00200.vue'
                    ) /* 판매 - T수납대행상세 팝업 */,
            },
            {
                path: '/pages/sal/SALPAY00210',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY00210.vue'
                    ) /* 판매 - T수납대행 수납변경 팝업 */,
            },
            {
                path: '/pages/sal/SALPAY00220',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY00220.vue'
                    ) /* 판매 - T수납대행 처리제외요청 팝업  */,
            },
            {
                path: '/pages/sal/SALPAY00300',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY00300.vue'
                    ) /* 판매 - T수납대행 현황 */,
            },
            {
                path: '/pages/sal/SALPAY00400',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY00400.vue'
                    ) /* 판매 - T수납대행 일괄등록 */,
            },
            {
                path: '/pages/sal/SALPAY00500',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY00500.vue'
                    ) /* 판매 - T수납대행 예수금등록 */,
            },
            {
                path: '/pages/sal/SALPAY00310',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY00310.vue'
                    ) /* 판매 - T수납대행 현황 상세 팝업 */,
            },
            {
                path: '/pages/sal/SALPAY00320',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY00320.vue'
                    ) /* 판매 - T수납대행 현황 전체상세 팝업 */,
            },
            {
                path: '/pages/sal/SALSCO01200',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSCO01200.vue'
                    ) /* 판매 - I/F 오류 확인 팝업창 */,
            },
            {
                path: '/pages/sal/SALSCO01900',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSCO01900.vue'
                    ) /* 판매 - 판매점관리현황 */,
            },
            {
                path: '/pages/sal/SALSCO02800',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSCO02800.vue'
                    ) /* 판매 - 카드승인 > 카드 결제 팝업 */,
            },
            {
                path: '/pages/sal/SALSCO02820',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSCO02820.vue'
                    ) /* 판매 - 카드단말기등록 */,
            },
            {
                path: '/pages/sal/SALSMG00600',
                component: () =>
                    import(
                        '@/views/pages/sal/SALSMG00600.vue'
                    ) /* 판매 - 판매현황상세 팝업 */,
            },
            {
                path: '/pages/sal/TKPUKI00800',
                component: () =>
                    import(
                        '@/views/pages/sal/TKPUKI00800.vue'
                    ) /* 판매 - ADT캡스 상세 팝업 */,
            },
            {
                path: '/pages/sal/SALPAY01000',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY01000.vue'
                    ) /* 판매 - 요금수납확인요청현황 조회 */,
            },
            {
                path: '/pages/sal/SALPAY01100',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY01100.vue'
                    ) /* 판매 - 요금수납확인요청 팝업 */,
            },
            {
                path: '/pages/sal/SALPAY01200',
                component: () =>
                    import(
                        '@/views/pages/sal/SALPAY01200.vue'
                    ) /* 판매 - 요금수납확인 팝업 */,
            },
            {
                path: '/pages/bas/BasBbsReg',
                component: () =>
                    import(
                        '@/views/pages/bas/BasBbsReg.vue'
                    ) /* 기준정보 - 도매게시판(단가표) 등록 팝업 */,
            },
            {
                path: '/pages/bas/BasBbsRegPop1',
                component: () =>
                    import(
                        '@/views/pages/bas/BasBbsRegPop1.vue'
                    ) /* 기준정보 - 대상매장등록_대상판매점 선택 팝업 */,
            },
            {
                path: '/pages/bas/BasBbsRegPop2',
                component: () =>
                    import(
                        '@/views/pages/bas/BasBbsRegPop2.vue'
                    ) /* 기준정보 - 대상매장등록_대상아이디 선택 팝업 */,
            },
            {
                path: '/pages/bas/BASBCO00600',
                component: () =>
                    import(
                        '@/views/pages/bas/BASBCO00600.vue'
                    ) /* 기준정보 - 상품색상검색 팝업 */,
            },
            {
                path: '/pages/bas/BASCDM00200',
                component: () =>
                    import(
                        '@/views/pages/bas/BASCDM00200.vue'
                    ) /* 기준정보 - 공통코드관리 */,
            },
            {
                path: '/pages/bas/BASOGM00200',
                component: () =>
                    import(
                        '@/views/pages/bas/BASOGM00200.vue'
                    ) /* 기준정보 - 조직관리 팝업 */,
            },
            {
                path: '/pages/bas/BASUM00400',
                component: () =>
                    import(
                        '@/views/pages/bas/BASUM00400.vue'
                    ) /* 기준정보 - 사용자관리 > 사용자 등록 */,
            },
            {
                path: '/pages/bas/BASBCO10180',
                component: () =>
                    import(
                        '@/views/pages/bas/BASBCO10180.vue'
                    ) /* 기준정보 - 유통단말기매핑관리 */,
            },
            {
                path: '/pages/bas/BASPRM00710',
                component: () =>
                    import(
                        '@/views/pages/bas/BASPRM00710.vue'
                    ) /* 기준정보 - 거래처등록 */,
            },
            {
                path: '/pages/bas/BASPRM02642',
                component: () =>
                    import(
                        '@/views/pages/bas/BASPRM02642.vue'
                    ) /* 기준정보 - 전자결재 전송 변경&담보 갱신 팝업 */,
            },
            {
                path: '/pages/bas/BASPRM2640',
                component: () =>
                    import(
                        '@/views/pages/bas/BASPRM2640.vue'
                    ) /* 기준정보 - 전자결재 전송 신규팝업 */,
            },
            {
                path: '/pages/bas/BASPRM2641',
                component: () =>
                    import(
                        '@/views/pages/bas/BASPRM2641.vue'
                    ) /* 기준정보 - 전자결재 전송 변경팝업 */,
            },
            {
                path: '/pages/bas/BASPRM2642',
                component: () =>
                    import(
                        '@/views/pages/bas/BASPRM2642.vue'
                    ) /* 기준정보 - 전자결재 전송 변경&담보 갱신 팝업 */,
            },
            {
                path: '/pages/bas/BASPRM2643',
                component: () =>
                    import(
                        '@/views/pages/bas/BASPRM2643.vue'
                    ) /* 기준정보 - 전자결재 전송 담보 갱신팝업 */,
            },
            {
                path: '/pages/bas/BASPRM2644',
                component: () =>
                    import(
                        '@/views/pages/bas/BASPRM2644.vue'
                    ) /* 기준정보 - 전자결재 전송 해지팝업 */,
            },
            {
                path: '/pages/bas/BASPRM2646',
                component: () =>
                    import(
                        '@/views/pages/bas/BASPRM2646.vue'
                    ) /* 기준정보 - 전자결재 전송 신규 제품의 팝업 */,
            },
            {
                path: '/pages/bas/BASUSM00440',
                component: () =>
                    import(
                        '@/views/pages/bas/BASUSM00440.vue'
                    ) /* 기준정보 - 사용자 현행화 팝업 */,
            },
            {
                path: '/pages/bas/BASUSM00442',
                component: () =>
                    import(
                        '@/views/pages/bas/BASUSM00442.vue'
                    ) /* 기준정보 - 사용자 정보 업데이트 팝업 */,
            },
            {
                path: '/pages/bas/BASUSERGRP',
                component: () =>
                    import(
                        '@/views/pages/bas/BASUSERGRP.vue'
                    ) /* 기준정보 - 메뉴권한 설정 팝업 */,
            },
            {
                path: '/pages/bas/BasPdmAgnProdMgmtNeW',
                component: () =>
                    import(
                        '@/views/pages/bas/BasPdmAgnProdMgmtNeW.vue'
                    ) /* 기준정보 - 운영상품관리 */,
            },
            {
                path: '/pages/bas/BasOgmOrgMgmt',
                component: () =>
                    import(
                        '@/views/pages/bas/BasOgmOrgMgmt.vue'
                    ) /* 기준정보 - 레이아웃 추가1(조직관리) */,
            },
            {
                path: '/pages/bas/BasAdmAuthMgmt',
                component: () =>
                    import(
                        '@/views/pages/bas/BasAdmAuthMgmt.vue'
                    ) /* 기준정보 - 레이아웃 추가2(권한관리) */,
            },
            {
                path: '/pages/bas/BasBbsMgmt',
                component: () =>
                    import(
                        '@/views/pages/bas/BasBbsMgmt.vue'
                    ) /* 기준정보 - 레이아웃 추가3(게시판) */,
            },
            {
                path: '/pages/bas/PersonalData',
                component: () =>
                    import(
                        '@/views/pages/bas/PersonalData.vue'
                    ) /* 기준정보 - 개인정보추출내역(팝업) */,
            },
            {
                path: '/pages/acc/ACCBOS00500',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCBOS00500.vue'
                    ) /* 정산 - 월)가상계좌입금내역 */,
            },
            {
                path: '/pages/acc/ACCDCL00120',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCDCL00120.vue'
                    ) /* 정산 - 일마감관리 */,
            },
            {
                path: '/pages/acc/ACCDCL00700',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCDCL00700.vue'
                    ) /* 정산 - 수납마감현황 */,
            },
            {
                path: '/pages/acc/ACCDCL00710',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCDCL00710.vue'
                    ) /* 정산 - 수납일마감 상세내역팝업 */,
            },
            {
                path: '/pages/acc/ACCDCL01400',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCDCL01400.vue'
                    ) /* 정산 - 수요금예수금비교검증 */,
            },
            {
                path: '/pages/acc/ACCMCL00200',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCMCL00200.vue'
                    ) /* 정산 - 조직별손익현황(원장기준) */,
            },
            {
                path: '/pages/acc/ACCPAC01910',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCPAC01910.vue'
                    ) /* 정산 - 위탁거래처SMS수신인선택 팝업 */,
            },
            {
                path: '/pages/acc/ACCPAC02300',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCPAC02300.vue'
                    ) /* 정산 - EDI 매출/입금 정산관리 */,
            },
            {
                path: '/pages/acc/ACCPAC02301',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCPAC02301.vue'
                    ) /* 정산 - EDI 매출/입금 정산관리2 */,
            },
            {
                path: '/pages/acc/ACCPAC03200',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCPAC03200.vue'
                    ) /* 정산 - 입금관리 > 수작업카드 입금정산관리 */,
            },
            {
                path: '/pages/acc/ACCPAC04000',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCPAC04000.vue'
                    ) /* 정산 - 입금관리 > 현금시재/채권조정관리 */,
            },
            {
                path: '/pages/acc/ACCPAD03100',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCPAD03100.vue'
                    ) /* 정산 - New 수작업카드입금정산엑셀업로드 팝업 */,
            },
            {
                path: '/pages/acc/ACCSAC00150',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC00150.vue'
                    ) /* 정산 - EDI 부가서비스해지환수 세부내역 */,
            },
            {
                path: '/pages/acc/ACCSAC00150_1',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC00150_1.vue'
                    ) /* 정산 - 유선판매수수료 정산관리 */,
            },
            {
                path: '/pages/acc/ACCSAC00150_222',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC00150_222.vue'
                    ) /* 정산 - 파일첨부(popup) */,
            },
            {
                path: '/pages/acc/ACCSAC00151',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC00151.vue'
                    ) /* 정산 - 유선 판매 수수료정산관리 세부내역 팝업 */,
            },
            {
                path: '/pages/acc/ACCSAC00152',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC00152.vue'
                    ) /* 정산 - 유선 수수료 가감 엑셀업로드 팝업 */,
            },
            {
                path: '/pages/acc/ACCSAC00153',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC00153.vue'
                    ) /* 정산 - 유선 판매수수료정산관리 팝업 */,
            },
            {
                path: '/pages/acc/ACCSAC00154',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC00154.vue'
                    ) /* 정산 - 유선수수료가감 팝업 */,
            },
            {
                path: '/pages/acc/ACCSAC00155',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC00155.vue'
                    ) /* 정산 - 유선정산상계 팝업 */,
            },
            {
                path: '/pages/acc/ACCSAC00180',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC00180.vue'
                    ) /* 정산 - 신품자급 USIM후불예수금 기준관리 */,
            },
            {
                path: '/pages/acc/ACCSAC00400',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC00400.vue'
                    ) /* 정산 - 통합판매수수료정산관리 */,
            },
            {
                path: '/pages/acc/ACCSAC00800',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC00800.vue'
                    ) /* 정산 - CIA미비 환수관리 */,
            },
            {
                path: '/pages/acc/ACCSAC02500',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC02520.vue'
                    ) /* 정산 - 판매수수료 선지급 관리 */,
            },
            {
                path: '/pages/acc/ACCSAC02520',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC02500.vue'
                    ) /* 정산 - 판매수수료 선지급 검증관리 */,
            },
            {
                path: '/pages/acc/ACCSAC02600',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC02600.vue'
                    ) /* 정산 - 정산거래서 휴폐업상태관리 */,
            },
            {
                path: '/pages/acc/ACCSAC02720',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC02720.vue'
                    ) /* 정산 - 정산지원게시판 상세보기 팝업 */,
            },
            {
                path: '/pages/acc/ACCSAC02721',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC02721.vue'
                    ) /* 정산 - 정산지원게시판 상세보기 팝업_Type2 */,
            },
            {
                path: '/pages/acc/ACCSAC02740',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSAC02740.vue'
                    ) /* 정산 - 정산지원게시판 답변등록 팝업 */,
            },
            {
                path: '/pages/acc/ACCSSS00250',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSSS00250.vue'
                    ) /* 정산 - SKT인센티브정산관리 */,
            },
            {
                path: '/pages/acc/ACCSSS00310',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSSS00310.vue'
                    ) /* 정산 - SKT수수료정산등록 팝업 */,
            },
            {
                path: '/pages/acc/ACCSSS00610',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSSS00610.vue'
                    ) /* 정산 - 관계사채권채무현황<전사>상세 팝업 */,
            },
            {
                path: '/pages/acc/ACCSSS00910',
                component: () =>
                    import(
                        '@/views/pages/acc/ACCSSS00910.vue'
                    ) /* 정산 - SKB수수료/인센티브정산관리>엑셀업로드 팝업 */,
            },
            {
                path: '/pages/acc/RMTACC00100',
                component: () =>
                    import(
                        '@/views/pages/acc/RMTACC00100.vue'
                    ) /* 정산 - 도매정산>정산 Report */,
            },
            {
                path: '/pages/acc/RMTACC00110',
                component: () =>
                    import(
                        '@/views/pages/acc/RMTACC00110.vue'
                    ) /* 정산 - 도매정산>정산 Report > 정산 Report 파일업로드 */,
            },
            {
                path: '/pages/acc/RMTACC00130',
                component: () =>
                    import(
                        '@/views/pages/acc/RMTACC00130.vue'
                    ) /* 정산 - 도매정산>정산 Report > 정산 Report 공지사항 및 비고관리 팝업 */,
            },
            {
                path: '/pages/acc/SACRFD00200',
                component: () =>
                    import(
                        '@/views/pages/acc/SACRFD00200.vue'
                    ) /* 정산 - 조직별오입금환불관리 */,
            },
            {
                path: '/pages/acc/SACRFD00210',
                component: () =>
                    import(
                        '@/views/pages/acc/SACRFD00210.vue'
                    ) /* 정산 - 조직별오입금환불관리 > 환불처리 팝업 */,
            },
            {
                path: '/pages/acc/SALSCO02910',
                component: () =>
                    import(
                        '@/views/pages/acc/SALSCO02910.vue'
                    ) /* 정산 - 현금영수증 내역 */,
            },
            {
                path: '/pages/acc/SALSCO02920',
                component: () =>
                    import(
                        '@/views/pages/acc/SALSCO02920.vue'
                    ) /* 정산 - 현금영수증 내역 > 카드결제 팝업 */,
            },
            {
                path: '/pages/acc/SALSMG00700',
                component: () =>
                    import(
                        '@/views/pages/acc/SALSMG00700.vue'
                    ) /* 정산 - 영업기초DATA관리 */,
            },
            {
                path: '/pages/acc/TAXPRM00230',
                component: () =>
                    import(
                        '@/views/pages/acc/TAXPRM00230.vue'
                    ) /* 정산 - 조통합판매 수수료 정산관리 파일첨부 팝업 */,
            },
            {
                path: '/pages/acc/AccSacWlessSaleCmmsAccMgmtJeongsan',
                component: () =>
                    import(
                        '@/views/pages/acc/AccSacWlessSaleCmmsAccMgmtJeongsan.vue'
                    ) /* 정산 - 판매수수료 정산 세부내역 팝업 */,
            },
            {
                path: '/pages/pol/POLICT00110',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00110.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)메인정책_기본단가정책_그레이드미적용 */,
            },
            {
                path: '/pages/pol/POLICT00110_1',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00110_1.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)메인정책_기본단가정책_그레이드적용 */,
            },
            {
                path: '/pages/pol/POLICT00120',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00120.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)메인정책_서비스별단가정책_그레이드미적용 */,
            },
            {
                path: '/pages/pol/POLICT00120_1',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00120_1.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)메인정책_서비스별단가정책_그레이드적용 */,
            },
            {
                path: '/pages/pol/POLICT00130',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00130.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)메인정책_VAS정책_그레이드미적용 */,
            },
            {
                path: '/pages/pol/POLICT00130_1',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00130_1.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)메인정책_VAS단가정책_그레이드적용 */,
            },
            {
                path: '/pages/pol/POLICT00140',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00140.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)메인정책_요금제정책_그레이드미적용 */,
            },
            {
                path: '/pages/pol/POLICT00150',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00150.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)메인정책_파일업로드 */,
            },
            {
                path: '/pages/pol/POLICT00112',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00112.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)대상-정책그룹 */,
            },
            {
                path: '/pages/pol/POLICT00112_1',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00112_1.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)대상-정책그룹 */,
            },
            {
                path: '/pages/pol/POLICT00112_2',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00112_2.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)대상-개별매장 */,
            },
            {
                path: '/pages/pol/POLICT00113',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00113.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)단말조건 */,
            },
            {
                path: '/pages/pol/POLICT00114',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00114.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)서비스조건 */,
            },
            {
                path: '/pages/pol/POLICT00115',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00115.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)요금제조건 */,
            },
            {
                path: '/pages/pol/POLICT00116',
                component: () =>
                    import(
                        '@/views/pages/pol/POLICT00116.vue'
                    ) /* 정책 - 인센티브정책상세_(tab)부가조건 */,
            },
            {
                path: '/pages/pol/POLSTD01300',
                component: () =>
                    import(
                        '@/views/pages/pol/POLSTD01300.vue'
                    ) /* 정책 - T영업일수관리 */,
            },
            {
                path: '/pages/pol/REQ2-004',
                component: () =>
                    import(
                        '@/views/pages/pol/REQ2-004.vue'
                    ) /* B정책 > 유선정책 > 유선인센티브 정책_(tab)메인정책 */,
            },
            {
                path: '/pages/pol/REQ2-005',
                component: () =>
                    import(
                        '@/views/pages/pol/REQ2-005.vue'
                    ) /* B정책 > 유선정책 > 유선인센티브 정책_(tab)대상 */,
            },
            {
                path: '/pages/pol/REQ2-006',
                component: () =>
                    import(
                        '@/views/pages/pol/REQ2-006.vue'
                    ) /* B정책 > 유선정책 > 유선인센티브 정책_(tab)무선조건 */,
            },
            {
                path: '/pages/pol/REQ2-007',
                component: () =>
                    import(
                        '@/views/pages/pol/REQ2-007.vue'
                    ) /* B정책 > 유선정책 > 유선인센티브 정책_(tab)유선조건 */,
            },
            {
                path: '/pages/sac/SACSAP00310',
                component: () =>
                    import(
                        '@/views/pages/sac/SACSAP00310.vue'
                    ) /* 판매회계 - 매출원장상세 팝업 */,
            },
            {
                path: '/pages/sac/SACSAP00410',
                component: () =>
                    import(
                        '@/views/pages/sac/SACSAP00410.vue'
                    ) /* 판매회계 - 매입원장상세 팝업 */,
            },
            {
                path: '/pages/sac/SACSAP01020',
                component: () =>
                    import(
                        '@/views/pages/sac/SACSAP01020.vue'
                    ) /* 판매회계 - 매출조정 팝업 */,
            },
            {
                path: '/pages/sac/SACSAP01200',
                component: () =>
                    import(
                        '@/views/pages/sac/SACSAP01200.vue'
                    ) /* 판매회계 - 매입조정요청관리 */,
            },
            {
                path: '/pages/sac/SACSAP01210',
                component: () =>
                    import(
                        '@/views/pages/sac/SACSAP01210.vue'
                    ) /* 판매회계 - 매입조정 팝업 */,
            },
            {
                path: '/pages/tax/TAXCUS00100',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXCUS00100.vue'
                    ) /* 판매회계 - 고객세금계산서발행 팝업 */,
            },
            {
                path: '/pages/tax/TAXCUS00110',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXCUS00110.vue'
                    ) /* 판매회계 - 고객세금계산서발행정보입력 팝업 */,
            },
            {
                path: '/pages/tax/TAXCUS00120',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXCUS00120.vue'
                    ) /* 판매회계 - 고객세금계산서발행요청상세 팝업 */,
            },
            {
                path: '/pages/tax/TAXCUS00130',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXCUS00130.vue'
                    ) /* 판매회계 - 타전산매출세금계산서발행정보입력-고객 팝업 */,
            },
            {
                path: '/pages/tax/TAXCUS00140',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXCUS00140.vue'
                    ) /* 판매회계 - 고객세금계산서발행상세정보 팝업 */,
            },
            {
                path: '/pages/tax/TAXCUS00220',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXCUS00220.vue'
                    ) /* 판매회계 - 고객세금계산서수정정보입력 팝업 */,
            },
            {
                path: '/pages/tax/TAXPRM00200',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXPRM00200.vue'
                    ) /* 판매회계 - 거래처 세금계산서발행-매출(정발행) */,
            },
            {
                path: '/pages/tax/TAXPRM00210',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXPRM00210.vue'
                    ) /* 판매회계 - 거래처 세금계산서발행 상세 팝업 */,
            },
            {
                path: '/pages/tax/TAXPRM00220',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXPRM00220.vue'
                    ) /* 판매회계 - 거래처 세금계산서발행 정보입력 팝업 */,
            },
            {
                path: '/pages/tax/TAXPRM00231',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXPRM00231.vue'
                    ) /* 판매회계 - 타전산 매출세금계산서 발행내역 팝업 */,
            },
            {
                path: '/pages/tax/TAXPRM00300',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXPRM00300.vue'
                    ) /* 판매회계 - 거래처 세금계산서발행-매입(역발행) */,
            },
            {
                path: '/pages/tax/TAXPRM00410',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXPRM00410.vue'
                    ) /* 판매회계 - 거래처 세금계산서발행 수정정보입력 팝업 */,
            },
            {
                path: '/pages/tax/TAXPRM00610',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXPRM00610.vue'
                    ) /* 판매회계 - 거래처 세금계산서발행 상세정보 팝업 */,
            },
            {
                path: '/pages/tax/TAXPRM00710',
                component: () =>
                    import(
                        '@/views/pages/tax/TAXPRM00710.vue'
                    ) /* 판매회계 - 세금계산서발행(역발행) */,
            },
            {
                path: '/pages/rm/ACCCRD02101',
                component: () =>
                    import(
                        '@/views/pages/rm/ACCCRD02101.vue'
                    ) /* RM - 소매Quick 사용확인서 */,
            },
            {
                path: '/pages/rm/ACCMGN00720',
                component: () =>
                    import(
                        '@/views/pages/rm/ACCMGN00720.vue'
                    ) /* RM - CS Target Offering 등록팝업 */,
            },
            {
                path: '/pages/rm/RMTBAS00410',
                component: () =>
                    import(
                        '@/views/pages/rm/RMTBAS00410.vue'
                    ) /* RM - 조직별 CIA 미비관리 */,
            },
            {
                path: '/pages/rm/SALACO01100',
                component: () =>
                    import(
                        '@/views/pages/rm/SALACO01100.vue'
                    ) /* RM - 현금/단말기 등 보관확인서 */,
            },
            {
                path: '/pages/rm/SALACO01300',
                component: () =>
                    import(
                        '@/views/pages/rm/SALACO01300.vue'
                    ) /* RM - 매장별일마감관리 */,
            },
            {
                path: '/pages/rm/SALACO01400',
                component: () =>
                    import(
                        '@/views/pages/rm/SALACO01400.vue'
                    ) /* RM - etc type */,
            },
        ],
    },
    /** 모바일 페이지 시작 */
    {
        path: '/pages/mobile/home/MblQuickSearch',
        component: () =>
            import(
                '@/views/pages/mobile/home/MblQuickSearch'
            ) /* 퀵서치 팝업 */,
    },
    {
        path: '/pages/mobile',
        name: '/pages/mobile',
        component: MblLayout,
        redirect: '/pages/mobile/home/MblMain',
        children: [
            {
                path: '/pages/mobile/home/MblMain',
                component: () =>
                    import(
                        '@/views/pages/mobile/home/MblMain'
                    ) /* 모바일-메인 */,
                meta: {
                    menuNm: 'T.key-taka',
                    menuNo: '0001',
                    screenId: 'SC0001',
                },
            },
            {
                path: '/pages/mobile/home/MblMenu',
                component: () =>
                    import(
                        '@/views/pages/mobile/home/MblMenu'
                    ) /* 모바일-메뉴 */,
                meta: {
                    menuNm: '메뉴',
                    menuNo: '0002',
                    screenId: 'SC0002',
                },
            },
            {
                path: '/pages/mobile/home/MblMyMenu',
                component: () =>
                    import(
                        '@/views/pages/mobile/home/MblMyMenu'
                    ) /* 나의메뉴설정 */,
                meta: {
                    menuNm: '나의 메뉴 설정',
                    menuNo: '0003',
                    screenId: 'SC0003',
                },
            },
            {
                path: '/pages/mobile/home/MblErrorPage',
                component: () =>
                    import(
                        '@/views/pages/mobile/home/MblErrorPage'
                    ) /* 에러페이지 */,
                meta: {
                    menuNm: '에러페이지',
                    menuNo: '0004',
                    screenId: 'SC0004',
                },
            },
            {
                path: '/pages/mobile/dis/MblDis01',
                component: () =>
                    import(
                        '@/views/pages/mobile/dis/MblDis01'
                    ) /* 서브-SK네트웍스 입고 */,
                meta: {
                    menuNm: 'SK네트웍스 입고',
                    menuNo: '0005',
                    screenId: 'SC0005',
                },
            },
            {
                path: '/pages/mobile/dis/MblDis02',
                component: () =>
                    import(
                        '@/views/pages/mobile/dis/MblDis02'
                    ) /* 서브-SK네트웍스 입고검색 */,
                meta: {
                    menuNm: '입고 검색',
                    menuNo: '0006',
                    screenId: 'SC0006',
                },
            },
            {
                path: '/pages/mobile/bas/bbs/MblBasBbs01',
                component: () =>
                    import(
                        '@/views/pages/mobile/bas/bbs/MblBasBbs01'
                    ) /* 서브-공지사항(View) */,
                meta: {
                    menuNm: '대리점 공지사항',
                    menuNo: '0007',
                    screenId: 'SC0007',
                },
            },
            {
                path: '/pages/mobile/bas/bbs/MblBasBbs02',
                component: () =>
                    import(
                        '@/views/pages/mobile/bas/bbs/MblBasBbs02'
                    ) /* 서브-공지사항 리스트1 */,
                meta: {
                    menuNm: '공지사항',
                    menuNo: '0008',
                    screenId: 'SC0008',
                },
            },
            {
                path: '/pages/mobile/bas/bbs/MblBasBbs03',
                component: () =>
                    import(
                        '@/views/pages/mobile/bas/bbs/MblBasBbs03'
                    ) /* 서브-공지사항 리스트2 */,
                meta: {
                    menuNm: '공지사항',
                    menuNo: '0009',
                    screenId: 'SC0009',
                },
            },
            {
                path: '/pages/mobile/bas/bbs/MblBasBbs04',
                component: () =>
                    import(
                        '@/views/pages/mobile/bas/bbs/MblBasBbs04'
                    ) /* 서브-글쓰기 */,
                meta: {
                    menuNm: '글올리기',
                    menuNo: '0010',
                    screenId: 'SC0010',
                },
            },
            {
                path: '/pages/mobile/bas/bbs/MblBasBbs05',
                component: () =>
                    import(
                        '@/views/pages/mobile/bas/bbs/MblBasBbs05'
                    ) /* 서브-글수정 */,
                meta: {
                    menuNm: '글수정',
                    menuNo: '0011',
                    screenId: 'SC0011',
                },
            },
            {
                path: '/pages/mobile/sal/MblSal01',
                component: () =>
                    import(
                        '@/views/pages/mobile/sal/MblSal01'
                    ) /* 서브- 판매 > T판매세부내역 */,
                meta: {
                    menuNm: 'T판매세부내역',
                    menuNo: '0012',
                    screenId: 'SC0012',
                },
            },
            {
                path: '/pages/mobile/sal/MblSal02',
                component: () =>
                    import(
                        '@/views/pages/mobile/sal/MblSal02'
                    ) /* 서브- 판매 > T판매세부내역_그리드 */,
                meta: {
                    menuNm: 'T판매세부내역',
                    menuNo: '0013',
                    screenId: 'SC0013',
                },
            },
        ],
    },
]

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch((err) => {
        if (err.name !== 'NavigationDuplicated') throw err
    })
}

export default routes
