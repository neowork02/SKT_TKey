<template>
    <div class="div5_5 cont1-1 right pl0">
        <TCRealGridHeader
            id="authMgmtGridHeader2"
            ref="authMgmtGridHeader2"
            gridTitle="미매핑목록"
            :gridObj="gridObj"
            :isPageRows="false"
            :isExceldown="false"
            :isNextPage="false"
            :isPageCnt="false"
            :editable="false"
            :isAddRow="false"
            :isDelRow="false"
            :addData="this.addData"
            @excelDownBtn="this.excelDownBtn"
            @addRowBtn="this.gridAddRowBtn"
            @chkDelRowBtn="this.gridchkDelRowBtn"
        >
            <!-- TCRealGridHeader 영역에 인풋, 체크박스,데이터피커 컴포넌트 추가될 경우_오른쪽 -->
            <template #gridElementArea>
                <TCComInput
                    v-model="searchWord"
                    labelName="검색"
                    :objAuth="objAuth"
                    @enterKey="onEnterKey"
                ></TCComInput>
            </template>
            <!-- //TCRealGridHeader 영역에 인풋, 체크박스,데이터피커 컴포넌트 추가될 경우_오른쪽 -->
        </TCRealGridHeader>
        <TCRealGrid
            id="authMgmtGrid2"
            ref="authMgmtGrid2"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle"
        />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/authMgmt/helpers'
import { CommonGrid } from '@/utils'
import CommonMsg from '@/utils/CommonMsg'
import moment from 'moment'
import _ from 'lodash'
import { M_HEADER2 } from '@/const/grid/bas/adm/basAdmAuthMgmtHeader'
import CommonMixin from '@/mixins'

export default {
    mixins: [CommonMixin],
    name: 'TableContainer2',
    components: {},
    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '455px', //그리드 높이 조절
            },
            objAuth: {},
            view: M_HEADER2,
            layout: [
                'origin',
                'chk', //체크
                'userNm', //사용자명
                'userId', //사용자아이디
                'userGrpCd', //사용자그룹코드
                'authTypCd',
                'orgClCd',
                'orgNm',
                'portalUserId',
                'serNo',
            ],
            addData: [],
            //행추가,수정시 필수 입력 컬럼
            requiredCols: [],
            gridOnClick: '',
            popupRowIndex: '',
            searchWord: '',
        }
    },
    async mounted() {
        this.gridObj = this.$refs.authMgmtGrid2
        this.gridHeaderObj = this.$refs.authMgmtGridHeader2
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.setGridState(false, false, false, false)
        //체크바
        this.$refs.authMgmtGrid2.gridView.setCheckBar({
            visible: true,
        })
        this.$refs.authMgmtGrid2.gridView.checkBar.fieldName = 'chk'

        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.gridView.displayOptions.selectionStyle = 'singleRow' //'rows'
        this.$refs.authMgmtGrid2.gridView.onCellDblClicked = (
            grid,
            clickData
        ) => {
            if (clickData.dataRow >= 0) {
                this.gridObj.dataProvider.setValue(
                    clickData.dataRow,
                    'chk',
                    true
                )
                this.gridObj.gridView.commit()
                this.defaultAssign_({
                    key: 'moveStore',
                    value: 'add',
                })
                grid.clearCurrent()
            }
        }
    },
    computed: {
        ...serviceComputed,
        data1: {
            get() {
                return this.$data
            },
        },
        resultList1: {
            get() {
                return this.resultListAll
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        saveAction1: {
            get() {
                return this.saveAction
            },
        },
        moveStore1: {
            get() {
                return this.moveStore
            },
        },
    },
    methods: {
        ...serviceMethods,
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.GridSetData()
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, 30, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        excelDownBtn: function () {
            this.gridHeaderObj.exportGrid(
                `미매핑목록_${moment(new Date()).format('YYYYMMDDHHmmss')}.xls`
            )
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            //Grid Row 가져올때 페이지정보 Setting
            console.log(
                '🚀 ~ file: TableContainer.vue ~ line 129 ~ SetPaging ~ paging',
                this.paging
            )
            this.gridHeaderObj.setPageCount(this.paging)
        },
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        gridAddRowBtn: function () {
            this.gridData.gridRows = this.gridHeaderObj.addRow(
                this.gridData.gridRows
            )
            let focuscell = this.gridObj.gridView.getCurrent()
            console.log(focuscell)
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)
        },
        gridDelRowBtn: function () {
            // one select line delete
            // @selDelRow="gridDelRowBtn"
            console.log('del current row')
            this.gridData.gridRows = this.gridHeaderObj.selDelRow()
        },
        gridchkDelRowBtn: function () {
            // Checked Row Delete Event
            //@chkDelRowBtn="gridchkDelRowBtn"
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
        },

        errorCellFocus(chkCell, message) {
            this.toasting_({
                message: message,
            })
            //cell focus : { index: -1, fieldName: '' }
            this.gridObj.validationChkGrid(chkCell)
        },
        validationCheck() {
            let index = this.gridObj.modifyGrid() //변경한 행 index 가져오기
            var chk = { index: -1, fieldName: '' }
            if (index.length) {
                for (var i = 0; i < index.length; i++) {
                    var row = this.gridObj.dataProvider.getJsonRow(
                        index[i],
                        true
                    )

                    if (
                        row.__rowState == 'created' ||
                        row.__rowState == 'updated'
                    ) {
                        //필수 입력 체크
                        if (this.requiredCols.length) {
                            // created(추가) / updated(수정) 인경우 필수입력항목 체크
                            for (var j = 0; j < this.requiredCols.length; j++) {
                                //필수입력항목이 누락된경우
                                if (!row[this.requiredCols[j]]) {
                                    chk.index = index[i]
                                    chk.fieldName = this.requiredCols[j]

                                    this.errorCellFocus(
                                        chk,
                                        this.gridObj.gridView.columnByField(
                                            chk.fieldName
                                        ).header.text + ' 필수 입력 입니다.'
                                    )
                                    return false
                                }
                            }
                        }
                    }
                }
            } else {
                if (!this.gridData.delRows.length) {
                    return false
                }
            }

            return true
        },

        async moveData() {
            let saveRows = []
            for (let i = 0; i < this.resultList.length; i++) {
                saveRows.push({
                    ...this.resultList[i],
                })
            }

            for (let i = 0; i < this.gridData.delRows.length; i++) {
                let e = this.gridData.delRows[i]
                saveRows.push({
                    ...e,
                })
            }
            await this.defaultAssign_({
                key: 'resultList',
                value: saveRows,
            })

            let otherData = this.gridObj.dataProvider.getJsonRows()
            this.gridObj.dataProvider.clearRows()
            this.gridData = this.GridSetData()
            await this.defaultAssign_({
                key: 'resultListAll',
                value: otherData,
            })
        },

        onEnterKey() {
            if (_.isEmpty(this.resultList1)) return
            let startIndex =
                (this.gridObj.gridView.getCurrent().itemIndex + 1) %
                this.gridObj.gridView.getItemCount()
            if (
                this.gridObj.gridView.getCurrent().itemIndex ==
                this.gridObj.gridView.getItemCount() - 1
            )
                startIndex = 0

            let found = this.searchItem(startIndex)
            if (startIndex != 0 && !found) {
                found = this.searchItem(0)
            }
            if (!found) {
                this.showTcComSnackbar('검색 해당 건이 없습니다.')
            }
        },

        searchItem(startIndex) {
            const leng1 = this.gridObj.dataProvider.getJsonRows().length
            const rows1 = this.gridObj.dataProvider.getJsonRows()
            for (let i = startIndex; i < leng1; i++) {
                let val1 = rows1[i].userNm
                if (val1.includes(this.searchWord)) {
                    this.gridObj.gridView.setCurrent({ itemIndex: i })
                    return true
                }
            }
            return false
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        resultList1(val, oldVal) {
            this.gridObj.dataProvider.clearRows()
            this.gridObj.setRows(this.resultList1)

            //신규 row 상태값 변경
            let arr1 = this.gridObj.dataProvider.getJsonRows()
            for (let j = 0; j < arr1.length; j++) {
                if (arr1[j].chk == 'true') {
                    this.gridObj.dataProvider.setValue(j, 'userGrpCd', null)
                    this.gridObj.dataProvider.setRowState(j, 'updated', false) //updated
                }
            }
            this.gridObj.gridView.commit()
        },
        // eslint-disable-next-line no-unused-vars
        paging1(val, oldVal) {
            this.SetPaging()
        },
        async saveAction1(val, oldVal) {
            if (val == true) {
                console.log('saveAction1: ', val, oldVal)
                this.gridObj.gridView.commit()

                console.log(
                    '변경 데이타',
                    this.gridObj.modifyGrid(), // 추가/수정 건 체크
                    this.gridData.delRows
                )

                if (this.validationCheck()) {
                    await this.saveData()
                } else {
                    console.log('validation false')
                }

                //temp 임시로 두개의 saveAction 이 있다고 간주
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: true,
                })
            }
        },
        // eslint-disable-next-line no-unused-vars
        async moveStore1(val, oldVal) {
            if (val == 'add') {
                this.gridchkDelRowBtn()
                await this.moveData()
                await this.defaultAssign_({
                    key: 'moveStore',
                    value: '',
                })
            }
        },
    },
}
</script>

<style scoped></style>
