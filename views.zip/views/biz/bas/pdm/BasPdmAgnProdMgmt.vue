<template>
    <div class="content">
        <!-- Tit -->
        <h1>대리점별 운영상품관리</h1>
        <!-- // Tit -->

        <!-- Top BTN -->
        <ul class="btn_area top">
            <!-- 왼쪽 버튼 : 불필요 할 경우 삭제 -->
            <!-- //왼쪽 버튼  -->
            <!-- 오른쪽 버튼 -->
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                    >조회</TCComButton
                >
                <TCComButton color="btn2" eClass="btn_ty01" @click="onSave"
                    >저장</TCComButton
                >
            </li>
            <!-- //오른쪽 버튼 -->
        </ul>
        <!-- // Top BTN -->

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00010"
                        labelName="상품구분"
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        v-model="forms.prodClCd"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        @change="prodClCdChange"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="단말기구분"
                        codeId="ZBAS_C_00500"
                        v-model="forms.eqpClCd"
                        :objAuth="this.objAuth"
                        :disabled="basProdMgmtDis.eqpClCd"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                    <!-- :filterFunc="filterEqpClCd" 단말기구분 필터, 일단 주석 -->
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="모델명"
                        v-model="forms.prodNm"
                        :objAuth="this.objAuth"
                        @enterKey="searchBtn"
                    ></TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="forms.mfactNm"
                        :codeVal.sync="forms.mfactCd"
                        labelName="제조사"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onOutDealEnterKey"
                        @appendIconClick="onOutDealIconClick"
                        @input="onOutDealInput"
                    />
                    <BasBcoOutDealsPopup
                        v-if="showBcoOutDeals"
                        :parentParam="searchOutDealParam"
                        :rows="resultOutDealRows"
                        :dialogShow.sync="showBcoOutDeals"
                        @confirm="onOutDealReturnData"
                    />
                </div>
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="D"
                        v-model="inputValue"
                        labelName="출시일자"
                        :eRequired="false"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="단종여부"
                        v-model="forms.endYn"
                        :objAuth="this.objAuth"
                        :itemList="this.Yn"
                        itemText="codeNm"
                        itemValue="codeId"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>-->
            <!-- //Search_line 2 -->
        </div>
        <!-- //Search_div -->

        <div class="contBoth">
            <!-- left area -->
            <div class="div5_5 cont1-1 left">
                <!-- gridWrap -->
                <TCRealGridHeader
                    id="gridHeader1"
                    ref="gridHeader1"
                    gridTitle="운영상품 목록"
                    :gridObj="gridObj1"
                    :isPageRows="true"
                    :isExceldown="true"
                    @excelDownBtn="this.includeDownload"
                >
                </TCRealGridHeader>
                <TCRealGrid
                    id="grid1"
                    ref="grid1"
                    :editable="true"
                    :movable="false"
                    :columnMovable="false"
                    :fields="view1.fields"
                    :columns="view1.columns"
                    :styles="gridStyle"
                />
                <!-- //gridWrap -->
            </div>
            <!-- //left area -->

            <!-- arrow area -->
            <div class="div5_5 cont3">
                <ul class="btnOrder">
                    <li>
                        <button
                            type="button"
                            class="btnOrderleft"
                            @click="onClickLeftBtn"
                        >
                            <span class="blind">left</span>
                        </button>
                    </li>
                    <li>
                        <button
                            type="button"
                            class="btnOrderright"
                            @click="onClickRightBtn"
                        >
                            <span class="blind">right</span>
                        </button>
                    </li>
                </ul>
            </div>
            <!-- //arrow area -->

            <!-- right area -->
            <div class="div5_5 cont1-1 right pl0">
                <!-- gridWrap -->
                <TCRealGridHeader
                    id="gridHeader2"
                    ref="gridHeader2"
                    gridTitle="미운영상품 목록"
                    :gridObj="gridObj2"
                    :isExceldown="true"
                    @excelDownBtn="this.excludeDownload"
                >
                </TCRealGridHeader>
                <TCRealGrid
                    id="grid2"
                    ref="grid2"
                    :editable="true"
                    :movable="false"
                    :columnMovable="false"
                    :fields="view2.fields"
                    :columns="view2.columns"
                    :styles="gridStyle"
                />
                <!-- //gridWrap -->
            </div>
            <!-- //right area -->
        </div>
        <!-- Dialog -->
        <basPdmProdBrwsMgmtPopup
            v-if="localDialogShow === true"
            ref="popup"
            :dialogShow.sync="localDialogShow"
            :parentParam="searchPopParam"
        />
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
import { PROD_HEADER } from '@/const/grid/bas/pdm/basPdmAgnProdHeader'
import attachedFileApi from '@/api/common/attachedFile'
import {
    BasPdmProdBrwsMgmtParam,
    BasProdMgmtDis,
} from '@/api/biz/bas/pdm/basPdmProdBrwsMgmtParam'
import CommonMixin from '@/mixins'
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//====================//외부거래처(제조사,매입처,배송사 등) 팝업====================
//====================상품팝업====================
import BasPdmProdBrwsMgmtPopup from '@/views/biz/bas/pdm/BasPdmProdBrwsMgmtPopup'
//====================//상품팝업==================
import basPdmAgnProdReg from '@/api/biz/bas/pdm/basPdmAgnProdReg'
import _ from 'lodash'
export default {
    name: 'Home',
    components: { BasBcoOutDealsPopup, BasPdmProdBrwsMgmtPopup },
    mixins: [CommonMixin],

    /*name: "disabled_dates",
  components: { DateRangePicker },*/

    data() {
        return {
            forms: new BasPdmProdBrwsMgmtParam(),
            basProdMgmtDis: new BasProdMgmtDis(),
            gridObj1: {},
            gridObj2: {},
            objAuth: {
                screenNo: this.$route.meta.breadcrumb,
            },
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '2X', // 거래처그룹
                dealcoClCd1: '20', // 거래처구분
            },
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================

            inputValue: '',
            gridData1: new CommonGrid('', '', '', ''),
            gridData2: new CommonGrid('', '', '', ''),
            codeIDView: true,
            codeIDViewVal: '',
            value1: '',
            value2: '',
            list01: [],
            list02: [],
            view1: PROD_HEADER,
            view2: PROD_HEADER,
            delRow: [],
            addRow: [],
            basProdAddList: [],
            basProdDelList: [],
            finalParam: {},
            searchPopParam: {
                prod_cd: '', // 상품코드
            },
            localDialogShow: false,
            checkbox: true,
            radio1: null,
            radios: null,
            options: [
                {
                    value: 'Option1',
                    label: 'Option1',
                },
                {
                    value: 'Option2',
                    label: 'Option2',
                    disabled: true,
                },
                {
                    value: 'Option3',
                    label: 'Option3',
                },
                {
                    value: 'Option4',
                    label: 'Option4',
                },
                {
                    value: 'Option5',
                    label: 'Option5',
                },
            ],
            items: ['Option1', 'Option2', 'Option3', 'Option4'],
            switch1: true,
            switch2: false,
            value: '',
            Yn: [
                {
                    codeId: 'Y',
                    codeNm: 'Y',
                },
                {
                    codeId: 'N',
                    codeNm: 'N',
                },
            ],
            gridStyle: {
                height: '455px', //그리드 높이 조절
            },
            gridStyle2: {
                height: '478px', //그리드 높이 조절
            },
            /*dateRange: {
        startDate: "",
        endDate: "",
      },*/
        }
    },
    mounted() {
        this.gridObj1 = this.$refs.grid1
        this.gridObj2 = this.$refs.grid2

        /*
         * indicatorBl  : 인디게이터 사용여부
         * stateBarBl   : 상태바 사용여부
         * checkBarBl   : 체크바 사용여부
         * footerBl     : Footer 사용여부
         */
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj1.setGridState(false, false, true, false)
        this.gridObj2.setGridState(false, false, true, false)
        this.gridObj1.gridView.checkBar.fieldName = 'chk'
        this.gridObj2.gridView.checkBar.fieldName = 'chk'
        this.gridObj2.gridView.onCellDblClicked = (grid, clickData) => {
            if (_.isEqual(clickData.cellType, 'data')) {
                this.gridObj2.dataProvider.setValue(
                    clickData.dataRow,
                    'chk',
                    true
                )
                this.onClickLeftBtn()
            }
        }
        this.gridObj1.gridView.onCellDblClicked = (grid, clickData) => {
            if (_.isEqual(clickData.cellType, 'data')) {
                this.gridObj1.dataProvider.setValue(
                    clickData.dataRow,
                    'chk',
                    true
                )
                this.onClickRightBtn()
            }
        }
        // 그리드내의 상품코드 돋보기 클릭시 이벤트처리
        this.gridObj1.gridView.onCellButtonClicked = (
            grid,
            itemIndex,
            column
        ) => {
            this.gridObj1.gridView.commit()
            if (column.fieldName === 'prodCd') {
                this.searchPopParam.prod_cd = grid.getValue(
                    itemIndex.itemIndex,
                    'prodCd'
                )
                this.onDealcoIconClick()
            }
        }
        // 그리드내의 상품코드 돋보기 클릭시 이벤트처리
        this.gridObj2.gridView.onCellButtonClicked = (
            grid,
            itemIndex,
            column
        ) => {
            this.gridObj2.gridView.commit()
            if (column.fieldName === 'prodCd') {
                this.searchPopParam.prod_cd = grid.getValue(
                    itemIndex.itemIndex,
                    'prodCd'
                )
                this.onDealcoIconClick()
            }
        }
    },
    methods: {
        gridSetData: function () {
            return new CommonGrid('', '', '', '')
        },
        // 상품코드 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            console.log('pop param prodCd', this.searchPopParam.prod_cd)
            this.localDialogShow = true
        },
        //상품구분변경시
        prodClCdChange: function () {
            let prodClCd = this.forms.prodClCd

            //바코드정보
            if ('1' == prodClCd || '' == prodClCd) {
                this.basProdMgmtDis.prodChrticCd1 = false
                this.basProdMgmtDis.prodChrticCd2 = false
                this.basProdMgmtDis.prodChrticCd3 = false
                this.basProdMgmtDis.prodChrticCd4 = false
                this.basProdMgmtDis.eqpClCd = false
            } else {
                //disable + 초기화
                this.basProdMgmtDis.prodChrticCd1 = true
                this.basProdMgmtDis.prodChrticCd2 = true
                this.basProdMgmtDis.prodChrticCd3 = true
                this.basProdMgmtDis.prodChrticCd4 = true
                this.basProdMgmtDis.eqpClCd = true
                //초기화
                this.forms.prodChrticCd1 = ''
                this.forms.prodChrticCd2 = ''
                this.forms.prodChrticCd3 = ''
                this.forms.prodChrticCd4 = ''
                this.forms.eqpClCd = ''
            }
        },
        filterEqpClCd(items) {
            return items.filter(
                (item) =>
                    item['commCdVal'] === '01' ||
                    item['commCdVal'] === '03' ||
                    item['commCdVal'] === ''
            )
        },
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            this.searchOutDealParam.dealcoNm = this.forms.mfactNm
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    console.log('getOutDealList then : ', res)
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.forms.mfactCd = _.get(res[0], 'dealcoCd')
                        this.forms.mfactNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        // 외부거래처 TextField 돋보기 Icon 이벤트 처리
        onOutDealIconClick() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
            // 그 이외는 외부거래처 팝업 오픈
            if (!_.isEmpty(this.forms.mfactNm)) {
                this.getOutDealList()
            } else {
                this.showBcoOutDeals = true
            }
        },
        // 외부거래처 TextField 엔터키 이벤트 처리
        onOutDealEnterKey() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.forms.mfactNm)) {
                this.showTcComAlert('외부거래처명을 입력해주세요.')
                return
            }
            // 외부거래처 정보 조회
            this.getOutDealList()
        },
        // 외부거래처 TextField Input 이벤트 처리
        onOutDealInput() {
            // 입력되는 값이 있으면 외부거래처 코드 초기화
            this.forms.mfactCd = ''
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.forms.mfactCd = _.get(retrunData, 'dealcoCd')
            this.forms.mfactNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================

        //조회 버튼 이벤트
        searchBtn: function () {
            this.getPproductListList()
            this.delRow = []
        },
        // API 호출
        getPproductListList() {
            basPdmAgnProdReg
                .getAgnProdIncludeList(this.forms)
                .then((resultData) => {
                    this.searchForms = this.forms //검색조건 저장
                    console.log('resultData ', resultData)
                    this.gridObj1.setRows(resultData)
                    this.gridData1 = this.gridSetData() //초기화
                    console.log('조회완료')
                })
            basPdmAgnProdReg
                .getAgnProdExcludeList(this.forms)
                .then((resultData) => {
                    this.searchForms = this.forms //검색조건 저장
                    console.log('resultData ', resultData)
                    this.gridObj2.setRows(resultData)
                    this.gridData2 = this.gridSetData() //초기화
                    console.log('조회완료')
                })
        },
        //엑셀다운로드 - 운영 상품
        includeDownload() {
            const rowCount = this.gridObj1.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/pdm/agnProdIncludeExcelList',
                this.searchForms
            )
        },
        //엑셀다운로드 - 미운영 상품
        excludeDownload() {
            const rowCount = this.gridObj2.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/pdm/agnProdExcludeExcelList',
                this.searchForms
            )
        },
        onClickRightBtn() {
            console.log('onClickRightBtn')

            let rowIdxs = this.gridObj1.gridView.getCheckedRows()
            let rows = this.gridObj1.dataProvider.getJsonRows()

            let rightRows = []

            rightRows = this.gridObj2.dataProvider.getJsonRows()

            let newRows = []
            rowIdxs.forEach((n) => {
                rows.forEach((v, i) => {
                    if (n === i) {
                        if (!_.isEmpty(v.prodCd)) {
                            if (
                                rightRows.filter((f) =>
                                    f.prodCd.includes(v.prodCd)
                                ).length === 0
                            ) {
                                this.delRow.push(v)
                                newRows.push(v)
                            }
                        }
                    }
                })
            })
            console.log('delRow', this.delRow)
            this.gridObj1.dataProvider.beginUpdate()
            this.gridObj1.dataProvider.removeRows(rowIdxs)
            this.gridObj1.dataProvider.endUpdate()

            this.gridObj2.dataProvider.beginUpdate()
            this.gridObj2.dataProvider.addRows(newRows)
            this.gridObj2.dataProvider.endUpdate()
        },
        onClickLeftBtn() {
            console.log('onClickLeftBtn')

            let rowIdxs = this.gridObj2.gridView.getCheckedRows()
            let rows = this.gridObj2.dataProvider.getJsonRows()

            let rightRows = []

            rightRows = this.gridObj1.dataProvider.getJsonRows()

            let newRows = []

            rowIdxs.forEach((n) => {
                rows.forEach((v, i) => {
                    if (n === i) {
                        if (!_.isEmpty(v.prodCd)) {
                            if (
                                rightRows.filter((f) =>
                                    f.prodCd.includes(v.prodCd)
                                ).length === 0
                            ) {
                                _.remove(this.delRow, { prodCd: v.prodCd })
                                newRows.push(v)
                            }
                        }
                    }
                })
            })
            console.log('delRow', this.delRow)
            this.gridObj2.dataProvider.beginUpdate()
            this.gridObj2.dataProvider.removeRows(rowIdxs)
            this.gridObj2.dataProvider.endUpdate()

            this.gridObj1.dataProvider.beginUpdate()
            this.gridObj1.dataProvider.addRows(newRows)
            this.gridObj1.dataProvider.endUpdate()
        }, //저장 버튼 이벤트
        onSave: function () {
            let addData = []
            //let delData = []
            let addIndexArr = this.gridObj1.modifyGrid() // 추가/수정 건 체크

            for (let idx = 0; idx < addIndexArr.length; idx++) {
                let getJson = this.gridObj1.dataProvider.getJsonRow(
                    addIndexArr[idx]
                )
                addData.push(getJson)
            }

            this.finalParam = {
                basProdAddList: addData,
                basProdDelList: this.delRow,
            }
            console.log('finalParam:', this.finalParam)
            console.log(
                '변경사항여부:',
                this.finalParam.basProdAddList.length,
                this.finalParam.basProdDelList.length
            )
            if (
                this.finalParam.basProdAddList.length > 0 ||
                this.finalParam.basProdDelList.length > 0
            ) {
                this.addAgnProd(this.finalParam)
            }
        },

        addAgnProd(finalParam) {
            console.log('addAgnProd')
            //그리드 validation
            basPdmAgnProdReg.addAgnProd(finalParam).then((res) => {
                if (res) {
                    this.showTcComAlert('저장 완료하였습니다.', {
                        header: 'Grid Data 저장',
                        size: '500',
                        confirmLabel: 'OK',
                    })

                    console.log('저장완료')
                }

                this.getPproductListList()
                this.delRow = []
            })
        },

        // 초기화
        onResetPage() {
            this.gridObj1.dataProvider.clearRows()
            this.gridObj2.dataProvider.clearRows()
            this.delRow = []
            this.forms = new BasPdmProdBrwsMgmtParam()
            this.basProdMgmtDis = new BasProdMgmtDis()
        },
    },
    computed: {},
    watch: {},
}
</script>
