import { ValueType } from 'realgrid'

export const BAS_BCO_NEW_ZIP_HEADER = {
    fields: [
        {
            fieldName: 'zipCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zipSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'siDoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'siDoEngNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'siGunGuNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'siGunGuEngNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eupMyunDongNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eupMyunDongEngNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'streetNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'streetEngNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'streetCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ldongCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ldongNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'siGunGuBldnNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'oldZipCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'basAddr',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'no',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'no',
            fieldName: 'no',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'no',
            },
        },
        {
            name: 'zipCd',
            fieldName: 'zipCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '신우편번호',
            },
        },
        {
            name: 'siDoNm',
            fieldName: 'siDoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '시/도',
            },
        },
        {
            name: 'siGunGuNm',
            fieldName: 'siGunGuNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '시/군/구',
            },
        },
        {
            name: 'eupMyunDongNm',
            fieldName: 'eupMyunDongNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '읍/면',
            },
        },
        {
            name: 'riNm',
            fieldName: 'riNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '리',
            },
        },
        {
            name: 'streetNm',
            fieldName: 'streetNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '도로명',
            },
        },
        {
            name: 'ldongNm',
            fieldName: 'ldongNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '법정동',
            },
        },
        {
            name: 'siGunGuBldnNm',
            fieldName: 'siGunGuBldnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '시군구용건물',
            },
        },
        {
            name: 'oldZipCd',
            fieldName: 'oldZipCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '구우편번호',
            },
        },
    ],
}
