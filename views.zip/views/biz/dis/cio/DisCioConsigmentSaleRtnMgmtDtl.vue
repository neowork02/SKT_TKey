<!-----------------------------------------------
 * 업무그룹명: 수탁매출입출고
 * 서브업무명: 수탁_매출반품관리상세
 * 설명: 수탁_매출반품상세 내역을 등록/조회한다.
 * 작성자: P179890
 * 작성일: 2022.06.06
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>수탁_매출반품관리상세</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="addProdPop"
                    :disabled="isNotNew"
                    >상품입력</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :disabled="isNotNew"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :disabled="isNotNew"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="listBtn"
                    :objAuth="this.objAuth"
                >
                    목록
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="반품지시일"
                        :eRequired="true"
                        :calType="calType"
                        v-model="setSchdDate"
                        :disabled="isNotNew"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="조직구분"
                        :itemList="orgClComboItems"
                        :objAuth="this.objAuth"
                        v-model="reqParam.outCl"
                        :addBlankItem="false"
                        :disabled="isNotNew"
                        @change="outClChange"
                    ></TCComComboBox>
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="거래조직"
                        @enterKey="onAuthOrgTreeIconClick"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :objAuth="this.objAuth"
                        :eRequired="true"
                        v-model="reqParam.orgNm"
                        v-show="showOrg"
                        :codeVal="reqParam.orgId"
                        :disabledAfter="true"
                        :disabled="isNotNew || searchDisable"
                    >
                    </TCComInputSearchText>
                    <!-- 내부조직팝업(권한) -->
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="reqParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="거래처"
                        @enterKey="onDealcoIconClick"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                        :objAuth="this.objAuth"
                        :eRequired="true"
                        v-model="reqParam.outPlcNm"
                        :codeVal="reqParam.outPlcId"
                        :disabledAfter="true"
                        :disabled="isNotNew || searchDisable"
                    >
                    </TCComInputSearchText>
                    <!-- 내부거래처팝업(권한조직) -->
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchDealcoParam"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                    <!-- 외부거래처팝업 -->
                    <BasBcoOutDealsPopup
                        v-if="showBcoOutDeals"
                        :parentParam="searchOutDealParam"
                        :rows="resultOutDealRows"
                        :dialogShow.sync="showBcoOutDeals"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 1-4 -->
            </div>
            <!-- //Search_line 1 -->
        </div>
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="수탁_매출반품관리상세 내역"
                :gridObj="this.gridObj"
                :isExceldown="isNotNew"
                :isDelRow="!isNotNew"
                @excelDownBtn="exportGridBtn"
                @chkDelRowBtn="gridchkDelRowBtn"
            >
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
        </div>
        <!-- //gridWrap -->
        <!-- 상품입력POPUP -->
        <DisCioDisSrchPopup
            v-if="showDisProdPop === true"
            :dialogShow.sync="showDisProdPop"
            :params="disProdParam"
            :prodOrgList="prodOrgList"
            @addDisProdList="returnProdList"
        />
        <!-- //상품입력POPUP -->
        <TCComAlert
            :headerText="alertHeadTxt"
            v-model="saveBool"
            :bodyText="alertBodyTxt"
            :size="400"
            :btnOkShow="false"
            @ok-click="listBtn"
        ></TCComAlert>
    </div>
</template>

<script>
import { CommonGrid, CommonUtil, CommonMsg } from '@/utils'
import { DisCioConsigmentSaleRtnMgmtDtl_GRID_HEADER } from '@/const/grid/dis/cio/disCioConsigmentSaleRtnMgmtDtlHeader'
import cioApi from '@/api/biz/dis/cio/disCioConsigmentSaleRtnMgmtDtl'
import attachedFileApi from '@/api/common/attachedFile'
import DisCioDisSrchPopup from '@/views/biz/dis/cio/DisCioDisSrchPopup'
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처(권한조직)====================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처(권한조직)==================
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//====================//외부거래처(제조사,매입처,배송사 등) 팝업====================

export default {
    name: 'DisCioConsigmentSaleRtnMgmtDtl',
    components: {
        DisCioDisSrchPopup,
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
        BasBcoOutDealsPopup,
    },
    mixins: [CommonMixin],
    data() {
        return {
            //====================내부조직팝업(권한)팝업관련====================
            authOrgParam: {},
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            curInOutOrgFocus: '', // 현재 포커스된 검색조직(출고:OUT/입고:IN) 영역
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처(권한 조직))====================
            basBcoDealcoShow: false,
            searchDealcoParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY',
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC',
            },
            resultDealcoRows: [],
            curInOutPlcFocus: '', // 현재 포커스된 거래처(출고:OUT/입고:IN) 영역
            //====================//내부거래처(권한 조직)==================
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '3X,2X,8X', // 거래처그룹
                dealcoClCd1: '', // 거래처구분
            },
            // ---- AS-IS ------
            // aDealCoGrp[0] = "3X";	// 제조사
            // aDealCoGrp[1] = "2X";	// 매입처
            // aDealCoGrp[2] = "8X";	// 특판처
            // ---- //AS-IS ------
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================
            showOrg: true, // 거래조직 visible 여부
            isNotNew: false, // 신규화면여부
            saveBool: false,
            searchDisable: false,
            alertHeadTxt: '수탁_매출반품관리상세',
            alertBodyTxt: '',
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            params: {},
            calType: 'D',
            view: DisCioConsigmentSaleRtnMgmtDtl_GRID_HEADER,
            listSearch: {},
            inMaster: {},
            searchParam: {},
            prodSerNumList: [],
            prodOrgList: [], // 그리드 리스트 배열
            outDealGrp: '3X,2X,8X', // 외부 거래처 그룹
            gridStyle: {
                height: '450px', //그리드 높이 조절
            },
            reqParam: {
                schdDt: '', // 반품지시일
                outCl: '', // 조직구분
                orgId: '', // 거래조직코드
                orgNm: '', // 거래조직명
                orgLevel: '', // 거래조직레벨
                outPlcId: '', // 거래처코드
                outPlcNm: '', // 거래처명
            },
            showDisProdPop: false, // 재고상품입력팝업 호출 값
            orgClComboItems: [
                { commCdValNm: '내부', commCdVal: '1' },
                { commCdValNm: '외부', commCdVal: '2' },
            ],
        }
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false, false, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.listSearch = this.$route.params.search
        this.params = this.$route.params
        // 입고등록된 경우
        if (!_.isEmpty(this.$route.params.inMgmtNo)) {
            // 입고 마스터/상세 조회
            this.getEntrustedSaleRtnDtlList()
        } else {
            this.init()
        }
    },
    computed: {
        setSchdDate: {
            get() {
                return this.reqParam['schdDt']
            },
            set(val) {
                this.reqParam['schdDt'] = val
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.reqParam.basMth = CommonUtil.onlyNumber(val).substr(0, 6)
                // 내부거래처 기준년월 파라미터 set
                this.searchDealcoParam.basDay = CommonUtil.onlyNumber(
                    val
                ).substr(0, 8)
                return val
            },
        },
    },
    methods: {
        init() {
            this.reqParam['schdDt'] = moment(new Date()).format('YYYY-MM-DD') // 반품지시일
            this.reqParam['outCl'] = '1' // 조직구분 default 내부
            // 세션정보 set
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                // 거래조직
                this.reqParam['orgId'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLevel'] = this.orgInfo['orgLvl']
                // 거래처
                this.reqParam['outPlcId'] = this.userInfo['dealcoCd']
                this.reqParam['outPlcNm'] = this.userInfo['dealcoNm']
                this.searchDisable = true
            } else {
                // 거래조직
                this.reqParam['orgId'] = this.listSearch['orgId']
                this.reqParam['orgNm'] = this.listSearch['orgNm']
                this.reqParam['orgLevel'] = this.listSearch['orgLevel']
                // 거래처
                this.reqParam['outPlcId'] = this.listSearch['outPlcId']
                this.reqParam['outPlcNm'] = this.listSearch['outPlcNm']
                this.searchDisable = false
            }
            this.showOrg = true
        },
        gridSetData: function () {
            // CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(0, 10000, '', '')
        },
        //Grid ExcelDown
        exportGridBtn: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/cio/consigmentSaleRtnMgmtDtlExcels',
                this.searchParam
            )
        },
        // Check Row Delete Event
        gridchkDelRowBtn: function () {
            if (!_.isEmpty(this.inMaster.outMgmtNo)) {
                this.openAlert(
                    CommonMsg.getMessage(
                        'MSG_00022',
                        '이미 출고 등록된 데이터로'
                    )
                )
                return
            }
            const chkRows = this.gridObj.gridView.getCheckedRows(true)
            this.gridData.gridRows = this.gridData.gridRows + chkRows.length
            this.gridHeaderObj.chkDelRow(this.gridData)
        },
        // 초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'reqParam', this.gridObj) // 초기화 함수
            this.init()
        },
        // 목록
        listBtn() {
            this.$router.push({
                name: '/dis/cio/DisCioConsigmentSaleRtnMgmt',
                params: { search: this.listSearch },
            })
        },
        // 저장
        async saveBtn() {
            const createdRows =
                this.gridObj.dataProvider.getStateRows('created')

            // 최초 등록시에만
            if (_.isEmpty(this.inMaster.outMgmtNo)) {
                if (!this.isSaveValidChk()) {
                    return
                }

                if (createdRows.length == 0) {
                    this.openAlert(CommonMsg.getMessage('MSG_00071', ''))
                    return
                }

                // MSG_00063: ' %s 저장하시겠습니까?'
                const confirm = await this.showTcComConfirm(
                    CommonMsg.getMessage('MSG_00063', '전체')
                )
                if (confirm) {
                    // 수탁_매출반품등록
                    this.saveEntrustedSaleRtnDtl(createdRows)
                }
            }
        },
        // 저장 Validation 체크
        isSaveValidChk() {
            if (_.isEmpty(this.reqParam.schdDt)) {
                // MSG_00083
                this.openAlert(CommonMsg.getMessage('MSG_00083', '반품지시일'))
                return false
            }

            if (
                CommonUtil.onlyNumber(this.reqParam.schdDt.substr(0, 7)) <
                CommonUtil.onlyNumber(moment(new Date()).format('YYYYMM'))
            ) {
                this.openAlert('현재월 이전으로는 입력이 불가합니다.')
                return
            }

            if (this.reqParam.outCl == '1') {
                if (_.isEmpty(this.reqParam.orgId)) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00083', '거래조직')
                    )
                    return false
                }
                if (_.isEmpty(this.reqParam.outPlcId)) {
                    this.openAlert(CommonMsg.getMessage('MSG_00083', '거래처'))
                    return false
                }
            } else {
                if (_.isEmpty(this.reqParam.outPlcId)) {
                    this.openAlert(CommonMsg.getMessage('MSG_00083', '거래처'))
                    return false
                }
            }
            return true
        },
        // 수탁_매출반품등록
        saveEntrustedSaleRtnDtl(createdRows) {
            // MASTER파라미터 set
            this.inMaster['inSchdDt'] = this.reqParam['schdDt'] // 반품지시일
            // this.inMaster['outPlcId'] = this.reqParam['outPlcId'] // 거래처코드
            // 반품지시일
            this.inMaster['inSchdDt'] = CommonUtil.onlyNumber(
                this.reqParam['schdDt']
            )

            let prodSerNumList = []
            let saveData = {}

            createdRows.forEach((i) => {
                prodSerNumList.push(this.gridObj.dataProvider.getJsonRow(i))
            })

            saveData = {
                inMaster: this.inMaster,
                prodSerNumList: prodSerNumList,
            }
            cioApi.saveEntrustedSaleRtnDtl(saveData).then((res) => {
                // 정상등록
                if (res === 1) {
                    this.alertBodyTxt = CommonMsg.getMessage('MSG_00990')
                    this.saveBool = true
                }
            })
        },
        // 입고 마스터/상세 조회
        getEntrustedSaleRtnDtlList: function () {
            this.searchParam = {
                inMgmtNo: this.params.inMgmtNo,
                inSchdDt: this.params.inSchdDt,
                inOrgId: this.params.inOrgId,
                outOrgId: this.params.outOrgId,
                inPlcId: this.params.inPlcId,
                outPlcId: this.params.outPlcId,
                outCl: !_.isEmpty(this.params['outDealCoGrp']) ? '1' : '2',
            }

            cioApi.getEntrustedSaleRtnDtlList(this.searchParam).then((res) => {
                // 입고마스터
                this.inMaster = res.result.inMaster

                // 디테일 리스트
                this.prodSerNumList = res.result.prodSerNumList

                this.gridObj.setRows(this.prodSerNumList)

                this.gridHeaderObj.setPageCount({
                    totalDataCnt: res.result.prodSerNumList.length,
                })

                // 검색영역 제어
                this.setDivOrgDs()
            })
        },
        // 검색영역 제어
        setDivOrgDs() {
            // 버튼 및 컴포넌트 제어
            this.isNotNew = true
            this.reqParam['schdDt'] = CommonUtil.addDashDate(
                this.params.inSchdDt
            )
            // const sDealCoGrp = this.params['outDealCoGrp']
            // if (this.outDealGrp.indexOf(sDealCoGrp) == -1) {
            if (!_.isEmpty(this.params['outDealCoGrp'])) {
                // 조직구분 - 내부
                this.reqParam['outCl'] = '1'
                this.reqParam['orgId'] = this.params.inOrgId
                this.reqParam['orgNm'] = this.params.inOrgNm
                this.reqParam['outPlcId'] = this.params.inPlcId
                this.reqParam['outPlcNm'] = this.params.inPlcNm
                // 거래조직 검색영역 visible true
                this.showOrg = true
            } else {
                // 조직구분 - 외부
                this.reqParam['outCl'] = '2'
                this.reqParam['outPlcId'] = this.params.inPlcId
                this.reqParam['outPlcNm'] = this.params.inPlcNm
                // 거래조직 검색영역 visible false
                this.showOrg = false
            }
        },
        // 팝업 호출 validation 체크
        isPopValidChk() {
            if (this.reqParam.outCl == '1') {
                if (_.isEmpty(this.reqParam.orgId)) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00083', '거래조직')
                    )
                    return false
                }
                if (_.isEmpty(this.reqParam.outPlcId)) {
                    this.openAlert(CommonMsg.getMessage('MSG_00083', '거래처'))
                    return false
                }
            } else {
                if (_.isEmpty(this.reqParam.outPlcId)) {
                    this.openAlert(CommonMsg.getMessage('MSG_00083', '거래처'))
                    return false
                }
            }
            return true
        },
        // 상품입력팝업 호출
        addProdPop() {
            // validation
            if (!this.isPopValidChk()) {
                return false
            }
            // 재고상품입력 팝업 파라미터 set
            this.disProdParam = {
                outPlcId: this.reqParam.outPlcId, // 거래처코드
                outPlcNm: this.reqParam.outPlcNm, // 거래처명
                outSchdDt: this.reqParam.schdDt, // 반품지시일
            }
            this.prodOrgList = this.gridObj.dataProvider.getJsonRows(0, -1)
            this.showDisProdPop = true
        },
        // 상품입력 팝업 리턴 데이터
        returnProdList(returnVal) {
            if (returnVal.length > 0) {
                returnVal.forEach((data) => {
                    data['inQty'] = data['movCnt'] // 수량
                    data['inPrac'] = data['unitPrc'] // 단가
                    // 상품 append
                    this.gridObj.dataProvider.insertRow(
                        this.gridObj.gridView.getItemCount(),
                        data
                    )
                })
            }
        },
        // 조직구분 ComboBox 변경이벤트
        outClChange(val) {
            // 거래조직 거래처 초기화
            this.reqParam['orgId'] = ''
            this.reqParam['orgNm'] = ''
            this.reqParam['orgLevel'] = ''
            this.reqParam['outPlcId'] = ''
            this.reqParam['outPlcNm'] = ''
            if (val == '1') {
                // 내부
                // 거래조직 검색영역 visible true
                this.showOrg = true

                if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                    // 거래조직
                    this.reqParam['orgId'] = this.orgInfo['orgCd']
                    this.reqParam['orgNm'] = this.orgInfo['orgNm']
                    this.reqParam['orgLevel'] = this.orgInfo['orgLvl']
                    // 거래처
                    this.reqParam['outPlcId'] = this.userInfo['dealcoCd']
                    this.reqParam['outPlcNm'] = this.userInfo['dealcoNm']
                    this.searchDisable = true
                } else {
                    this.searchDisable = false
                }
            } else {
                // 외부
                // 거래조직 검색영역 visible false
                this.showOrg = false
                this.searchDisable = false
            }
        },
        // alert창 호출
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.authOrgParam)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.orgId = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLevel = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            this.authOrgParam['orgNm'] = this.reqParam['orgNm']
            this.authOrgParam['orgCd'] = this.reqParam['orgId']
            this.authOrgParam['orgLvl'] = this.reqParam['orgLevel']
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            if (
                !_.isEmpty(this.reqParam.orgId) &&
                this.reqParam.orgId != returnData.orgCd
            ) {
                this.reqParam.outPlcId = ''
                this.reqParam.outPlcNm = ''
                this.gridObj.gridInit()
            }
            this.reqParam.orgId = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.orgLevel = _.get(returnData, 'orgLvl')
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.orgId = ''
            this.reqParam.orgLevel = ''
            this.reqParam.outPlcId = ''
            this.reqParam.outPlcNm = ''
            this.gridObj.gridInit()
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처(권한조직)) methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcoParam)
                .then((res) => {
                    if (res.length === 1) {
                        // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                        this.reqParam.outPlcId = _.get(res[0], 'dealcoCd')
                        this.reqParam.outPlcNm = _.get(res[0], 'dealcoNm')
                    } else {
                        // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        // 내부거래처(권한조직) TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.resultOutDealRows = []
            if (this.reqParam.outCl == '1') {
                // 내부
                if (_.isEmpty(this.reqParam.orgId)) {
                    // MSG_00083
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00083', '거래조직')
                    )
                    return
                }
                this.searchDealcoParam['orgCd'] = this.reqParam['orgId']
                this.searchDealcoParam['orgNm'] = this.reqParam['orgNm']
                this.searchDealcoParam['orgLvl'] = this.reqParam['orgLevel']
                this.searchDealcoParam['dealcoCd'] = this.reqParam['outPlcId']
                this.searchDealcoParam['dealcoNm'] = this.reqParam['outPlcNm']

                if (!_.isEmpty(this.reqParam['outPlcNm'])) {
                    this.getDealcosList()
                } else {
                    // 내부거래처팝업오픈
                    this.basBcoDealcoShow = true
                }
            } else {
                // 외부
                this.resultOutDealRows = []
                this.searchOutDealParam['dealcoCd'] = this.reqParam.outPlcId
                this.searchOutDealParam['dealcoNm'] = this.reqParam.outPlcNm
                if (!_.isEmpty(this.reqParam.outPlcNm)) {
                    // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
                    this.getOutDealList()
                } else {
                    // 외부거래처팝업오픈
                    // 그 이외는 외부거래처 팝업 오픈
                    this.showBcoOutDeals = true
                }
            }
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.reqParam.outPlcId = ''
            this.gridObj.gridInit()
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            if (this.reqParam.outPlcId != returnData.dealcoCd) {
                this.gridObj.gridInit()
            }
            this.reqParam.outPlcId = _.get(returnData, 'dealcoCd')
            this.reqParam.outPlcNm = _.get(returnData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.outPlcId = _.get(res[0], 'dealcoCd')
                        this.reqParam.outPlcNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
    },
}
</script>
