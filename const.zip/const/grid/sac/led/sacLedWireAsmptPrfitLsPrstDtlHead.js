import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'accDealcoCd', // 정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', // 정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accMtch', // 정산상계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'addsCmmsAmt', // 판매수수료_추가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'adjtCmmsAmt', //판매수수료_조정
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'agencyCd', // 대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm', // 대리점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agrmtPrd', // 약정기간
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asmptPrfitLs', // 추정손익_총액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'asmptPrfitUamt', // 추정손익_객단가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cellProcDt ', // T개통일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cellProdNm', // T단말기모델
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cellSaleTypNm', // T판매유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cmmsAddSub', // 수수료가감
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsTotAmt', // 판매수수료_소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'custNm', // 고객명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNo', // 고객번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm', // 거래처구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eventAmt', // 기타_스마트팩
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'gnrlCmmsAmt', // 판매수수료_일반
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'gnrlPhoneSaleQty', // 판매수량_일반전화
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'gnrlSaleChgSeq ', // 판매변경순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleNo', // 판매관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'intPhoneSaleQty', // 판매수량_인터넷전화
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'iptvSaleQty', // 판매수량_IPTV
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ldntwCmmsAmt', // 대형유통망수수료
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mktChrgrUserId', // 마케터
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktChrgrUserNm', // 마케터
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mnpYn', // 번호이동여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'motiPrMnyAmt', // 모티인센티브
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'opUserId', // 처리자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opUserNm', // 처리자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd2', // 사업담당코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd3', // 영업팀코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd4', // 영업파트코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm2', // 사업담당명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm3', // 영업팀명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm4', // 영업센터명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prAmt', // 기타_판촉물
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'procStCd', // 개통상태코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procStNm', // 개통상태명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm', // 사업상세
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'psnmPrMnyAmt', // PS&M인센티브_소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'psnmPrMnyAmt1', // PS&M인센티브_본사
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'psnmPrMnyAmt2', // PS&M인센티브_본부
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'psnmPrMnyAmt3', // PS&M인센티브_팀
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rewardAmt1', // 성과보상A
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rewardAmt2', // 성과보상B
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleChgDtm', // 매출일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgHstClNm', // 판매이력구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgrUserId', // 판매자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgrUserNm', // 판매자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoCd', // 판매처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoNm', // 판매처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtm', // 개통일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleStCd', // 판매상태코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleStNm', // 판매상태명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleTypNm', //판매유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'skbPrMnyAmt', // 인센티브_SKB
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktChnlCd', // 채널코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktPrMnyAmt', // 인센티브_SKT
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktSubCd', // 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubNm', // 매장명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sumPrMnyAmt', // 인센티브_소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'suplCmmsAmt', // 판매수수료_부가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'suplPolSvcs', // 부가상품
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm', // 요금제
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcs', // 부가서비스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcDtm', // 최초접수일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', // 결합서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tbFamilyNm', // TB결합형태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'totPrMnyAmt', // 인센티브_소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totSaleQty', // 판매수량_소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'trgtSaleCmmsAmt', // 판매수수료_추정
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'wireFastSaleQty', // 판매수량_초고속
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'wireSvcMgmtNum', // 유선서비스관리번호
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            width: '200',
            header: '판매번호',
        },
        {
            name: 'gnrlSaleChgSeq',
            fieldName: 'gnrlSaleChgSeq',
            type: 'data',
            width: '200',
            header: '판매변경순번',
        },
        {
            name: 'svcDtm',
            fieldName: 'svcDtm',
            type: 'data',
            width: '200',
            header: '최초접수일',
        },
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            width: '200',
            header: '개통일자',
        },
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            width: '200',
            header: '매출일자',
        },
        {
            name: 'saleStNm',
            fieldName: 'saleStNm',
            type: 'data',
            width: '200',
            header: '판매상태',
        },
        {
            name: 'saleChgHstClNm',
            fieldName: 'saleChgHstClNm',
            type: 'data',
            width: '200',
            header: '판매이력구분',
        },
        {
            name: 'procStNm',
            fieldName: 'procStNm',
            type: 'data',
            width: '200',
            header: '개통상태',
        },
        {
            name: 'orgNm2',
            fieldName: 'orgNm2',
            type: 'data',
            width: '200',
            header: '사업담당',
        },
        {
            name: 'orgNm3',
            fieldName: 'orgNm3',
            type: 'data',
            width: '200',
            header: '영업팀',
        },
        {
            name: 'orgNm4',
            fieldName: 'orgNm4',
            type: 'data',
            width: '200',
            header: '영업파트',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            width: '200',
            header: '정산처',
            visible: false,
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            width: '200',
            header: '정산처명',
            visible: false,
        },
        {
            name: 'dealcoClNm',
            fieldName: 'dealcoClNm',
            type: 'data',
            width: '200',
            header: '거래처구분',
            visible: false,
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            width: '200',
            header: '판매처',
            visible: false,
        },
        {
            name: 'saleDealcoNm',
            fieldName: 'saleDealcoNm',
            type: 'data',
            width: '200',
            header: '판매처명',
            visible: false,
        },
        {
            name: 'saleChrgrUserId',
            fieldName: 'saleChrgrUserId',
            type: 'data',
            width: '200',
            header: '판매자ID',
            visible: false,
        },
        {
            name: 'saleChrgrUserNm',
            fieldName: 'saleChrgrUserNm',
            type: 'data',
            width: '200',
            header: '판매자명',
            visible: false,
        },
        {
            name: 'mktChrgrUserNm',
            fieldName: 'mktChrgrUserNm',
            type: 'data',
            width: '200',
            header: '마케터',
            visible: false,
        },
        {
            name: 'custNo',
            fieldName: 'custNo',
            type: 'data',
            width: '200',
            header: '고객번호',
            visible: false,
        },

        {
            name: 'wireSvcMgmtNum',
            fieldName: 'wireSvcMgmtNum',
            type: 'data',
            width: '200',
            header: '유선서비스관리번호',
            visible: false,
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            width: '200',
            header: '고객명',
            visible: false,
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            width: '200',
            header: '대리점코드',
            visible: false,
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            width: '200',
            header: '대리점명',
            visible: false,
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            width: '200',
            header: '매장코드',
            visible: false,
        },
        {
            name: 'sktSubNm',
            fieldName: 'sktSubNm',
            type: 'data',
            width: '200',
            header: '매장명',
            visible: false,
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            width: '200',
            header: '채널코드',
            visible: false,
        },
        {
            name: 'mnpYn',
            fieldName: 'mnpYn',
            type: 'data',
            width: '200',
            header: '번호이동여부',
            visible: false,
        },
        {
            name: 'saleTypNm',
            fieldName: 'saleTypNm',
            type: 'data',
            width: '200',
            header: '판매유형',
            visible: false,
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '200',
            header: '사업상세',
            visible: false,
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            width: '200',
            header: '요금제',
            visible: false,
        },

        {
            name: 'agrmtPrd',
            fieldName: 'agrmtPrd',
            type: 'data',
            width: '200',
            header: '약정기간',
            visible: false,
        },
        {
            name: 'tbFamilyNm',
            fieldName: 'tbFamilyNm',
            type: 'data',
            width: '200',
            header: 'TB결합형태',
            visible: false,
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            width: '200',
            header: '결합서비스관리번호',
            visible: false,
        },
        {
            name: 'cellProcDt',
            fieldName: 'cellProcDt',
            type: 'data',
            width: '200',
            header: 'T개통일',
            visible: false,
        },
        {
            name: 'cellProdNm',
            fieldName: 'cellProdNm',
            type: 'data',
            width: '200',
            header: 'T단말기모델',
            visible: false,
        },
        {
            name: 'cellSaleTypNm',
            fieldName: 'cellSaleTypNm',
            type: 'data',
            width: '200',
            header: 'T판매유형',
            visible: false,
        },
        {
            name: 'opUserId',
            fieldName: 'opUserId',
            type: 'data',
            width: '200',
            header: '처리자ID',
            visible: false,
        },
        {
            name: 'opUserNm',
            fieldName: 'opUserNm',
            type: 'data',
            width: '200',
            header: '처리자명',
            visible: false,
        },
        {
            name: 'suplPolSvcs',
            fieldName: 'suplPolSvcs',
            type: 'data',
            width: '200',
            header: '부가상품',
            visible: false,
        },
        {
            name: 'suplSvcs',
            fieldName: 'suplSvcs',
            type: 'data',
            width: '200',
            header: '부가서비스',
            visible: false,
        },
        // 인센티브 - SKT, SKB, 소계
        {
            name: 'sktPrMnyAmt',
            fieldName: 'sktPrMnyAmt',
            type: 'data',
            width: '200',
            header: 'SKT',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'skbPrMnyAmt',
            fieldName: 'skbPrMnyAmt',
            type: 'data',
            width: '200',
            header: 'SKB',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'sumPrMnyAmt',
            fieldName: 'sumPrMnyAmt',
            type: 'data',
            width: '200',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // PS&M인센티브 - 본사, 본부, 팀, 소계
        {
            name: 'psnmPrMnyAmt1',
            fieldName: 'psnmPrMnyAmt1',
            type: 'data',
            width: '200',
            header: '본사',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmt2',
            fieldName: 'psnmPrMnyAmt2',
            type: 'data',
            width: '200',
            header: '본부',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmt3',
            fieldName: 'psnmPrMnyAmt3',
            type: 'data',
            width: '200',
            header: '팀',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmt',
            fieldName: 'psnmPrMnyAmt',
            type: 'data',
            width: '200',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 판매수수료 - 일반, 부가, 추가, 조정, 소계
        {
            name: 'gnrlCmmsAmt',
            fieldName: 'gnrlCmmsAmt',
            type: 'data',
            width: '200',
            header: '일반',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'suplCmmsAmt',
            fieldName: 'suplCmmsAmt',
            type: 'data',
            width: '200',
            header: '부가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'addsCmmsAmt',
            fieldName: 'addsCmmsAmt',
            type: 'data',
            width: '200',
            header: '추가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'adjtCmmsAmt',
            fieldName: 'adjtCmmsAmt',
            type: 'data',
            width: '200',
            header: '조정',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'cmmsTotAmt',
            fieldName: 'cmmsTotAmt',
            type: 'data',
            width: '200',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'eventAmt',
            fieldName: 'eventAmt',
            type: 'data',
            width: '200',
            header: '스마트팩',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },

        {
            name: 'motiPrMnyAmt',
            fieldName: 'motiPrMnyAmt',
            type: 'data',
            width: '200',
            header: '모티인센티브',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'asmptPrfitLs',
            fieldName: 'asmptPrfitLs',
            type: 'data',
            width: '200',
            header: '추정손익',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
    ],
    layout: [
        'NO',
        'gnrlSaleNo',
        'gnrlSaleChgSeq',
        'svcDtm',
        'saleDtm',
        'saleChgDtm',
        'saleStNm',
        'saleChgHstClNm',
        'procStNm',
        'orgNm2',
        'orgNm3',
        'orgNm4',
        'accDealcoCd',
        'accDealcoNm',
        'dealcoClNm',
        'saleDealcoCd',
        'saleDealcoNm',
        'saleChrgrUserId',
        'saleChrgrUserNm',
        'mktChrgrUserNm',
        'custNo',
        'wireSvcMgmtNum',
        'custNm',
        'agencyCd',
        'agencyNm',
        'sktSubCd',
        'sktSubNm',
        'sktChnlCd',
        'mnpYn',
        'saleTypNm',
        'prodClNm',
        'suplSvcNm',
        'agrmtPrd',
        'tbFamilyNm',
        'svcMgmtNum',
        'cellProcDt',
        'cellProdNm',
        'cellSaleTypNm',
        'opUserId',
        'opUserNm',
        'suplPolSvcs',
        'suplSvcs',
        {
            name: '인센티브',
            direction: 'horizontal',
            items: ['sktPrMnyAmt', 'skbPrMnyAmt', 'sumPrMnyAmt'],
        },
        {
            name: 'PS&M인센티브',
            direction: 'horizontal',
            items: [
                'psnmPrMnyAmt1',
                'psnmPrMnyAmt2',
                'psnmPrMnyAmt3',
                'psnmPrMnyAmt',
            ],
        },
        {
            name: '판매수수료',
            direction: 'horizontal',
            items: [
                'gnrlCmmsAmt',
                'suplCmmsAmt',
                'addsCmmsAmt',
                'adjtCmmsAmt',
                'cmmsTotAmt',
            ],
        },
        'eventAmt',
        'motiPrMnyAmt',
        'asmptPrfitLs',
    ],
}
