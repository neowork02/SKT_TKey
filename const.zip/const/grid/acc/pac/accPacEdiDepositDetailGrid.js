'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: '__rowState',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'patmentDt',
        editable: false,
        header: { text: '승인일자' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'payDt',
        editable: false,
        header: { text: '입금일자' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'gnrlSaleNo',
        editable: false,
        header: { text: '수납번호' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'saleChgDtm',
        editable: false,
        header: { text: '매출일자' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'payDtm',
        editable: false,
        header: { text: '수납일자' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'saleTyp',
        editable: false,
        header: { text: '전표유형' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'aprvNum',
        editable: false,
        header: { text: '승인번호' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'salePlcCd',
        editable: false,
        header: { text: '판매처코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'salePlcNm',
        editable: false,
        header: { text: '판매처명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'cardCoCd',
        editable: false,
        header: { text: '매입사코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'cardCoNm',
        editable: false,
        header: { text: '매입사명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'payAmt',
        editable: false,
        header: { text: '승인금액' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },

    {
        fieldName: 'dpstAmt',
        editable: false,
        header: { text: '입금금액' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },

    {
        fieldName: 'caseCmmsAmt',
        editable: false,
        header: { text: '수수료' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },

    {
        fieldName: 'stCd',
        editable: false,
        header: { text: '처리결과' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'cardOpStCdNm',
        editable: false,
        header: { text: '처리상태' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'chgDt',
        editable: false,
        header: { text: '변경일자' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },

    {
        fieldName: 'rmks',
        editable: false,
        header: { text: '비고' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = []
GRID_HEADER.contextStyle = `height: 500px`

const MOCK_DATA = {
    adpayMgmtVoList: [],
}

export { GRID_HEADER, MOCK_DATA }
