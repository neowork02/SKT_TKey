import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'stNm', // 처리상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opDt', // 등록일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'oprUserId', // 등록자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'oprUserNm', // 등록자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDt', // 처리일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'clsDt', // 완료일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outOrgCd', // 원보유처조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outOrgNm', // 원보유처조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgCd', // 원보유처레벨0조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgNm', // 원보유처레벨0조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgCd1', // 원보유처레벨1조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgNm1', // 원보유처레벨1조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgCd2', // 원보유처레벨2조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgNm2', // 원보유처레벨2조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgCd3', // 원보유처레벨3조직코드
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'outLvOrgNm3', // 원보유처레벨3조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoCd', // 원보유처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoNm', // 원보유처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outShopCd', // 원보유처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgCd', // 현보유처조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgNm', // 현보유처조직점
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgCd', // 현보유처레벨0조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgNm', // 현보유처레벨0조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgCd1', // 현보유처레벨1조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgNm1', // 현보유처레벨1조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgCd2', // 현보유처레벨2조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgNm2', // 현보유처레벨2조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgCd3', // 현보유처레벨3조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgNm3', // 현보유처레벨3조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inPlcId', // 현보유처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inPlcNm', // 현보유처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inShopCd', // 현보유처매장코드
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'chrgrUserId', // 영업담당자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chrgrUserNm', // 영업담당자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd', // 거래처구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm', // 거래처구분명
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'sktAgencyCd', // 대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd', // 서브코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd', // 채널코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd', // 상품구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm', // 상품구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd', // 제조사
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm', // 제조사명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 상품코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd', // 색상코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm', // 색상명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum', // 일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskLclCd', // RISK대분류
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskLclNm', // RISK대분류명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskMclCd', // RISK중분류
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskMclNm', // RISK중분류명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskStCd', // RISK상태코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskStNm', // RISK상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'clsYn', // 완료여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'clsYnNm', // 완료여부명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'crdtPrchsPrc', // 여신매입가
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'realPrchsPrc', // 실제매입가
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskAmt', // RISK금액
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstAmt', // 입금(거래처)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'etcDpstAmt', // 입금(기타)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'costOpAmt', // 비용처리
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'debtSetoffAmt', // 채무상계
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskId', // RISK ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskSeq', // RISK 순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskIdSeq', // RISK ID 순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bondClctAmt', // 채권회수금액
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bondErpTrmsYn', // 채권회수ERP전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bondTrmsDt', // 채권회수전송일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'costErpTrmsYn', // 비용ERP전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'debtSetoffErpTrmsYn', // 채권상계ERP전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'debtSetoffTrmsDt', // 채권상계전송일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', // 재고 UPD_CNT
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dtlRiskId', // RISK 상세 ID
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'stNm',
            fieldName: 'stNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '처리상태',
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '등록일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'oprUserNm',
            fieldName: 'oprUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '등록자',
        },
        {
            name: 'modDt',
            fieldName: 'modDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '처리일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'clsDt',
            fieldName: 'clsDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '완료일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'outOrgNm',
            fieldName: 'outOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '원보유처조직',
        },
        {
            name: 'outDealcoNm',
            fieldName: 'outDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '원보유처',
        },
        {
            name: 'inOrgNm',
            fieldName: 'inOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '현보유처조직',
        },
        {
            name: 'inPlcNm',
            fieldName: 'inPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '현보유처',
        },
        {
            name: 'chrgrUserNm',
            fieldName: 'chrgrUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '영업담당',
        },
        {
            name: 'dealcoClNm1',
            fieldName: 'dealcoClNm1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처구분',
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '대리점코드',
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '서브코드',
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '채널코드',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품구분',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '제조사',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '색상',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '일련번호',
        },
        {
            name: 'riskLclNm',
            fieldName: 'riskLclNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: 'RISK대분류',
        },
        {
            name: 'riskMclNm',
            fieldName: 'riskMclNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: 'RISK중분류',
        },
        {
            name: 'riskStNm',
            fieldName: 'riskStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: 'RISK상태',
        },
        {
            name: 'clsYnNm',
            fieldName: 'clsYnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '완료여부',
        },
        {
            name: 'crdtPrchsPrc',
            fieldName: 'crdtPrchsPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '여신매입가',
        },
        {
            name: 'realPrchsPrc',
            fieldName: 'realPrchsPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '실제매입가',
        },
        {
            name: 'riskAmt',
            fieldName: 'riskAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: 'Risk금액',
        },
        {
            name: 'dpstAmt',
            fieldName: 'dpstAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입금(거래처)',
        },
        {
            name: 'etcDpstAmt',
            fieldName: 'etcDpstAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입금(기타)',
        },
        {
            name: 'costOpAmt',
            fieldName: 'costOpAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '비용처리',
        },
        {
            name: 'debtSetoffAmt',
            fieldName: 'debtSetoffAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '채무상계',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
        },
        {
            name: 'dtlRiskId',
            fieldName: 'dtlRiskId',
            visible: false,
            type: 'data',
        },
    ],
}
