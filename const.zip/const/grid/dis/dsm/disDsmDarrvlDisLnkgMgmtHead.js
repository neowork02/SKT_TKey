import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'rgnCd', // 권역코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgnNm', // 권역명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 모델코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 모델명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd', // 색상코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm', // 색상명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', // 처리자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm', // 처리자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 처리일시
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'rgnCd',
            fieldName: 'rgnCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '권역코드',
        },
        {
            name: 'rgnNm',
            fieldName: 'rgnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '권역명',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델코드',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: '모델명',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '처리자',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '처리일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
    ],
}

export const G_HEADER_REGISTER = {
    fields: [
        {
            fieldName: 'no',
            dataType: ValueType.TEXT, //번호
        },
        {
            fieldName: 'rgnCd', // 권역코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgnNm', // 권역명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 모델코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 모델명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errDesc', // 오류사항
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId', // 처리자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCnt', // 상품건수
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'rgnCd',
            fieldName: 'rgnCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '권역코드',
        },
        {
            name: 'rgnNm',
            fieldName: 'rgnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '권역명',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품코드',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품명',
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: '오류사항',
        },
    ],
}
