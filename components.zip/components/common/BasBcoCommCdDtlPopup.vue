<!-----------------------------------------------
 * 업무그룹명: 기준정보>공통코드상세
 * 서브업무명: 기준정보>공통코드상세
 * 설명: 기준정보>공통코드상세 Popup 컴포넌트
 * 작성자: 이창석
 * 작성일: 2022.05.09
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpenBcoCommCdDtl" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">공통코드상세 팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <!--
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchCommCdDtlParam.commCdId"
                                    labelName="코드구분ID"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            -->
                            <!-- 공통코드상세 -->
                            <div class="formitem div2">
                                <TCComInputSearch
                                    v-model="searchCommCdDtlParam.commCdId"
                                    labelName="코드구분ID"
                                    placeholder="입력해주세요"
                                    :disabled="
                                        searchCommCdDtlParam.isDisabledCommCdId
                                    "
                                    :objAuth="objAuth"
                                    @enterKey="onCommCdSrchEnterKey"
                                    @appendIconClick="onCommCdSrchIconClick"
                                />
                                <BasCdmCommCdSrchPopup
                                    v-if="showCdmCommCdSrch"
                                    :parentParam="searchCommCdSrchParam"
                                    :rows="resultCommCdSrchRows"
                                    :dialogShow.sync="showCdmCommCdSrch"
                                    @confirm="onCommCdSrchReturnData"
                                />
                            </div>
                            <!-- 공통코드상세 -->

                            <div class="formitem div2">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            :objAuth="objAuth"
                                            @click="onSearch"
                                        >
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                            <!-- // input -->
                        </div>
                        <!-- // Search_line 1 -->
                    </div>
                    <div class="contBoth">
                        <!-- SubTit -->
                        <div class="stitHead pop">
                            <h4 class="subTit">공통코드상세 목록</h4>
                        </div>
                        <!-- // SubTit -->

                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="bcoCommCdDtlGrid"
                                ref="bcoCommCdDtlGrid"
                                :editable="true"
                                :fields="header.fields"
                                :columns="header.columns"
                                @hook:mounted="gridMounted"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { BAS_BCO_COMMCDDTL_HEADER } from '@/const/grid/bas/bco/basBcoCommCdDtlHeader'
import basBcoCommCdDtlApi from '@/api/biz/bas/bco/basBcoCommCdDtl'
import CommonMixin from '@/mixins'
//====================공통코드검색====================
import BasCdmCommCdSrchPopup from '@/components/common/BasCdmCommCdSrchPopup'
import basCdmCommCdSrchApi from '@/api/biz/bas/cdm/basCdmCommCdSrch'
//====================//공통코드검색====================
//import commonApi from '@/api/common/commonCode'
import _ from 'lodash'

export default {
    name: 'BasBcoCommCdDtlPopup',
    mixins: [CommonMixin],
    components: { BasCdmCommCdSrchPopup },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            header: BAS_BCO_COMMCDDTL_HEADER,
            headerText: '',
            searchCommCdDtlParam: {
                commCdId: '', // 코드구분
                commCdNm: '',
                cd: '',
                nm: '',
                isDisabledCommCdId: false,
            },
            //====================공통검색팝업관련====================
            showCdmCommCdSrch: false, // 공통검색팝업 팝업 오픈 여부
            searchCommCdSrchParam: {
                condition: '1', //검색구분구분
                value: '', //검색값

                //리턴값
                commCdId: '', // 공통검색팝업코드 변경가능
                commCdNm: '',
            },
            resultCommCdSrchRows: [], // 공통검색팝업 팝업 오픈 여부
            //====================//대리점팝업관련==================
        }
    },
    computed: {
        activeOpenBcoCommCdDtl: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchCommCdDtlParam.commCdId =
                    value['commCdId'] == undefined ? '' : value['commCdId']
                this.searchCommCdDtlParam.nm =
                    value['nm'] == undefined ? '' : value['nm']
                this.searchCommCdDtlParam.cd =
                    value['cd'] == undefined ? '' : value['cd']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        console.log('created')
        this.init()
    },
    mounted() {
        console.log('mounted')
        this.gridObj = this.$refs.bcoCommCdDtlGrid // Grid Object 설정
        this.initGrid()
        this.getCommCdDtlList()

        //컬럼전체채우기
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
    },
    methods: {
        init() {
            console.log('init')
            this.gridData = this.gridSetData()
            if (!_.isEmpty(this.searchCommCdDtlParam.commCdId)) {
                this.searchCommCdDtlParam.isDisabledCommCdId = true
                this.searchCommCdDtlParam.commCdId =
                    this.searchCommCdDtlParam.commCdId.toUpperCase()
                this.onSearch()
            }
        },
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            this.gridObj.setGridState(false, false, false)
            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },

        gridMounted() {
            console.log('gridMounted')
        },
        getCommCdDtlList() {
            basBcoCommCdDtlApi
                .getCommCdDtlList(this.searchCommCdDtlParam)
                .then((res) => {
                    console.log('getCommCdDtlList then : ', res)
                    this.gridObj.setRows(res)
                })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()

            if (current.dataRow === -1) {
                this.showTcComAlert('코드구분ID를 입력해주세요.', {
                    header: '공통코드 선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }

            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )

            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpenBcoCommCdDtl = false
        },

        onSearch() {
            if (_.isEmpty(this.searchCommCdDtlParam.commCdId)) {
                this.showTcComAlert('코드구분ID를 입력해주세요.', {
                    header: '공통코드 선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }

            this.getCommCdDtlList()
        },

        onEnterKey() {
            this.onSearch()
        },

        //===================== 공통팝업검색팝업관련 methods ================================
        // 공통팝업검색 조회 후 1건이면 TextField에 바로 설정하고 아니면 공통팝업검색 팝업 오픈
        getCommCdSrchList() {
            //검색구분에따른 검색어변경
            /*
            if ('1' == this.searchCommCdSrchParam.condition) {
                this.searchCommCdSrchParam.value =
                    this.searchCommCdDtlParam.commCdId
            }

            if ('2' == this.searchCommCdSrchParam.condition) {
                this.searchCommCdSrchParam.value =
                    this.searchCommCdDtlParam.commCdNm
            }
            */
            this.searchCommCdSrchParam.value =
                this.searchCommCdDtlParam.commCdId

            basCdmCommCdSrchApi
                .getCommCdSrchList(this.searchCommCdSrchParam)
                .then((res) => {
                    console.log('getCommCdSrchList then : ', res)
                    // 검색된 공통팝업검색 정보가 1건이면 TextField에 바로 설정
                    // 검색된 공통팝업검색 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 공통팝업검색 팝업 오픈
                    if (res.length === 1) {
                        /*
                        this.searchCommCdSrchParam.value = _.get(
                            _.get(res[0]
                            'value'
                        )
                        */
                        this.searchCommCdDtlParam.commCdId = _.get(
                            res[0],
                            'commCdId'
                        )
                        this.searchCommCdDtlParam.commCdNm = _.get(
                            res[0],
                            'commCdNm'
                        )
                    } else {
                        this.resultCommCdSrchRows = res
                        this.showCdmCommCdSrch = true
                    }
                })
        },
        // 공통팝업검색 TextField 돋보기 Icon 이벤트 처리
        onCommCdSrchIconClick() {
            // 공통팝업검색 팝업 Row 설정 Prop 변수 초기화
            this.resultCommCdSrchRows = []
            // 검색조건 공통팝업검색명이 빈값이 아니면 공통팝업검색 조회
            // 그 이외는 공통팝업검색 팝업 오픈

            if (!_.isEmpty(this.searchCommCdDtlParam.commCdId)) {
                this.getCommCdSrchList()
            } else {
                this.showCdmCommCdSrch = true
            }
        },
        // 공통팝업검색 TextField 엔터키 이벤트 처리
        onCommCdSrchEnterKey() {
            //검색구분에따른 검색어변경
            /*            
            if ('1' == this.searchCommCdSrchParam.condition) {
                this.searchCommCdSrchParam.value =
                    this.searchCommCdDtlParam.commCdId
            }

            if ('2' == this.searchCommCdSrchParam.condition) {
                this.searchCommCdSrchParam.value =
                    this.searchCommCdDtlParam.commCdNm
            }
            */
            // 공통팝업검색 팝업 Row 설정 Prop 변수 초기화
            this.resultCommCdSrchRows = []
            // 검색조건 공통팝업검색명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchCommCdDtlParam.commCdId)) {
                this.showTcComAlert('코드구분ID를 입력해주세요.')
                return
            }
            // 공통팝업검색 정보 조회
            this.getCommCdSrchList()
        },
        /*        
        // 공통팝업검색 TextField Input 이벤트 처리
        onCommCdSrchInput() {
            console.log('commCdId null')
            // 입력되는 값이 있으면 공통팝업검색 코드 초기화
            this.searchCommCdDtlParam.commCdId = ''
        },
*/
        // 공통팝업검색 팝업 리턴 이벤트 처리
        onCommCdSrchReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchCommCdDtlParam.commCdId = _.get(retrunData, 'commCdId')
            this.searchCommCdDtlParam.commCdNm = _.get(retrunData, 'commCdNm')
        },
        //===================== //공통팝업검색팝업관련 methods ================================
    },
}
</script>
