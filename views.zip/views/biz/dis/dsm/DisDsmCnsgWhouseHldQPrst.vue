<!-----------------------------------------------
 * 업무그룹명: 재고관리현황
 * 서브업무명: 위탁창고보유현황
 * 설명: 위탁창고보유현황을 조회한다.
 * 작성자: P179890
 * 작성일: 2022.04.14
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>위탁창고보유현황</h1>
        <!-- // Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left"></li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="getDisDsmCnsgWhouseHldQPrsts"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="배정일자"
                        :calType="calType"
                        v-model="setDate"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.agencyNm"
                        :codeVal="reqParam.agencyCd"
                        labelName="대리점"
                        :disabledAfter="true"
                        :objAuth="this.objAuth"
                        @enterKey="onAgencyIconClick"
                        @appendIconClick="onAgencyIconClick"
                        @input="onAgencyInput"
                    >
                    </TCComInputSearchText>
                    <BasBcoAgencysPopup
                        v-if="showBcoAgencys"
                        :dialogShow.sync="showBcoAgencys"
                        :parentParam="reqParam"
                        :rows="resultAgencyRows"
                        @confirm="onAgencyReturnData"
                    />
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="모델"
                        @enterKey="onProdsIconClick"
                        @appendIconClick="onProdsIconClick"
                        @input="reqParam.prodCd = ''"
                        :objAuth="this.objAuth"
                        v-model="reqParam.prodNm"
                        :codeVal="reqParam.prodCd"
                        :disabledAfter="true"
                    >
                    </TCComInputSearchText>
                    <BasBcoProdsPopup
                        v-if="basBcoProdsShow === true"
                        :dialogShow.sync="basBcoProdsShow"
                        :parentParam="searchProdForm"
                        :rows="resultProdsRows"
                        @confirm="onProdsReturnData"
                    />
                </div>
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="색상"
                        @enterKey="onCommCdDtlIconClick"
                        @appendIconClick="onCommCdDtlIconClick"
                        @input="reqParam.colorCd = ''"
                        :objAuth="this.objAuth"
                        v-model="reqParam.colorNm"
                        :codeVal="reqParam.colorCd"
                        :disabledAfter="true"
                    >
                    </TCComInputSearchText>
                    <BasBcoCommCdDtlPopup
                        v-if="showBcoCommCdDtl"
                        :parentParam="searchCommCdDtlParam"
                        :rows="resultCommCdDtlRows"
                        :dialogShow.sync="showBcoCommCdDtl"
                        @confirm="onCommCdDtlReturnData"
                    />
                </div>
                <!-- //item 1-4 -->
            </div>
            <!-- //Search_line 1 -->
        </div>
        <!-- //Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="위탁창고보유현황"
                :gridObj="this.gridObj"
                :isExceldown="true"
                :isPageRows="true"
                @excelDownBtn="this.exportGridBtn"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
        </div>
        <!-- //gridWrap -->
    </div>
</template>

<!--style scoped>
</style-->
<script>
import { DisDsmCnsgWhouseHldQPrst_GRID_HEADER } from '@/const/grid/dis/dsm/disDsmCnsgWhouseHldQPrstHeader.js'
import restApi from '@/api/biz/dis/dsm/disDsmCnsgWhouseHldQPrst.js'
import attachedFileApi from '@/api/common/attachedFile'
import { CommonUtil, CommonMsg } from '@/utils'
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
//====================대리점팝업====================
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup' // 대리점팝업
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys' // 대리점팝업
//====================//대리점팝업====================
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================
//====================공통코드상세====================
import BasBcoCommCdDtlPopup from '@/components/common/BasBcoCommCdDtlPopup'
import basBcoCommCdDtlApi from '@/api/biz/bas/bco/basBcoCommCdDtl'
//====================//공통코드상세====================

export default {
    name: 'DisDsmCnsgWhouseHldQPrst',
    mixins: [CommonMixin],
    components: { BasBcoAgencysPopup, BasBcoProdsPopup, BasBcoCommCdDtlPopup },
    data() {
        return {
            //====================대리점팝업관련====================
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //====================//대리점팝업관련==================
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            resultProdsRows: [],
            searchProdForm: {
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
                prodClCd: '', //상품구분
                sktOperYn: '', //skt운영여부
                useYn: '', //사용여부
            },
            //====================//상품팝업관련==================
            //====================공통상세팝업관련====================
            showBcoCommCdDtl: false, // 공통상세팝업 팝업 오픈 여부
            searchCommCdDtlParam: {
                commCdId: 'ZBAS_C_00040', // 공통상세팝업코드 변경가능
                cd: 'ZBAS_C_00040', // 공통상세팝업코드 변경가능
            },
            resultCommCdDtlRows: [], // 공통상세팝업 팝업 오픈 여부
            //====================//공통상세팝업관련====================
            alertBodyTxt: '',
            alertHeadTxt: '위탁창고보유현황',
            view: DisDsmCnsgWhouseHldQPrst_GRID_HEADER,
            calType: 'D',
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            searchForms: {},
            gridStyle: {
                height: '450px', //그리드 높이 조절
            },
            reqParam: {
                // 요청파라미터
                asgnDt: '', // 배정일자
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
                agencyTypCd: '', // 대리점명
                prodCd: '', // 모델코드
                prodNm: '', // 모델명
                colorCd: '', // 색상코드
                colorNm: '', // 색상명
            },
        }
    },
    watch: {},
    computed: {
        setDate: {
            get() {
                return this.reqParam.asgnDt
            },
            set(val) {
                this.reqParam.asgnDt = val
                return val
            },
        },
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false)
        this.gridObj.gridView.setRowIndicator({ visible: true })

        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.init()
    },
    methods: {
        init() {
            //검색영역
            this.reqParam.asgnDt = moment(new Date()).format('YYYY-MM-DD') // 배정일자
            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
        },
        //Grid ExcelDown
        exportGridBtn: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dsm/disDsmCnsgWhouseHldQPrstExcels',
                this.searchForms
            )
        },
        // 위탁창고보유현황 조회
        getDisDsmCnsgWhouseHldQPrsts() {
            if (!this.isValidChk()) {
                return false
            }
            this.searchForms = { ...this.reqParam }
            this.searchForms.asgnDt = CommonUtil.onlyNumber(
                this.searchForms.asgnDt
            )
            //위탁창고보유현황 리스트 조회
            restApi
                .getDisDsmCnsgWhouseHldQPrsts(this.searchForms)
                .then((res) => {
                    this.gridObj.setRows(res.gridList)
                    this.gridHeaderObj.setPageCount({
                        totalDataCnt: res.gridList.length,
                    })
                })
        },
        // 초기화
        clearPage() {
            // CommonUtil 페이지 초기화 함수
            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            this.init()
        },
        // Alert창 호출
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        // Validation 체크
        isValidChk() {
            // validation 체크
            if (_.isEmpty(this.reqParam.asgnDt)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '배정일자'))
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.asgnDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }
            return true
        },
        // 검색영역 공통팝업 호출
        searchCommon(flag) {
            // TODO 공통팝업 호출
            if (flag === 'color') {
                // 색상
                this.showColors = true
            }
        },
        //===================== 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getAgencyList() {
            basBcoAgencysApi.getAgencyList(this.reqParam).then((res) => {
                // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.agencyCd = _.get(res[0], 'agencyCd')
                    this.reqParam.agencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultAgencyRows = res
                    this.showBcoAgencys = true
                }
            })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.reqParam.agencyNm)) {
                this.getAgencyList()
            } else {
                this.showBcoAgencys = true
            }
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(retrunData) {
            this.reqParam.agencyCd = _.get(retrunData, 'agencyCd')
            this.reqParam.agencyNm = _.get(retrunData, 'agencyNm')
        },
        onAgencyInput() {
            this.reqParam.agencyCd = ''
        },
        //===================== //대리점팝업관련 methods ================================
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                if (res.length === 1) {
                    this.reqParam.prodCd = _.get(res[0], 'prodCd')
                    this.reqParam.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            this.searchProdForm['prodCd'] = this.reqParam['prodCd']
            this.searchProdForm['prodNm'] = this.reqParam['prodNm']
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.reqParam.prodNm)) {
                this.getProdsList()
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            this.reqParam.prodCd = _.get(retrunData, 'prodCd')
            this.reqParam.prodNm = _.get(retrunData, 'prodNm')
        },
        //===================== //상품팝업관련 methods ================================

        //===================== 공통팝업상세(색상)팝업관련 methods ================================
        // 공통팝업상세 조회 후 1건이면 TextField에 바로 설정하고 아니면 공통팝업상세 팝업 오픈
        getCommCdDtlList() {
            basBcoCommCdDtlApi
                .getCommCdDtlList(this.searchCommCdDtlParam)
                .then((res) => {
                    // 검색된 공통팝업상세 정보가 1건이면 TextField에 바로 설정
                    // 검색된 공통팝업상세 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 공통팝업상세 팝업 오픈
                    if (res.length === 1) {
                        this.searchCommCdDtlParam.commCdId = _.get(
                            res[0],
                            'commCdId'
                        )
                    } else {
                        this.resultCommCdDtlRows = res
                        this.showBcoCommCdDtl = true
                    }
                })
        },
        // 공통팝업상세 TextField 돋보기 Icon 이벤트 처리
        onCommCdDtlIconClick() {
            // 공통팝업상세 팝업 Row 설정 Prop 변수 초기화
            this.resultCommCdDtlRows = []
            // 검색조건 공통팝업상세명이 빈값이 아니면 공통팝업상세 조회
            // 그 이외는 공통팝업상세 팝업 오픈
            if (!_.isEmpty(this.reqParam.colorNm)) {
                this.getCommCdDtlList()
            } else {
                this.showBcoCommCdDtl = true
            }
        },
        // 공통팝업상세 팝업 리턴 이벤트 처리
        onCommCdDtlReturnData(retrunData) {
            this.reqParam.colorCd = _.get(retrunData, 'commCdVal')
            this.reqParam.colorNm = _.get(retrunData, 'commCdValNm')
        },
        //===================== //공통팝업상세(색상)팝업관련 methods ================================
    },
}
</script>
