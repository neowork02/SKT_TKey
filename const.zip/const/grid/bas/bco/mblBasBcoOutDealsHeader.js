/*****************************************
* 업무 그룹명 : 기준정보>외부거래처검색
* 서브 업무명 : 외부거래처검색
* 설 명 : 외부거래처검색 Grid 헤더 정보
* 작 성 자 : 김태훈
* 작 성 일 : 2022.05.12
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 :
* 변경사유/내역 : 
*
======================================
*****************************************/
import { ValueType } from 'realgrid'

export const BAS_BCO_OUT_DEAL_HEADER = {
    fields: [
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizNo',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        // {
        //     name: 'dealcoGrpCd',
        //     fieldName: 'dealcoGrpCd',
        //     editable: false,
        //     lookupDisplay: true,
        //     editor: {
        //         type: 'dropdown',
        //         dropDownCount: 10,
        //         domainOnly: true,
        //         textReadOnly: true,
        //     },
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '거래처그룹코드명',
        //     },
        // },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },

            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            editable: false,
            styleName: 'left-column',
            header: {
                text: '거래처명',
            },
            width: 200,
        },

        // {
        //     name: 'dealEndYn',
        //     fieldName: 'dealEndYn',
        //     type: 'data',
        //     editable: false,
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '거래상태',
        //     },
        // },
    ],
}
