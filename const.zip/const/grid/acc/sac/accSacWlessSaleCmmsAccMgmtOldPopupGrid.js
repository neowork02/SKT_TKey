import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = [
    {
        fieldName: 'accStNm',
        header: { text: '정산상태' },
        width: '150',
    },
    {
        fieldName: 'gnrlSaleNo',
        header: { text: '판매번호' },
        width: '150',
    },
    {
        fieldName: 'accYm',
        header: { text: '최초정산월' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMM',
        columnDatetimeFormat: 'yyyy-MM',
    },
    {
        fieldName: 'saleChgDtm',
        header: { text: '매출일' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'svcMgmtNum',
        header: { text: '서비스관리번호' },
        width: '150',
    },
    {
        fieldName: 'cntrctMgmtNo',
        header: { text: '계약관리번호' },
        width: '150',
    },
    {
        fieldName: 'custNm',
        header: { text: '고객명' },
        width: '150',
    },
    {
        fieldName: 'svcNum',
        header: { text: '개통번호' },
        width: '150',
    },
    {
        fieldName: 'agrmtClNm',
        header: { text: '약정구분' },
        width: '150',
    },
    {
        fieldName: 'saleDtlTypNm',
        header: { text: '판매유형' },
        width: '150',
    },
    {
        fieldName: 'prodNm',
        header: { text: '모델' },
        width: '150',
        group: 'saleEqp',
    },
    {
        fieldName: 'eqpColorNm',
        header: { text: '색상' },
        width: '150',
        group: 'saleEqp',
    },
    {
        fieldName: 'serNum',
        header: { text: '일련번호' },
        width: '150',
        group: 'saleEqp',
    },
    {
        fieldName: 'eqpDisClNm',
        header: { text: '재고구분' },
        width: '150',
        group: 'saleEqp',
    },
    {
        fieldName: 'eqpSettlCondNm',
        header: { text: '결재조건' },
        width: '150',
        group: 'saleEqp',
    },
    {
        fieldName: 'rtnProdCd',
        header: { text: '모델' },
        width: '150',
        group: 'rtnEqp',
    },
    {
        fieldName: 'rtnSerNum',
        header: { text: '일련번호' },
        width: '150',
        group: 'rtnEqp',
    },
]

const GRID_META_GROUP = {
    saleEqp: {
        direction: 'horizontal',
        header: { text: '판매 단말기' },
        items: [],
    },
    rtnEqp: {
        direction: 'horizontal',
        header: { text: '반납 단말기' },
        items: [],
    },
}

const GRID_HEADER = {}
GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = gridMetaUtil.adjustLayout(GRID_META, GRID_META_GROUP)

export { GRID_HEADER }
