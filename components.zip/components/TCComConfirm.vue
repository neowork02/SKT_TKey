<!-----------------------------------------------
 * 업무그룹명: Confirm 컴포넌트
 * 서브업무명: Confirm 공통함수
 * 설명: Confirm 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.05.13
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <v-dialog persistent :max-width="size" v-model="confirmShow">
        <template v-slot:default>
            <div class="layerPop">
                <!-- Popup_tit -->
                <p class="popTitle noDraggable">{{ header }}</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont alert">
                    <!-- textbox -->
                    <div class="text-box">
                        <p style="white-space: pre-line">
                            {{ confirmMessage }}
                        </p>
                    </div>
                    <!-- //textbox -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onCancel"
                        >취소</a
                    >
                    <!--//Close BTN-->
                    <!-- <v-btn text @click="dialog.value = false" >Close</v-btn> -->
                </div>
                <!-- //Popup_Cont -->
                <!-- Popup_BTN :하단 버튼 2개 -->
                <div class="popBtn">
                    <!-- <TCComButton
                        :Vuetify="false"
                        :labelName="confirmLabel"
                        class="btn_bottom"
                        @click="onConfirm"
                    >
                    </TCComButton>
                    <TCComButton
                        v-if="isCancelBtn"
                        :Vuetify="false"
                        :labelName="cancelLabel"
                        class="btn_bottom confirmBtn"
                        @click="onCancel"
                    >
                    </TCComButton> -->
                    <button
                        ref="confirmBtn"
                        type="button"
                        class="btn_bottom"
                        :class="{ full: !isCancelBtn }"
                        @click="onConfirm"
                    >
                        <span>{{ confirmLabel }}</span>
                    </button>
                    <button
                        v-if="isCancelBtn"
                        type="button"
                        class="btn_bottom confirmBtn"
                        @click="onCancel"
                    >
                        <span>{{ cancelLabel }}</span>
                    </button>
                </div>
                <!-- //Popup_BTN  :하단 버튼 2개-->
            </div>
        </template>
    </v-dialog>
</template>

<script>
import _ from 'lodash'
export default {
    inheritAttrs: false,
    name: 'TCComConfirm',
    components: {},
    props: {},

    data() {
        return {
            resolve: null,
        }
    },
    computed: {
        size() {
            let res = '360'
            const size = _.get(
                this.$store.getters['tcComConfirmOptions'],
                'size'
            )
            if (!_.isEmpty(size)) {
                res = size + 'px'
            }
            return res
        },
        confirmMessage() {
            return this.$store.getters['tcComConfirmMessage']
        },
        getConfirmOptions() {
            return this.$store.getters['tcComConfirmOptions']
        },
        confirmShow() {
            this.$nextTick(() => {
                if (this.$store.getters['tcComConfirmShow'] === true) {
                    this.$refs.confirmBtn.focus()
                }
            })
            return this.$store.getters['tcComConfirmShow']
        },
        confirmResolve() {
            return this.$store.getters['tcComConfirmResolve']
        },
        header() {
            let header = _.get(this.getConfirmOptions, 'header')
            if (_.isEmpty(header)) {
                header = '확인'
            }
            return header
        },
        confirmLabel() {
            let confirmLabel = _.get(this.getConfirmOptions, 'confirmLabel')
            if (_.isEmpty(confirmLabel)) {
                confirmLabel = '확인'
            }
            return confirmLabel
        },
        cancelLabel() {
            let cancelLabel = _.get(this.getConfirmOptions, 'cancelLabel')
            if (_.isEmpty(cancelLabel)) {
                cancelLabel = '취소'
            }
            return cancelLabel
        },
        isCancelBtn() {
            return _.get(this.getConfirmOptions, 'isCancelBtn')
        },
    },
    // props 동적 제어
    watch: {},
    created() {},
    mounted() {},
    methods: {
        onCancel() {
            this.confirmResolve(false)
            this.$store.dispatch('closeTcComConfirm')
        },
        onConfirm() {
            this.confirmResolve(true)
            this.$store.dispatch('closeTcComConfirm')
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
