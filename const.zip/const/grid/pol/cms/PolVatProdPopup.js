import { ValueType } from 'realgrid'

export let GRID_INFO = {
    fields: [
        {
            fieldName: 'suplSvcCd', // 부가서비스코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm', // 부가서비스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClCd', // 부가서비스(요금제)구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClNm', // 부가서비스(요금제)구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'basAmt', // 기본료
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'suplSvcClNm',
            fieldName: 'suplSvcClNm',
            type: 'data',
            width: '120',
            header: {
                text: '요금제구분',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            type: 'data',
            width: '120',
            header: {
                text: '부가서비스코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            width: '300',
            header: {
                text: '부가서비스명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        // {
        //     name: 'basAmt',
        //     fieldName: 'basAmt',
        //     type: 'data',
        //     width: '100',
        //     styles: {
        //         textAlignment: 'far',
        //     },
        //     header: {
        //         text: '기본료',
        //         showTooltip: false,
        //     },
        //     editor: {
        //         type: 'number',
        //         editFormat: '#,##0',
        //     },
        //     numberFormat: '#,##0',
        //     styleName: 'right-column',
        // },
    ],
}
