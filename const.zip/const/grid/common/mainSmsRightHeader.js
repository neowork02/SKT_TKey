import { ValueType } from 'realgrid'

export const GRID_R_HEADER = {
    fields: [
        {
            fieldName: 'classificationGrp',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'grp',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'repMblPhonNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktDealCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'classificationGrp',
            fieldName: 'classificationGrp',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '유형+그룹구분',
            },
        },
        {
            name: 'grp',
            fieldName: 'grp',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: ' 그룹코드',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            width: 30,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: ' 이름',
            },
        },
        {
            name: 'repMblPhonNo',
            fieldName: 'repMblPhonNo',
            type: 'data',
            width: 50,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전화번호',
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: 60,
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '소속조직',
            },
            styleName: 'left-column',
        },
        {
            name: 'sktDealCd',
            fieldName: 'sktDealCd',
            type: 'data',
            width: 45,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
            },
            styleName: 'left-column',
        },
    ],
}
