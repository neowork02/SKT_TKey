export default {
    agencyTypList: (state) => {
        return state._agencyTypList
    },
    agencyPtnList: (state) => {
        return state._agencyPtnList.filter((item) => item.commCdVal === 'M')
    },
}
