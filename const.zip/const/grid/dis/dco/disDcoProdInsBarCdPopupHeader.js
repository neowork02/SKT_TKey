import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT, //체크여부
        },
        {
            fieldName: 'inoutSchdDt',
            dataType: ValueType.TEXT, //입고예정일
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //모델코드
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //상품구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'toSerNum',
            dataType: ValueType.TEXT, //종료일련번호
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'badYnNm',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'disStCd',
            dataType: ValueType.TEXT, //재고상태
        },
        {
            fieldName: 'disStNm',
            dataType: ValueType.TEXT, //재고상태
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, //오류내용
        },
        {
            fieldName: 'errorClCd',
            dataType: ValueType.TEXT, //오류코드
        },
        {
            fieldName: 'reflYn',
            dataType: ValueType.TEXT, //반영여부
        },
        {
            fieldName: 'opDt',
            dataType: ValueType.TEXT, //처리일자
        },
        {
            fieldName: 'opTm',
            dataType: ValueType.TEXT, //if처리일자
        },
        {
            fieldName: 'rgstSeq',
            dataType: ValueType.TEXT, //등록순번
        },
        {
            fieldName: 'inoutClCd',
            dataType: ValueType.TEXT, //입출고구분코드
        },
        {
            fieldName: 'inoutPlcCd',
            dataType: ValueType.TEXT, //입출고처코드
        },
        {
            fieldName: 'lastInoutClCd',
            dataType: ValueType.TEXT, //최종입출고구분코드
        },
        {
            fieldName: 'lastInoutDtlClCd',
            dataType: ValueType.TEXT, //최종입출고상세구분코드
        },
        {
            fieldName: 'sknRnpTypCd',
            dataType: ValueType.TEXT, //SKN수불유형코드
        },
        {
            fieldName: 'sknOpClCd',
            dataType: ValueType.TEXT, //SKN처리구분코드
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT, //수정횟수
        },
        {
            fieldName: 'eqpClCd',
            dataType: ValueType.TEXT, //단말기구분코드
        },
        {
            fieldName: 'eqpClNm',
            dataType: ValueType.TEXT, //단말기구분명
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT, //제조사코드
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.TEXT, //종료일련번호
        },
        {
            fieldName: 'disHldDay',
            dataType: ValueType.TEXT, //보유일
        },
        {
            fieldName: 'barCdType',
            dataType: ValueType.TEXT, //바코드타입
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.TEXT, //판매단가
        },
        {
            fieldName: 'saleAmt',
            dataType: ValueType.TEXT, //판매가
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, //보유처코드
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '체크여부',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'inoutSchdDt',
            fieldName: 'inoutSchdDt',
            type: 'data',
            header: {
                text: '입고예정일',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분명',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'toSerNum',
            fieldName: 'toSerNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '종료일련번호',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량여부',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'badYnNm',
            fieldName: 'badYnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량여부',
                showTooltip: false,
            },
        },
        {
            name: 'disStCd',
            fieldName: 'disStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고상태',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'disStNm',
            fieldName: 'disStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고상태',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류내용',
                showTooltip: false,
            },
        },
        {
            name: 'errorClCd',
            fieldName: 'errorClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'reflYn',
            fieldName: 'reflYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반영여부',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일자',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'opTm',
            fieldName: 'opTm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'if처리일자',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'rgstSeq',
            fieldName: 'rgstSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록순번',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'inoutClCd',
            fieldName: 'inoutClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입출고구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'inoutPlcCd',
            fieldName: 'inoutPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입출고처코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'lastInoutClCd',
            fieldName: 'lastInoutClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최종입출고구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'lastInoutDtlClCd',
            fieldName: 'lastInoutDtlClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최종입출고상세구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'sknRnpTypCd',
            fieldName: 'sknRnpTypCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKN수불유형코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'sknOpClCd',
            fieldName: 'sknOpClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKN처리구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수정횟수',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'eqpClCd',
            fieldName: 'eqpClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'eqpClNm',
            fieldName: 'eqpClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분명',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'barCdType',
            fieldName: 'barCdType',
            visible: false,
            type: 'data',
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            visible: false,
            type: 'data',
        },
        {
            name: 'saleAmt',
            fieldName: 'saleAmt',
            visible: false,
            type: 'data',
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            visible: false,
            type: 'data',
        },
    ],
}
