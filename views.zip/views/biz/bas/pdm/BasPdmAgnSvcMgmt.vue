<template>
    <div class="content">
        <!-- Tit -->
        <h1>대리점별 운영부가상품관리</h1>
        <!-- // Tit -->

        <!-- Top BTN -->
        <ul class="btn_area top">
            <!-- 왼쪽 버튼 : 불필요 할 경우 삭제 -->
            <!-- //왼쪽 버튼  -->
            <!-- 오른쪽 버튼 -->
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                    >조회</TCComButton
                >
                <TCComButton color="btn2" eClass="btn_ty01" @click="onSave"
                    >저장</TCComButton
                >
            </li>
            <!-- //오른쪽 버튼 -->
        </ul>
        <!-- // Top BTN -->

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00480"
                        labelName="상품유형"
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        v-model="forms.wrcellClCd"
                        @change="onChangeWrcellClCd"
                        :eRequired="true"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="부가상품구분"
                        :codeId="commIdPrcplnClCd"
                        v-model="forms.suplSvcClCd"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :eRequired="true"
                        :filterFunc="filterPrcplnClCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="상품코드/상품명"
                        v-model="forms.suplSvcCdNm"
                        :objAuth="this.objAuth"
                        @enterKey="searchBtn"
                    ></TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="상품상태"
                        codeId="ZBAS_C_00180"
                        v-model="forms.prodStCd"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="D"
                        v-model="inputValue"
                        labelName="출시일자"
                        :eRequired="false"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="단종여부"
                        v-model="forms.endYn"
                        :objAuth="this.objAuth"
                        :itemList="this.Yn"
                        itemText="codeNm"
                        itemValue="codeId"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>-->
            <!-- //Search_line 2 -->
        </div>
        <!-- //Search_div -->

        <div class="contBoth">
            <!-- left area -->
            <div class="div5_5 cont1-1 left">
                <!-- gridWrap -->
                <TCRealGridHeader
                    id="gridHeader1"
                    ref="gridHeader1"
                    gridTitle="운영상품 목록"
                    :gridObj="gridObj1"
                    :isExceldown="true"
                    @excelDownBtn="this.includeDownload"
                >
                </TCRealGridHeader>
                <TCRealGrid
                    id="grid1"
                    ref="grid1"
                    :editable="true"
                    :movable="false"
                    :columnMovable="false"
                    :fields="view1.fields"
                    :columns="view1.columns"
                    :styles="gridStyle"
                />
                <!--TCComPaging
                    :totalPage="gridData1.totalPage"
                    :apiFunc="getProductPagingList"
                    :gridObj="gridObj1"
                    :rowCnt="rowCnt"
                    @input="chgRowCnt"
                /-->
                <!-- //gridWrap -->
            </div>
            <!-- //left area -->

            <!-- arrow area -->
            <div class="div5_5 cont3">
                <ul class="btnOrder">
                    <li>
                        <button
                            type="button"
                            class="btnOrderleft"
                            @click="onClickLeftBtn"
                        >
                            <span class="blind">left</span>
                        </button>
                    </li>
                    <li>
                        <button
                            type="button"
                            class="btnOrderright"
                            @click="onClickRightBtn"
                        >
                            <span class="blind">right</span>
                        </button>
                    </li>
                </ul>
            </div>
            <!-- //arrow area -->

            <!-- right area -->
            <div class="div5_5 cont1-1 right pl0">
                <!-- gridWrap -->
                <TCRealGridHeader
                    id="gridHeader2"
                    ref="gridHeader2"
                    gridTitle="미운영상품 목록"
                    :gridObj="gridObj2"
                    :isExceldown="true"
                    @excelDownBtn="this.excludeDownload"
                >
                </TCRealGridHeader>
                <TCRealGrid
                    id="grid2"
                    ref="grid2"
                    :editable="true"
                    :movable="false"
                    :columnMovable="false"
                    :fields="view2.fields"
                    :columns="view2.columns"
                    :styles="gridStyle"
                />
                <!--TCComPaging
                    :totalPage="gridData2.totalPage"
                    :apiFunc="getProductPagingList2"
                    :gridObj="gridObj2"
                    :rowCnt="rowCnt2"
                    @input="chgRowCnt2"
                /-->
                <!-- //gridWrap -->
            </div>
            <!-- //right area -->
        </div>
        <!-- Popup -->
        <DtlPopup
            v-if="showDtlPopup"
            ref="popup"
            :dialogShow.sync="showDtlPopup"
            :parentParam="searchPopParam"
        />
        <!-- Popup -->
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
import { WIRELESS_HEADER } from '@/const/grid/bas/pdm/basPdmAgnSvcMgmtHeader'
import attachedFileApi from '@/api/common/attachedFile'
import CommonMixin from '@/mixins'
import basPdmAgnSvcMgmt from '@/api/biz/bas/pdm/basPdmAgnSvcMgmt'
//====================상품팝업====================
import DtlPopup from './BasPdmAgnSvcDtlPopup'
//====================//상품팝업==================
import _ from 'lodash'
export default {
    name: 'Home',
    components: { DtlPopup },
    mixins: [CommonMixin],

    /*name: "disabled_dates",
  components: { DateRangePicker },*/

    data() {
        return {
            // forms: new BasPdmProdBrwsMgmtParam(),
            // basProdMgmtDis: new BasProdMgmtDis(),
            gridObj1: {},
            gridObj2: {},
            gridHeaderObj1: {},
            objAuth: {
                screenNo: this.$route.meta.breadcrumb,
            },
            inputValue: '',
            //gridData1: this.gridSetData(this.rowCnt),
            gridData1: new CommonGrid('', '', '', ''),
            gridData2: new CommonGrid('', '', '', ''),
            codeIDView: true,
            codeIDViewVal: '',
            value1: '',
            value2: '',
            list01: [],
            list02: [],
            view1: WIRELESS_HEADER,
            view2: WIRELESS_HEADER,
            delRow: [],
            addRow: [],
            basSuplSvcAddList: [],
            basSuplSvcDelList: [],
            finalParam: {},
            commIdPrcplnClCd: 'ZBAS_C_00320',
            forms: {
                wrcellClCd: '', // 유무선구분
                suplSvcClCd: '', // 서비스구분
                prodStCd: '', // 상품상태
                suplSvcCdNm: '', // 서비스코드/명
            },
            //rowCnt: 200,
            //rowCnt2: 200,
            //activePage: 1, // 현재페이지
            showDtlPopup: false,
            searchPopParam: {
                wrcellClCd: '', // 유무선구분
                suplSvbcCd: '', // 부가서비스코드
            },
            checkbox: true,
            radio1: null,
            radios: null,
            options: [
                {
                    value: 'Option1',
                    label: 'Option1',
                },
                {
                    value: 'Option2',
                    label: 'Option2',
                    disabled: true,
                },
                {
                    value: 'Option3',
                    label: 'Option3',
                },
                {
                    value: 'Option4',
                    label: 'Option4',
                },
                {
                    value: 'Option5',
                    label: 'Option5',
                },
            ],
            items: ['Option1', 'Option2', 'Option3', 'Option4'],
            switch1: true,
            switch2: false,
            value: '',
            Yn: [
                {
                    codeId: 'Y',
                    codeNm: 'Y',
                },
                {
                    codeId: 'N',
                    codeNm: 'N',
                },
            ],
            gridStyle: {
                height: '455px', //그리드 높이 조절
            },
            gridStyle2: {
                height: '478px', //그리드 높이 조절
            },
            /*dateRange: {
        startDate: "",
        endDate: "",
      },*/
        }
    },
    mounted() {
        this.gridObj1 = this.$refs.grid1
        this.gridObj2 = this.$refs.grid2

        /*
         * indicatorBl  : 인디게이터 사용여부
         * stateBarBl   : 상태바 사용여부
         * checkBarBl   : 체크바 사용여부
         * footerBl     : Footer 사용여부
         */
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj1.setGridState(false, false, true, false)
        this.gridObj2.setGridState(false, false, true, false)
        this.gridObj1.gridView.checkBar.fieldName = 'chk'
        this.gridObj2.gridView.checkBar.fieldName = 'chk'
        this.gridObj2.gridView.onCellDblClicked = (grid, clickData) => {
            if (_.isEqual(clickData.cellType, 'data')) {
                this.gridObj2.dataProvider.setValue(
                    clickData.dataRow,
                    'chk',
                    true
                )
                this.onClickLeftBtn()
            }
        }
        this.gridObj1.gridView.onCellDblClicked = (grid, clickData) => {
            if (_.isEqual(clickData.cellType, 'data')) {
                this.gridObj1.dataProvider.setValue(
                    clickData.dataRow,
                    'chk',
                    true
                )
                this.onClickRightBtn()
            }
        }
        if (!_.isEmpty(this.forms.wrcellClCd)) {
            this.isDisabledWrcelClCd = true
        } else {
            this.forms.wrcellClCd = '1'
        }
        // 그리드내의 상품코드 돋보기 클릭시 이벤트처리
        this.gridObj1.gridView.onCellButtonClicked = (
            grid,
            itemIndex,
            column
        ) => {
            this.gridObj1.gridView.commit()
            if (column.fieldName === 'suplSvcCd') {
                this.searchPopParam.suplSvcCd = grid.getValue(
                    itemIndex.itemIndex,
                    'suplSvcCd'
                )
                this.searchPopParam.wrcellClCd = this.forms.wrcellClCd
                this.onDealcoIconClick()
            }
        }
        // 그리드내의 상품코드 돋보기 클릭시 이벤트처리
        this.gridObj2.gridView.onCellButtonClicked = (
            grid,
            itemIndex,
            column
        ) => {
            this.gridObj2.gridView.commit()
            if (column.fieldName === 'suplSvcCd') {
                this.searchPopParam.suplSvcCd = grid.getValue(
                    itemIndex.itemIndex,
                    'suplSvcCd'
                )
                this.searchPopParam.wrcellClCd = this.forms.wrcellClCd
                this.onDealcoIconClick()
            }
        }
    },
    methods: {
        gridSetData: function () {
            return new CommonGrid('', '', '', '')
        },
        filterPrcplnClCd(items) {
            return items.filter((item) => item['commCdVal'] !== '6')
        },
        //Grid Init
        /*gridSetData: function (rowCnt) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, rowCnt, '', '')
        },*/
        /*gridSetData2: function (rowCnt2) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, rowCnt2, '', '')
        },*/

        //페이지 표시 행의수 변경처리
        /*chgRowCnt(val) {
            this.rowCnt = val
        },*/
        //페이지 표시 행의수 변경처리
        /*chgRowCnt2(val) {
            this.rowCnt2 = val
        },*/
        //조회 버튼 이벤트
        searchBtn: function () {
            //첫 조회시 표시할 행의 갯수
            //this.forms.pageSize = this.rowCnt
            //this.forms.pageNum = 1 //첫번째 페이지
            //this.gridData1.totalPage = 0 // 이전페이지정보 초기화
            //this.gridData2.totalPage = 0 // 이전페이지정보 초기화
            this.getPproductListList()
            this.delRow = []
        },
        /*getProductPagingList(page) {
            this.forms.pageNum = page //첫번째 페이지
            this.delRow = []
            console.log('forms', this.forms)
            basPdmAgnSvcMgmt
                .getAgnSvcIncludeList(this.forms)
                .then((resultData) => {
                    this.searchForms = this.forms //검색조건 저장
                    console.log('getAgnSvcIncludeList resultData ', resultData)
                    this.gridObj1.setRows(resultData.gridList)
                    this.gridData1 = this.gridSetData() //초기화
                    this.gridData1.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    console.log('조회완료')
                })
            if (this.forms.wrcellClCd === '1') {
                this.gridObj1.gridView.columnByName('basAmt').visible = true
                this.gridObj1.gridView.columnByName(
                    'detailType'
                ).visible = false
                this.gridObj2.gridView.columnByName('basAmt').visible = true
                this.gridObj2.gridView.columnByName(
                    'detailType'
                ).visible = false
            } else if (this.forms.wrcellClCd === '2') {
                this.gridObj1.gridView.columnByName('basAmt').visible = false
                this.gridObj1.gridView.columnByName('detailType').visible = true
                this.gridObj2.gridView.columnByName('basAmt').visible = false
                this.gridObj2.gridView.columnByName('detailType').visible = true
            }
        },*/
        /*getProductPagingList2(page) {
            this.forms.pageNum = page //첫번째 페이지
            console.log('forms', this.forms)
            basPdmAgnSvcMgmt
                .getAgnSvcExcludeList(this.forms)
                .then((resultData) => {
                    this.searchForms = this.forms //검색조건 저장
                    console.log('getAgnSvcIncludeList resultData ', resultData)
                    this.gridObj2.setRows(resultData.gridList)
                    this.gridData2 = this.gridSetData() //초기화
                    this.gridData2.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    console.log('조회완료')
                })
            if (this.forms.wrcellClCd === '1') {
                this.gridObj1.gridView.columnByName('basAmt').visible = true
                this.gridObj1.gridView.columnByName(
                    'detailType'
                ).visible = false
                this.gridObj2.gridView.columnByName('basAmt').visible = true
                this.gridObj2.gridView.columnByName(
                    'detailType'
                ).visible = false
            } else if (this.forms.wrcellClCd === '2') {
                this.gridObj1.gridView.columnByName('basAmt').visible = false
                this.gridObj1.gridView.columnByName('detailType').visible = true
                this.gridObj2.gridView.columnByName('basAmt').visible = false
                this.gridObj2.gridView.columnByName('detailType').visible = true
            }
        },*/
        // API 호출
        getPproductListList() {
            //this.forms.pageNum = page //첫번째 페이지
            console.log('forms', this.forms)
            basPdmAgnSvcMgmt
                .getAgnSvcIncludeList(this.forms)
                .then((resultData) => {
                    this.searchForms = this.forms //검색조건 저장
                    console.log('getAgnSvcIncludeList resultData ', resultData)
                    this.gridObj1.setRows(resultData)
                    this.gridData1 = this.gridSetData() //초기화
                    //this.gridData1.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    console.log('조회완료')
                })
            basPdmAgnSvcMgmt
                .getAgnSvcExcludeList(this.forms)
                .then((resultData) => {
                    this.searchForms = this.forms //검색조건 저장
                    console.log(' getAgnSvcExcludeListresultData ', resultData)
                    //this.gridObj2.setRows(resultData.gridList)
                    this.gridObj2.setRows(resultData)
                    this.gridData2 = this.gridSetData() //초기화
                    //this.gridData2.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    console.log('조회완료')
                })
            if (this.forms.wrcellClCd === '1') {
                this.gridObj1.gridView.columnByName('basAmt').visible = true
                this.gridObj1.gridView.columnByName(
                    'wireProdClNm'
                ).visible = false
                this.gridObj2.gridView.columnByName('basAmt').visible = true
                this.gridObj2.gridView.columnByName(
                    'wireProdClNm'
                ).visible = false
            } else if (this.forms.wrcellClCd === '2') {
                this.gridObj1.gridView.columnByName('basAmt').visible = false
                this.gridObj1.gridView.columnByName(
                    'wireProdClNm'
                ).visible = true
                this.gridObj2.gridView.columnByName('basAmt').visible = false
                this.gridObj2.gridView.columnByName(
                    'wireProdClNm'
                ).visible = true
            }
        },
        //엑셀다운로드 - 운영 상품
        includeDownload() {
            const rowCount = this.gridObj1.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/pdm/agnSuplSvcIncludeExcelList',
                this.searchForms
            )
        },
        //엑셀다운로드 - 미운영 상품
        excludeDownload() {
            const rowCount = this.gridObj2.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/pdm/agnSuplSvcExcludeExcelList',
                this.searchForms
            )
        },
        onClickRightBtn() {
            console.log('onClickRightBtn')

            let rowIdxs = this.gridObj1.gridView.getCheckedRows()
            let rows = this.gridObj1.dataProvider.getJsonRows()

            let rightRows = []

            rightRows = this.gridObj2.dataProvider.getJsonRows()

            let newRows = []
            rowIdxs.forEach((n) => {
                rows.forEach((v, i) => {
                    if (n === i) {
                        if (!_.isEmpty(v.suplSvcCd)) {
                            if (
                                rightRows.filter((f) =>
                                    f.suplSvcCd.includes(v.suplSvcCd)
                                ).length === 0
                            ) {
                                this.delRow.push(v)
                                newRows.push(v)
                            }
                        }
                    }
                })
            })
            console.log('delRow', this.delRow)
            this.gridObj1.dataProvider.beginUpdate()
            this.gridObj1.dataProvider.removeRows(rowIdxs)
            this.gridObj1.dataProvider.endUpdate()

            this.gridObj2.dataProvider.beginUpdate()
            this.gridObj2.dataProvider.addRows(newRows)
            this.gridObj2.dataProvider.endUpdate()
        },
        onClickLeftBtn() {
            console.log('onClickLeftBtn')

            let rowIdxs = this.gridObj2.gridView.getCheckedRows()
            let rows = this.gridObj2.dataProvider.getJsonRows()

            let rightRows = []

            rightRows = this.gridObj1.dataProvider.getJsonRows()

            let newRows = []

            rowIdxs.forEach((n) => {
                rows.forEach((v, i) => {
                    if (n === i) {
                        if (!_.isEmpty(v.suplSvcCd)) {
                            if (
                                rightRows.filter((f) =>
                                    f.suplSvcCd.includes(v.suplSvcCd)
                                ).length === 0
                            ) {
                                _.remove(this.delRow, {
                                    suplSvcCd: v.suplSvcCd,
                                })
                                newRows.push(v)
                            }
                        }
                    }
                })
            })
            console.log('delRow', this.delRow)
            this.gridObj2.dataProvider.beginUpdate()
            this.gridObj2.dataProvider.removeRows(rowIdxs)
            this.gridObj2.dataProvider.endUpdate()

            this.gridObj1.dataProvider.beginUpdate()
            this.gridObj1.dataProvider.addRows(newRows)
            this.gridObj1.dataProvider.endUpdate()
        }, //저장 버튼 이벤트
        onSave: function () {
            let addData = []
            //let delData = []
            let addIndexArr = this.gridObj1.modifyGrid() // 추가/수정 건 체크

            for (let idx = 0; idx < addIndexArr.length; idx++) {
                let getJson = this.gridObj1.dataProvider.getJsonRow(
                    addIndexArr[idx]
                )
                addData.push(getJson)
            }

            this.finalParam = {
                basSuplSvcAddList: addData,
                basSuplSvcDelList: this.delRow,
            }
            console.log('finalParam:', this.finalParam)
            console.log(
                '변경사항여부:',
                this.finalParam.basSuplSvcAddList.length,
                this.finalParam.basSuplSvcDelList.length
            )
            if (
                this.finalParam.basSuplSvcAddList.length > 0 ||
                this.finalParam.basSuplSvcDelList.length > 0
            ) {
                this.saveSuplSvcList(this.finalParam)
            }
        },

        saveSuplSvcList(finalParam) {
            console.log('saveSuplSvcList')
            //그리드 validation
            basPdmAgnSvcMgmt.saveSuplSvcList(finalParam).then((res) => {
                if (res) {
                    this.showTcComAlert('저장 완료하였습니다.', {
                        header: 'Grid Data 저장',
                        size: '500',
                        confirmLabel: 'OK',
                    })

                    console.log('저장완료')
                }

                this.getPproductListList()
                this.delRow = []
            })
        },
        onChangeWrcellClCd() {
            console.log('onChangeWrcellClCd::', this.forms.wrcellClCd)
            if (this.forms.wrcellClCd === '1') {
                this.commIdPrcplnClCd = 'ZBAS_C_00320'
            } else if (this.forms.wrcellClCd === '2') {
                this.commIdPrcplnClCd =
                    'ZBAS_C_00320' /*AS-IS 버전 유선 부가상품구분 ZBAS_C_00321*/
            }
        },
        // 상품코드 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            console.log(
                'pop param prodCd',
                this.searchPopParam.suplSvbcCd,
                this.searchPopParam.wrcellClCd
            )

            this.showDtlPopup = true
        },
        // 초기화
        onResetPage() {
            this.gridObj1.dataProvider.clearRows()
            this.gridObj2.dataProvider.clearRows()
            this.delRow = []
            this.forms = {
                wrcellClCd: '1', // 유무선구분
                suplSvcClCd: '', // 서비스구분
                prodStCd: '', // 상품상태
                suplSvcCdNm: '', // 서비스코드/명
            }
        },
    },
    computed: {},
    watch: {},
}
</script>
