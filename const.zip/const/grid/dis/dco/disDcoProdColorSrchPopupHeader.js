import { ValueType } from 'realgrid'

export const DisDcoProdColorSrchGRID_HEADER = {
    fields: [
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
    ],
    columns: [
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: '240',
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            visible: false,
            type: 'data',
        },
    ],
}
