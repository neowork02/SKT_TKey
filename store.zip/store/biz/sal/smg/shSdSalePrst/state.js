export default {
    //alert message
    alertShow: false,
    alertHeaderText: '',
    alertBodyText: '',
    loadingShow: false,
    snackbar: false,
    snackbarText: '',
    //paging
    paging: {
        pageNum: 1, //fix
        pageSize: 15,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    paging2: {
        pageNum: 1, //fix
        pageSize: 15,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    paging3: {
        pageNum: 1, //fix
        pageSize: 15,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging: {
        pageNum: 1, //fix
        pageSize: 15, //전체 조회:9999
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging2: {
        pageNum: 1, //fix
        pageSize: 15, //전체 조회:9999
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging3: {
        pageNum: 1, //fix
        pageSize: 15, //전체 조회:9999
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    saveAction: false,
    saveDoneA: false,
    saveDoneB: false,

    commDropDown: {},

    commCdIds: [],
    resultList: [],
    resultList2: [],
    resultList3: [],
    resultDetailList: [],

    searchParams: {},
    popupParams: {},

    searchCl: '',
}
