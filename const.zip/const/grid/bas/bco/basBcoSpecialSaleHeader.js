import { ValueType } from 'realgrid'

export const SALE_HEADER = {
    fields: [
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStatus',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStaDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndDt',
            dataType: ValueType.TEXT,
        },
        /*
        {
            fieldName: 'reqYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealcoClCd2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT,
        },
        */
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoRgstClCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'dealcoRgstClCd',
            fieldName: 'dealcoRgstClCd',
            type: 'data',
            header: {
                text: '거래처등록구분',
            },
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },

            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분',
            },
        },

        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '거래처명',
            },
            width: 200,
        },
        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래상태',
            },
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '거래개시일',
            },
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '거래종료일',
            },
        },
        /*
        {
            name: 'reqYn',
            fieldName: 'reqYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청여부',
            },
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '채널코드',
            },
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업부',
            },
        },
        {
            name: 'orgCd1',
            fieldName: 'orgCd1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업담당',
            },
        },
        {
            name: 'orgCd2',
            fieldName: 'orgCd2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업팀',
            },
        },
        {
            name: 'orgCd3',
            fieldName: 'orgCd3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업파트',
            },
        },
        {
            name: 'dealcoGrpCd',
            fieldName: 'dealcoGrpCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처그룹',
            },
        },

        {
            name: 'dealcoClCd2',
            fieldName: 'dealcoClCd2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처유형',
            },
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처코드',
            },
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고보유처코드',
            },
        },
        */
    ],
}
