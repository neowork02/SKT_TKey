<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1500px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">메뉴등록</p>
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap mt20">
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComComboBox
                                    labelName="1차메뉴"
                                    v-model="forms.menuNo1"
                                    :codeVal.sync="forms.menuNo1"
                                    :objAuth="objAuth"
                                    :itemList="menuNmList1"
                                    @change="onChange1"
                                    itemText="menuNm"
                                    itemValue="menuNo"
                                    :eRequired="true"
                                    :disabled="menuNo1Dis"
                                >
                                </TCComComboBox>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="1차메뉴NO"
                                    v-model="forms.menuNo1"
                                    :disabled="true"
                                    :eRequired="true"
                                    placeholder="1차메뉴선택시자동입력"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComComboBox
                                    labelName="2차메뉴"
                                    v-model="forms.menuNo2"
                                    :codeVal.sync="forms.menuNo2"
                                    :itemList="menuNmList2"
                                    :objAuth="objAuth"
                                    @change="onChange2"
                                    itemText="menuSupNm"
                                    itemValue="menuSupNo"
                                    :addBlankItem="true"
                                    blankItemText="메뉴선택"
                                    blankItemValue=""
                                    :eRequired="true"
                                    :disabled="menuNo2Dis"
                                >
                                </TCComComboBox>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="2차메뉴NO"
                                    v-model="forms.menuNo2"
                                    :disabled="true"
                                    :eRequired="true"
                                    placeholder="2차메뉴선택시자동입력"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform" v-if="menu3Dis">
                            <div class="formitem div2">
                                <TCComComboBox
                                    labelName="3차메뉴"
                                    v-model="forms.menuNo3"
                                    :codeVal.sync="forms.menuNo3"
                                    @change="onChange3"
                                    :itemList="menuNmList3"
                                    :objAuth="objAuth"
                                    itemText="menuSupNm"
                                    itemValue="menuSupNo"
                                    :addBlankItem="true"
                                    blankItemText="메뉴선택"
                                    blankItemValue=""
                                    :eRequired="true"
                                    :disabled="menuNo3Dis"
                                >
                                </TCComComboBox>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="3차메뉴NO"
                                    v-model="forms.menuNo3"
                                    :disabled="true"
                                    :eRequired="true"
                                    placeholder="3차메뉴선택시자동입력"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComComboBox
                                    labelName="4차메뉴"
                                    v-model="forms.menuNo4"
                                    :codeVal.sync="forms.menuNo4"
                                    @change="onChange4"
                                    :itemList="menuNmList4"
                                    :objAuth="objAuth"
                                    itemText="menuSupNm"
                                    itemValue="menuSupNo"
                                    :addBlankItem="true"
                                    blankItemText="메뉴선택"
                                    blankItemValue=""
                                    :eRequired="true"
                                    :disabled="menuNo4Dis"
                                >
                                </TCComComboBox>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="4차메뉴NO"
                                    v-model="forms.menuNo4"
                                    :disabled="true"
                                    :eRequired="true"
                                    placeholder="4차메뉴선택시자동입력"
                                ></TCComInput>
                            </div>
                        </div>

                        <div class="searchform">
                            <div class="formitem div1">
                                <span class="inner">
                                    <TCComInput
                                        labelName="4차메뉴URL"
                                        v-model="forms.menuUrl4"
                                        :disabled="true"
                                        @input="onChange4"
                                        :eRequired="true"
                                    ></TCComInput>
                                </span>
                            </div>
                        </div>
                        <div class="searchform">&nbsp;</div>

                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="SCREEN NO"
                                    v-model="authForms.screenNo"
                                    placeholder="입력하세요"
                                    :eRequired="true"
                                ></TCComInput>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="SCREEN 명"
                                    v-model="authForms.screenNm"
                                    placeholder="입력하세요"
                                    :eRequired="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <span class="inner">
                                    <TCComInput
                                        labelName="SCREEN URL"
                                        v-model="authForms.screenUrl"
                                        :eRequired="true"
                                        placeholder="입력하세요"
                                    ></TCComInput>
                                </span>
                            </div>

                            <div class="formitem div2">
                                <TCComComboBox
                                    labelName="화면유형코드"
                                    v-model="authForms.screenTypCd"
                                    :eRequired="true"
                                    :itemList="itemList3"
                                    itemText="commCdValNm"
                                    itemValue="commCdVal"
                                ></TCComComboBox>
                            </div>
                        </div>
                        <div class="searchform">&nbsp;</div>
                        <div class="searchform">
                            <div
                                class="formitem div5"
                                v-for="(cValue, cKey) in authCheckBoxList"
                                v-bind:key="cKey"
                            >
                                <div class="leftArea">
                                    <v-checkbox
                                        v-model="
                                            authCheckBoxList[`${cKey}`].checkCk
                                        "
                                        :label="`${cValue.commGroupNm} : ${cValue.commAuthNo}`"
                                        color="point"
                                        @change="checkeChange(`${cKey}`)"
                                    >
                                    </v-checkbox>

                                    <span class="iteminput">
                                        <v-select
                                            v-model="
                                                authCheckBoxList[`${cKey}`]
                                                    .comboAuthNm
                                            "
                                            :items="
                                                selectCombo[
                                                    `${cValue.commAuthNo}`
                                                ].authArr
                                            "
                                            dense
                                            outlined
                                            color="basiccont"
                                            item-text="selectKey"
                                            item-value="selectVal"
                                            @input="
                                                comboChange(
                                                    `${cKey}`,
                                                    `${cValue.commAuthNo}`
                                                )
                                            "
                                        ></v-select>
                                    </span>

                                    <TCComInput
                                        labelName=""
                                        v-model="
                                            authCheckBoxList[`${cKey}`]
                                                .btnAuthNm
                                        "
                                        :placeholder="
                                            authCheckBoxList[`${cKey}`]
                                                .placeholderNm
                                        "
                                        @input="textChange(`${cKey}`)"
                                    ></TCComInput>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <div class="right">
                            <!-- 등록버튼 -->
                            <TCComButton
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onSave"
                                >저장</TCComButton
                            >
                            <!-- 수정버튼 -->

                            <TCComButton
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onDelete"
                                v-if="btDelDis"
                                >삭제</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onClose"
                                >목록</TCComButton
                            >
                        </div>
                    </div>

                    <!-- Close BTN(화면 우측 상단 X표시)-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >

                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import moment from 'moment'
//====================1차메뉴명====================
import menuApi from '@/api/biz/bas/adm/BasAdmScreenMgmt'
//====================//1차메뉴명====================
import _ from 'lodash'
export default {
    name: 'BasAdmScreenMgmtPop',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
    },
    data() {
        return {
            gridObj: {},
            gridData: {},
            gridHeaderObj: {},
            objAuth: {},
            forms: {
                userNm: '',
                toDate: '',
                psYn: '',
                mblYn: '',
                useYn: '',
                menuNo1: '',
                menuNm1: '',
                menuNo2: '',
                menuNm2: '',
                menuNo3: '',
                menuNm3: '',
                menuNo4: '',
                menuNm4: '',
                bfMenuNo4: '',
                bfMenuUrl4: '',
                bfScreenNo: '',
                bfScreenUrl: '',
                menuSupNo2: '',
                menuSupNo3: '',
                menuSupNo4: '',
                newMenuNm: '',
                supMenuNo: '',
                menuUrl: '',
                menuUrl4: '',
                screenUrl: '',
                screenNo: '',
                screenNm: '',
                sortSeq: '',
                screenId: '',
                readType: '',
            },
            authForms: {
                menuNo: '',
                screenUrl: '',
                screenNo: '',
                screenNm: '',
                bfScreenNo: '',
                bfScreenUrl: '',
                screenTypCd: '',
                delYn: '',
            },
            ckParam: {
                psYn: 'Y',
                mblYn: 'N',
                useYn: 'Y',
            },

            itemList: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '사용',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: '미사용',
                },
            ],
            itemList1: [
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
            itemList3: [
                {
                    commCdVal: 'S',
                    commCdValNm: '화면',
                },
                {
                    commCdVal: 'P',
                    commCdValNm: '팝업',
                },
                {
                    commCdVal: 'T',
                    commCdValNm: 'TAB',
                },
            ],
            disableEl: true,
            menuNmList1: [],
            menuNmList2: [],
            menuNmList3: [],
            menuNmList4: [],

            authCheckBoxList: [],

            authCheckSaveList: [],

            //sameCd: 'N',
            readType: '',

            menu3Dis: true,
            menuNo1Dis: true,
            menuNo2Dis: true,
            menuNo3Dis: true,
            menuNo4Dis: true,
            selectCombo: {},
            btDelDis: true,
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.forms.menuNo4 =
                    value['menuNo4'] == undefined ? '' : value['menuNo4']
                this.readType =
                    value['readType'] == undefined ? '' : value['readType']
                this.forms.screenNo =
                    value['screenNo'] == undefined ? '' : value['screenNo']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {},
    mounted() {
        //this.forms.userNm = this.userInfo.userNm
        this.forms.toDate = moment(new Date()).format('YYYY-MM-DD h:mm:ss')
        //수정모드
        if ('U' == this.readType) {
            this.searchDetailMenu()

            //메뉴콤보박스수정못하게
            this.menuNo1Dis = true
            this.menuNo2Dis = true
            this.menuNo3Dis = true
            this.menuNo4Dis = true

            //복사모드
        } else if ('B' == this.readType) {
            this.searchDetailMenu()

            //메뉴콤보박스수정못하게
            this.menuNo1Dis = true
            this.menuNo2Dis = true
            this.menuNo3Dis = true
            this.menuNo4Dis = true

            this.forms.screenNo = ''
        } else {
            //C:신규모드
            this.forms.menuNo4 = ''
            this.forms.menuNm4 = ''
            this.forms.screenNo = ''

            //메뉴콤보박스수정가능
            this.menuNo1Dis = false
            this.menuNo2Dis = false
            this.menuNo3Dis = false
            this.menuNo4Dis = false

            //첫번째콤보박스로딩
            this.onInitChange()
        }

        //screen auth cd 나열
        this.getScreenAuthList()
    },
    methods: {
        onClose() {
            this.activeOpen = false
        },
        onConfirm() {},
        /*
        onClick() {
            console.log('forms', this.forms)
        },
        */
        //모든 속성값을 가져온다. 기본뼈대 + 수정일경우 선택한 값까지
        async getScreenAuthList() {
            let screenUrl = ''
            let screenNo = ''
            let screenNm = ''
            //let menuNo = '' 등록이거나 AUTH 에 없을경우 MENU_NO를 가져올수 없어 제거.
            let bfScreenNo = ''
            let bfScreenUrl = ''
            let screenTypCd = ''

            await menuApi.getScreenAuthList(this.forms).then((resultData) => {
                let menuNmArr = []
                let bfCommAuthNo = ''
                let selectObject = {}
                let nextCommAuthNo = ''
                let resultDataLen = resultData.length
                let authArr = []

                resultData.forEach((v, idx) => {
                    //상위값 1개로우만 가져옴. auth저장시 사용.
                    if (0 == idx) {
                        screenUrl = v.screenUrl
                        screenNo = v.screenNo
                        screenNm = v.screenNm
                        //menuNo = v.menuNo
                        bfScreenNo = v.bfScreenNo
                        bfScreenUrl = v.bfScreenUrl
                        screenTypCd = v.screenTypCd
                    }

                    //console.log('bfScreenUrl===>', bfScreenUrl)
                    //console.log('nextCommAuthNo:::' + nextCommAuthNo)

                    //##########체크값객체생성영역(코드당 한개씩 생성)
                    //중복되지않는 체크값배열생성.
                    if (bfCommAuthNo != v.commAuthNo) {
                        menuNmArr.push({
                            commAuthNo: v.commAuthNo,
                            checkCk: v.checkCk == 'Y' ? true : false,
                            btnAuthNm: v.btnAuthNm,
                            comboAuthNm: v.btnAuthNm,
                            commGroupNm: v.commGroupNm,
                            placeholderNm: '',
                        })
                    }
                    //##########체크값객체생성영역

                    //##########콤보박스객체생성영역(코드당 콤보가 여러개일수있다)
                    //다음에나올코드를 비교를위해 저장한다.
                    //console.log('resultDataLen:::' + resultDataLen, idx)
                    if (idx + 1 < resultDataLen) {
                        nextCommAuthNo = resultData[idx + 1].commAuthNo
                    } else {
                        nextCommAuthNo = 'END'
                    }

                    //이전값과 현재값이 다르면 배열초기화
                    if (bfCommAuthNo != v.commAuthNo) {
                        authArr = []
                    }

                    authArr.push({
                        selectAuthNo: v.commAuthNo,
                        selectKey: v.commComboNm,
                        selectVal: v.commComboNm,
                        selectCk: v.selectCk,
                    })
                    //다음값과 다르면 체크박스 코드1개당 - 콤보박스 여러개를 합친 1개배열을 완성하여 꺼낼키코드에 넣는다.
                    if (v.commAuthNo != nextCommAuthNo) {
                        selectObject[v.commAuthNo] = { authArr }
                    }
                    //이전코드
                    bfCommAuthNo = v.commAuthNo
                    //##########콤보박스객체생성영역
                })

                //console.log('selectObject:======>', selectObject)
                //중복제거한 체크박스키 배열에 저장.
                this.authCheckBoxList = menuNmArr
                //콤보박스 객체에 담는다.
                this.selectCombo = selectObject
            })

            //중간 screenAuth 작성부분에 데이터를 로드한다.
            this.authForms.screenUrl = screenUrl
            this.authForms.screenNo = screenNo
            this.authForms.screenNm = screenNm
            this.authForms.menuNo = this.forms.menuNo4 //부모에서 가져온값으로 셋팅(등록이나 수정시 AUTH에 없으면 가져올수없음.)
            this.authForms.bfScreenNo = bfScreenNo
            this.authForms.bfScreenUrl = bfScreenUrl
            this.authForms.screenTypCd = screenTypCd

            //스크린NO가 존재하지 않는경우는 TADM_SCREEN 에 값이 없는경우이므로 삭제버튼을 안보이게 처리한다.
            if (!screenNo) {
                this.btDelDis = false
            }

            //console.log('this.selectCombo:======>', this.selectCombo)
            /*
            console.log(
                '꺼내기 - this.selectCombo:======>',
                this.selectCombo['101'].authArr
            )
            */
            //console.log('authCheckBoxList:', this.authCheckBoxList)
        },
        async searchDetailMenu() {
            await menuApi.searchDetailMenu(this.forms).then((resultData) => {
                console.log('resultData', resultData)
                //detail값 null 인경우 '' 로 변경처리
                //----------------------------------------
                let rData = resultData[0]
                this.forms = rData
                //--------------------------------------
                //console.log('this.forms:', this.forms)
                //console.log('this.forms.bfMenuNo4:', this.forms.bfMenuNo4)
                //console.log('this.forms.bfMenuUrl4:', this.forms.bfMenuUrl4)

                this.ckParam.mblYn = this.forms.mblYn
                this.ckParam.psYn = this.forms.psYn
                this.ckParam.useYn = this.forms.useYn

                //신규모드일때는 콤보박스선택이 수동으로 이루어진다.
                if ('C' != this.readType) {
                    //첫번째콤보박스로딩
                    this.onInitChange()
                    //결과로나온 1번코드값을 넣어 2번콤보박스를 change 해 ->2번메뉴나열
                    this.onChange1(this.forms.menuNo1)
                    //결과로나온 2번코드값을 넣어 3번콤보박스를 change 해 ->3번메뉴나열
                    this.onChange2(this.forms.menuNo2)

                    //결과로나온 3번코드값을 넣어 4번콤보박스를 change 해 ->4번메뉴나열
                    if (null != this.forms.menuNo3) {
                        this.onChange3(this.forms.menuNo3, 'menuNo3')
                    }

                    //4번코드를 넣는다
                    this.onChange4(this.forms.menuNo4)
                }
            })
        },
        async onInitChange() {
            await menuApi.getMemuLvlList(this.forms).then((resultData) => {
                let menuNmArr = [{ menuNo: '', menuNm: '메뉴선택' }] //1차메뉴이름
                resultData.forEach((v) => {
                    menuNmArr.push(v)
                })
                this.menuNmList1 = menuNmArr
            })
        },
        //1차콤보박스 선택시
        async onChange1(value) {
            //신규모드일때는 onChage1이 가능하므로 변경시 초기화
            if ('C' == this.readType) {
                this.formClear()
            }
            console.log('onChange1 value: ', value)

            //NO자동 추가
            this.forms.menuNo1 = value

            //DB
            this.forms.supMenuNo = value
            //가져올lvl
            this.forms.menuLvlCd = '2'

            await menuApi.getMemuLvlSupList(this.forms).then((resultData) => {
                console.log('resultData', resultData)
                let menuSupNmArr = []
                resultData.forEach((v) => {
                    menuSupNmArr.push(v)
                })

                this.menuNmList2 = menuSupNmArr
            })
        },
        //2차콤보박스선택시
        async onChange2(value) {
            if ('C' == this.readType) {
                this.forms.menuNo3 = ''
                this.forms.menuNo4 = ''
                this.forms.menuUrl4 = ''
                this.menuNmList3 = []
            }
            console.log('onChange2 value: ', value)

            //NO자동 추가
            this.forms.menuNo2 = value

            //this.sameCd = 'N'
            this.forms.supMenuNo = value
            //가져올lvl
            this.forms.menuLvlCd = '3'
            let menuSupNmArr = []
            await menuApi.getMemuLvlSupList(this.forms).then((resultData) => {
                console.log('resultData', resultData)

                if (0 < resultData.length) {
                    this.menu3Dis = true
                    resultData.forEach((v) => {
                        menuSupNmArr.push(v)
                        this.menuNmList3 = menuSupNmArr
                    })
                } else {
                    //3차 가 존재하지 않을경우 2차코드 넣어 4차 확인.
                    this.onChange3(value, 'menuNo2')
                }
            })
        },
        //3차콤보박스선택시
        async onChange3(value, selectCd) {
            if ('C' == this.readType) {
                this.forms.menuNo4 = ''
                this.forms.menuUrl4 = ''
            }
            console.log('onChange3 value: ', value)

            //2번코드일때 노출되는 input값에 추가하지않음
            if ('menuNo2' == selectCd) {
                this.forms.menuNo3 = ''
                this.menu3Dis = false
            } else {
                this.forms.menuNo3 = value
                this.menu3Dis = true
            }

            this.forms.supMenuNo = value

            this.forms.menuLvlCd = '4'
            let menuSupNmArr = []
            await menuApi.getMemuLvlSupList(this.forms).then((resultData) => {
                console.log('resultData', resultData)

                resultData.forEach((v) => {
                    menuSupNmArr.push(v)
                })

                this.menuNmList4 = menuSupNmArr
            })
        },
        onChange4(value) {
            console.log(value)
            //변경시 중복확인 N으로 변경
            //신규모드일때는 4차 선택시 상세가져오는 function으로 상세 내역 URL 가져옴.
            if ('C' == this.readType) {
                this.forms.menuUrl4 = ''
                this.searchDetailMenu()
            }
        },
        formDataSet(mode) {
            let saveForms = {}
            let authArr = []
            let cnt = 0
            //신규, 수정, 복사 -> 최종 4차메뉴no를 넣는다.
            this.authForms.menuNo = this.forms.menuNo4
            //삭제시에 delYn 추가
            if ('D' == mode) {
                this.authForms.delYn = 'Y'
            }

            //전체 auth code중 체크된것만 배열에 셋팅
            this.authCheckBoxList.forEach((v) => {
                if (v.checkCk) {
                    authArr.push({
                        menuNo: this.authForms.menuNo,
                        screenNo: this.authForms.screenNo,
                        bfScreenNo: this.authForms.bfScreenNo,
                        bfScreenUrl: this.authForms.bfScreenUrl,
                        screenNm: this.authForms.screenNm,
                        screenUrl: this.authForms.screenUrl,
                        screenTypCd: this.authForms.screenTypCd,
                        sortSeq: cnt,
                        btnAuthNo: v.commAuthNo,
                        btnAuthNm: v.comboAuthNm,
                        commGroupNm: v.commGroupNm,
                    })

                    cnt++
                }
            })

            this.authCheckSaveList = authArr

            saveForms = {
                //SCREEN NO, SCREEN NM, SCREEN URL, 화면유형코드 셋팅.
                basAdmScreenVo: this.authForms,
                //auth 배열내용셋팅
                authCheckSaveList: this.authCheckSaveList,
            }

            console.log('saveForms===>', saveForms)

            return saveForms
        },
        //수정
        onSave() {
            if (!this.onValidate()) {
                return
            }

            this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                if (confirm) {
                    let params = {}
                    //배열파라미터셋팅
                    params = this.formDataSet()
                    //저장실행
                    menuApi.saveScreenMgmt(params).then((resultData) => {
                        console.log('resultData', resultData)

                        if ('Y' == resultData.screenNoSameYn) {
                            this.showTcComAlert(
                                '저장되지 않았습니다. 동일한 SCREEN명 이 존재합니다.',
                                {
                                    header: '확인',
                                    size: '500',
                                    confirmLabel: 'OK',
                                }
                            )
                        } else if ('Y' == resultData.screenUrlSameYn) {
                            this.showTcComAlert(
                                '저장되지 않았습니다. 동일한 SCREEN URL 이 존재합니다.',
                                {
                                    header: '확인',
                                    size: '500',
                                    confirmLabel: 'OK',
                                }
                            )
                        } else {
                            this.$emit('confirm', resultData)
                            this.onClose()
                        }
                    })
                }
            })
        },
        onDelete() {
            this.showTcComConfirm('삭제 하시겠습니까?').then((confirm) => {
                if (confirm) {
                    let params = {}
                    //배열파라미터셋팅
                    //this.authForms.delYn = 'Y'
                    params = this.formDataSet('D')

                    //저장실행
                    menuApi.saveScreenMgmt(params).then((resultData) => {
                        if ('DF' == resultData.delF) {
                            this.showTcComAlert(
                                'SCREEN NO 변경으로 삭제 실패하였습니다.',
                                {
                                    header: '확인',
                                    size: '500',
                                    confirmLabel: 'OK',
                                }
                            )
                        } else {
                            this.$emit('confirm', resultData)
                            this.onClose()
                        }
                    })
                    //console.log('resultData', resultData)
                }
            })
        },
        onSameCk() {
            //중복확인 성공여부
            //this.sameCd = 'Y'
        },
        onValidate() {
            if (_.isEmpty(this.forms.menuNm4)) {
                this.showTcComAlert('4차 메뉴명을 입력해주세요.')
                return false
            }

            if (_.isEmpty(this.forms.menuNo4)) {
                this.showTcComAlert('4차 메뉴NO를 입력해주세요.')
                return false
            }

            if (_.isEmpty(this.authForms.screenNo)) {
                this.showTcComAlert('SCREEN NO를 입력해주세요.')
                return false
            }

            if (_.isEmpty(this.authForms.screenNm)) {
                this.showTcComAlert('SCREEN명를 입력해주세요.')
                return false
            }

            if (_.isEmpty(this.authForms.screenUrl)) {
                this.showTcComAlert('SCREEN URL을 입력해주세요.')
                return false
            }

            if (_.isEmpty(this.authForms.screenTypCd)) {
                this.showTcComAlert('화면유형코드를 입력해주세요.')
                return false
            }
            let chbAuth = true
            let chbMsg = ''
            this.authCheckBoxList.forEach((v) => {
                if (v.checkCk) {
                    if (_.isEmpty(_.trim(v.comboAuthNm))) {
                        chbAuth = false
                        chbMsg = v.commGroupNm + ' : ' + v.commAuthNo
                        //console.log(v.comboAuthNm)
                    }
                }
            })

            if (!chbAuth) {
                this.showTcComAlert(chbMsg + ' 의 필수값을 입력해주세요.')
                return false
            }

            return true
        },
        formClear() {
            this.forms.menuNo2 = ''
            this.forms.menuNm2 = ''
            this.forms.menuNo3 = ''
            this.forms.menuNm3 = ''
            this.forms.menuNo4 = ''
            this.forms.menuNm4 = ''
            this.forms.menuUrl4 = ''
            this.forms.screenId = ''

            this.menuNmList2 = []
            this.menuNmList3 = []
            this.menuNmList4 = []
        },
        checkeChange(idx) {
            if (!this.authCheckBoxList[idx].checkCk) {
                this.authCheckBoxList[idx].comboAuthNm = ''
                this.authCheckBoxList[idx].btnAuthNm = ''
            }
            if (this.authCheckBoxList[idx].checkCk) {
                this.authCheckBoxList[idx].placeholderNm = '체크시필수입력'
            } else {
                this.authCheckBoxList[idx].placeholderNm = ''
            }
        },
        comboChange(idx) {
            //cKey == idx
            //console.log(idx, authNo)
            this.authCheckBoxList[idx].checkCk = true
            if (this.authCheckBoxList[idx].checkCk) {
                this.authCheckBoxList[idx].placeholderNm = '체크시필수입력'
            } else {
                this.authCheckBoxList[idx].placeholderNm = ''
            }
            this.authCheckBoxList[idx].btnAuthNm =
                this.authCheckBoxList[idx].comboAuthNm
        },
        textChange(idx) {
            //console.log(idx)
            this.authCheckBoxList[idx].checkCk = true
            if (this.authCheckBoxList[idx].checkCk) {
                this.authCheckBoxList[idx].placeholderNm = '체크시필수입력'
            } else {
                this.authCheckBoxList[idx].placeholderNm = ''
            }
            this.authCheckBoxList[idx].comboAuthNm =
                this.authCheckBoxList[idx].btnAuthNm
        },
    },
}
</script>
