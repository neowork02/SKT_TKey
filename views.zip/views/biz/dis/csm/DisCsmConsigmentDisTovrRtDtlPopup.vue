<!-----------------------------------------------
 * 업무그룹명: 수탁재고관리>수탁재고관리현황
 * 서브업무명: 수탁재고회전률관리상세
 * 설명: 수탁재고회전률관리상세를 조회한다.
 * 작성자: P179229
 * 작성일: 2022.04.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">수탁재고회전률관리 상세</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- gridWrap -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="popupGridHeader"
                            ref="popupGridHeader"
                            gridTitle="수탁재고회전률관리 상세"
                            :gridObj="gridObj"
                            :isPageRows="true"
                            :isExceldown="true"
                            @excelDownBtn="onClickDownload"
                        />
                        <TCRealGrid
                            id="popupGrid"
                            ref="popupGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>
                    <!-- // gridWrap -->
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="closeBtn"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- //Bottom BTN Group -->
                    <!-- Close BTN-->
                    <a
                        href="#none"
                        class="layerClose b-close"
                        @click="closeBtn()"
                        >닫기</a
                    >
                    <!-- //Close BTN-->
                </div>
                <!-- // Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { DisDsmTovrRtDtlGRID_HEADER } from '@/const/grid/dis/dsm/disDsmTovrRtDtlPopupHeader'
import disDsmTovrRtMgmtApi from '@/api/biz/dis/dsm/disDsmTovrRtMgmt'
import attachedFileApi from '@/api/common/attachedFile'

export default {
    name: 'DisCsmConsigmentDisTovrRtDtl',
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        dtlData: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            gridData: {},
            objAuth: {},
            view: DisDsmTovrRtDtlGRID_HEADER,
            gridObj: {},
            gridHeaderObj: {},
            reqParam: this.dtlData,
        }
    },
    created() {
        // 화면 default설정
        this.defaultSet()
    },
    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.popupGrid
        this.gridHeaderObj = this.$refs.popupGridHeader
        this.gridObj.setGridState(false, false, false)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        //상세조회
        this.searchDtl()
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        defaultSet() {
            this.gridData = this.gridSetData()
        },
        //gridSetData
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        closeBtn: function () {
            this.activeOpen = false
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dsm/disDsmTovrRtMgmtDtlExcelList',
                this.reqParam
            )
        },
        //상세 조회
        searchDtl: function () {
            disDsmTovrRtMgmtApi
                .getDisDsmTovrRtDtl(this.reqParam)
                .then((res) => {
                    //Get Row Data
                    this.gridObj.setRows(res.gridList)
                })
        },
    },
}
</script>
