/*****************************************
* 업무 그룹명 : 정책
* 서브 업무명 : B영업일수관리
* 설 명 : B영업일수관리 REST API
* 작 성 자 :
* 작 성 일 : 2022.03.28
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 : 김병희 / 2022.03.28
* 변경사유/내역 : 
======================================
*****************************************/
/**************************************************************************************************************
 * 가상데이터 선언 영역
 **************************************************************************************************************/
import send from '@/api/axios-tdcs'
// import _ from 'lodash'

export default {
    namespaced: true,
    state: {
        dsCondition: {
            saleDt: '',
            saleWght: '',
            hdayClCd: '',
        },
    },
    mutations: {
        setDsCondition(state, payload) {
            state.dsCondition = payload
        },
        setDsBsaleDayMgmtList(state, payload) {
            state.dsBsaleDayMgmtList = payload
        },
    },
    actions: {
        async getPolOperCdList({ commit }, payload) {
            console.log('getPolOperCdList::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'get',
                    url: '/api/v1/backend/pol/shd/getPolOperCdList',
                    params: payload,
                })
                    .then((res) => {
                        console.log('getBsaleDayMgmtList[then]', res)
                        commit('setDsBsaleDayMgmtList', res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
        },
    },
}
