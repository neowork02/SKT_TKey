import { ValueType } from 'realgrid'

export const DisUerDisCmpObjMgmt_GRID_HEADER = {
    fields: [
        {
            fieldName: 'disGb',
            dataType: ValueType.TEXT, //대상유형
        },
        {
            fieldName: 'disGbCd',
            dataType: ValueType.TEXT, //대상유형
        },
        {
            fieldName: 'splyStDt',
            dataType: ValueType.TEXT, //적용시작일자
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'occrQty',
            dataType: ValueType.NUMBER, //수량
        },
        {
            fieldName: 'inveCmpAmt',
            dataType: ValueType.NUMBER, //단가
        },
        {
            fieldName: 'occrAmt',
            dataType: ValueType.NUMBER, //합계
        },
        {
            fieldName: 'etc',
            dataType: ValueType.TEXT, //비고
        },
    ],
    columns: [
        {
            name: 'disGb',
            fieldName: 'disGb',
            type: 'data',
            width: 150,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대상유형',
                showTooltip: false,
            },
        },
        {
            name: 'disGbCd',
            fieldName: 'disGbCd',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대상유형코드',
                showTooltip: false,
            },
        },
        {
            name: 'splyStDt',
            fieldName: 'splyStDt',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '적용시작일자',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 250,
            header: {
                text: '상품명',
                showTooltip: false,
            },
            footer: {
                text: '합계',
            },
        },
        {
            name: 'occrQty',
            fieldName: 'occrQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'inveCmpAmt',
            fieldName: 'inveCmpAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            styleName: 'right-column',
            header: {
                text: '단가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'occrAmt',
            fieldName: 'occrAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '합계',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'etc',
            fieldName: 'etc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 300,
            header: {
                text: '비고',
                showTooltip: false,
            },
        },
    ],
}
