import { ValueType } from 'realgrid'

export const disInnAutoAsgnSimulProdPopupHeader = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktOperYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodChrticCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodChrticCd2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'endDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useStopDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'barCdTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'repProdCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'repProdYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'petNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
    ],
    columns: [
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'eqpClCd',
            fieldName: 'eqpClCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '단말기구분',
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '제조사',
            },
            width: 145,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            editable: false,
            styleName: 'left-column',
            header: {
                text: '모델명',
            },
            width: 145,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'repProdCd',
            fieldName: 'repProdCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표모델',
            },
        },
        {
            name: 'prodChrticCd1',
            fieldName: 'prodChrticCd1',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },

            header: {
                text: '특성1',
            },
        },
        {
            name: 'prodChrticCd2',
            fieldName: 'prodChrticCd2',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },

            header: {
                text: '특성2',
            },
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            type: 'data',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2});$1-$2-$3',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출시일',
            },
        },
        {
            name: 'endDt',
            fieldName: 'endDt',
            type: 'data',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2});$1-$2-$3',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단종일',
            },
        },
        {
            name: 'sktOperYn',
            fieldName: 'sktOperYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT운영여부',
            },
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사용여부',
            },
        },
    ],
}
