import types from './mutation-types'

const defaultSelect = (state, { optionNm, valueNm }) => {
    state[valueNm] = state[optionNm][0]['value']
}

const changeValue_ = (state, data) => {
    state[`${data.name}`] = data.value
}

const changeValueToNumber_ = (state, data) => {
    let iVal = data.value.replace(/[^0-9]/g, '')
    state[`${data.name}`] = iVal
    return iVal
}

const changeValueToUpper_ = (state, data) => {
    state[`${data.name}`] = data.value.toUpperCase()
}

const changePagingValue_ = (state, data) => {
    state.paging[`${data.name}`] = data.value
}

export default {
    [types.DEFAULT_ASSIGN]: (state, payload) => {
        state[payload.key] = payload.value
    },

    [types.SEARCH_PARAM]: (state, payload) => {
        state.searchParams[payload.key] = payload.value
    },

    defaultSelect,
    changeValue_,
    changeValueToNumber_,
    changeValueToUpper_,
    changePagingValue_,
}
