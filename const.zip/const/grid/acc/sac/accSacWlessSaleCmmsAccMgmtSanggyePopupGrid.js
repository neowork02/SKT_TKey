import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = [
    {
        fieldName: 'accYm',
        header: { text: '정산월' },
        width: '80',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMM',
        columnDatetimeFormat: 'yyyy-MM',
        editable: false,
    },
    {
        fieldName: 'dataClNm',
        header: { text: '구분' },
        width: '100',
        editable: false,
    },
    {
        fieldName: 'orgTree',
        header: { text: '조직' },
        width: '340',
        editable: false,
    },
    {
        fieldName: 'accDealcoCd',
        header: { text: '정산처', showTooltip: false },
        width: '100',
        button: 'action',
        buttonVisibility: 'always',
        editable: false,
    },
    {
        fieldName: 'accDealcoCdOld',
        header: { text: '[원값보존변수]정산처(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'accDealcoNm',
        header: { text: '정산처명' },
        width: '160',
        editable: false,
    },
    {
        fieldName: 'saleDealcoCd',
        header: { text: '판매처' },
        width: '100',
    },
    {
        fieldName: 'saleDealcoNm',
        header: { text: '판매처명' },
        width: '160',
    },
    {
        fieldName: 'accMtchClCd',
        header: { text: '수수료구분' },
        sortable: true,
        lookupDisplay: true,
        width: '180',
        values: [],
        labels: [],
        editor: {
            type: 'dropdown',
            dropDownCount: 10,
            domainOnly: true,
            textReadOnly: true,
            values: [],
            labels: [],
        },
    },
    {
        fieldName: 'accMtchItmNm',
        header: { text: '수수료설명' },
        width: '195',
    },
    {
        fieldName: 'accMtchAmt',
        header: { text: '금액' },
        width: '100',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'saleDt',
        header: { text: '판매일' },
        width: '100',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'custNm',
        header: { text: '고객명' },
        width: '100',
    },
    {
        fieldName: 'svcNum',
        header: { text: '서비스번호' },
        width: '120',
    },
    {
        fieldName: 'svcMgmtNum',
        header: { text: '서비스관리번호' },
        width: '120',
    },
    {
        fieldName: 'prodNm',
        header: { text: '모델명' },
        width: '120',
    },
    {
        fieldName: 'serNum',
        header: { text: '일련번호' },
        width: '120',
    },
    {
        fieldName: 'rmks',
        header: { text: '비고' },
        width: '200',
    },
    {
        fieldName: 'mtchSeq',
        header: { text: '상계순번(숨김)' },
        width: '80',
        visible: false,
    },
    {
        fieldName: 'slClCd',
        header: { text: '도소매구분코드(숨김)' },
        width: '150',
        visible: false,
    },
    {
        fieldName: 'orgCd',
        header: { text: '조직코드(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'orgLvl',
        header: { text: '조직레벨(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'lvOrgCd',
        header: { text: '레벨0조직코드(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'orgNm',
        header: { text: '조직명(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'saleTypeNm',
        header: { text: '판매유형명(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'isAddRow',
        header: { text: '행추가Row인지여부(숨김)' },
        width: '100',
        visible: false,
    },
]

const GRID_HEADER = {}
GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)

export { GRID_HEADER }
