'use strict'

import moment from 'moment'
import * as XLSX from 'xlsx'
import { GridView, LocalDataProvider, ValueType } from 'realgrid'

import $store from '@/store'
// import { CommonUtil } from '@/utils'
import _ from 'lodash'

/**
 * 필터
 */
const filter = {
    verifyYn(value) {
        let str
        switch (value) {
            case '검증':
                str = '검증'
                break
            case 'Y':
                str = '검증'
                break
            case '미검증':
                str = '미검증'
                break
            case 'N':
                str = '미검증'
                break
            default:
                str = value
        }

        return str
    },

    accSt(value) {
        let str
        switch (value) {
            case 'A':
                str = '추정'
                break
            case 'C':
                str = '이월'
                break
            case 'N':
                str = '임시저장'
                break
            case 'Y':
                str = '정산확정'
                break
            default:
                str = value
        }

        return str
    },

    payTypCd(value) {
        let str
        switch (value) {
            case '01':
                str = '입금완료'
                break
            case '02':
                str = '입금취소'
                break
            case '03':
                str = '익월취소'
                break
            case '04':
                str = '전월수납 당월취소'
                break
            case '05':
                str = '재수납'
                break
            case '06':
                str = '미정산'
                break
            default:
                str = value
        }

        return str
    },

    rfndCl(value) {
        let str
        switch (value) {
            case '1':
                str = '요금'
                break
            case '2':
                str = '기타'
                break
        }

        return str
    },

    fixYn(value) {
        let str
        switch (value) {
            case 'Y':
                str = '확정'
                break
            case 'N':
                str = '미확정'
                break
            default:
                str = '미확정'
                break
        }

        return str
    },

    currency(value) {
        if (!value) return '0'
        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    },

    phoneNoSection(value) {
        if (!value) return ''
        return value.replace(
            /^([\\*|\d]{2,3})([\\*|\d]{3,4})([\\*|\d]{3,4})$/g,
            `$1-$2-$3`
        )
    },
}

filter.grid = Object.keys(filter).reduce((acc, arr) => {
    acc[arr] = (grid, index, value) => filter[arr](value)
    return acc
}, {})

/**
 * 셀렉트박스 항목
 * @description 서버에서 제공되지 않는 셀렉트박스의 항목을 관리
 */
const searchSelector = {
    bondClCd: [
        {
            value: '1',
            label: '수납+매출-입금+오입금',
        },
        {
            value: '2',
            label: '수납-입금+오입금',
        },
    ],

    verifyYn: [
        {
            value: '0',
            label: '전체',
        },
        {
            value: 'Y',
            label: '검증',
        },
        {
            value: 'N',
            label: '미검증',
        },
    ],

    expObjYn: [
        {
            value: '0',
            label: '전체',
        },
        {
            value: 'Y',
            label: '대상',
        },
        {
            value: 'N',
            label: '비대상',
        },
    ],

    payTypCd: [
        {
            value: '0',
            label: '전체',
        },
        {
            value: '01',
            label: '입금완료',
        },
        {
            value: '02',
            label: '입금취소',
        },
        {
            value: '03',
            label: '익월취소',
        },
        {
            value: '04',
            label: '전월수납 당월취소',
        },
        {
            value: '05',
            label: '재수납',
        },
        {
            value: '06',
            label: '미정산',
        },
    ],

    patmentDtPayDt: [
        {
            value: 'patmentDt',
            label: '승인일',
        },
        {
            value: 'payDt',
            label: '입금일',
        },
    ],

    rfndCl: [
        {
            value: '1',
            label: '요금',
        },
        {
            value: '2',
            label: '기타',
        },
    ],

    accumuCl: [
        {
            value: '0',
            label: '월누적',
        },
        // {
        //     value: '1',
        //     label: '총누적',
        // },
    ],

    dealCoCl1: [
        {
            value: 'A6',
            label: '직영위탁',
        },
        {
            value: 'A7',
            label: '자영위탁직영',
        },
    ],

    stCl: [
        {
            value: 'Y',
            label: '확정',
        },
        {
            value: 'N',
            label: '비확정',
        },
    ],
}

/**
 * 오늘날짜 구하기
 * @param {string} format 표현할 날짜포맷
 * @description 포맷이 없을 경우 객체를 리턴해 준다
 */
const getTodayDate = (format) => {
    const date = moment(new Date())
    const year = date.format('YYYY')
    const month = date.format('MM')
    const day = date.format('DD')
    const dates = { date, year, month, day }

    if (format) return date.format(format)
    else return dates
}

/**
 * 날짜 거리 계산기
 * @param {date} org 원본날짜
 * @param {date} tar 대상날짜
 * @param {string} perCalc 비교단위
 * @param {string} [perCalc=days] 일
 * @param {string} [perCalc=months] 달
 * @param {string} [perCalc=years] 년
 * @return {number} org > tar ==> 양수
 */
const distanceDate = (org, tar, perCalc = 'days') =>
    moment(org).diff(moment(tar), perCalc)

/**
 * 날짜 포맷 변경
 * @param {string} val 원본날짜
 * @param {string} format 변경포맷
 */
const convertDate = (val, format) => moment(val).format(format)

/**
 * 날짜 계산기
 * @param {date} org 원본날짜
 * @param {string} [org=today] 오늘날짜 기준 리턴
 * @param {string} [org=firstday] 이번달 기준 첫날 리턴
 * @param {string} [org=lastday] 이번달 기준 마지막날 리턴
 * @param {date} calc 계산단위
 * @property {number} calc.count 가감 숫자 (+10, -10)
 * @property {string} calc.per 가감 단위
 * @property {string} [calc.per=days] 일
 * @property {string} [calc.per=months] 달
 * @property {string} [calc.per=years] 년
 * @param {date} format 표현된 날짜 포맷
 */
const getCalcDays = (org, calc, format) => {
    if (org == 'today') {
        return moment(new Date()).add(calc.count, calc.per).format(format)
    } else if (org == 'firstday') {
        return moment(calc.target).startOf('month').format(format)
    } else if (org == 'lastday') {
        return moment(calc.target).endOf('month').format(format)
    } else {
        return moment(org.date, org.dataFormat)
            .add(calc.count, calc.per)
            .format(format)
    }
}

/**
 * 같은 날짜인지 비교
 * @param {date} org 원본날짜
 * @param {date} tar 대상날짜
 * @param {date} perCalc 비교단위
 * @param {string} [perCalc=days] 일
 * @param {string} [perCalc=months] 월
 * @param {string} [perCalc=years] 년
 */
const isSameDate = (org, tar, perCalc = 'days') =>
    moment(org).isSame(moment(tar), perCalc)

/**
 * 객체의 속성이 있는지 확인
 * @param {object} target 대상객체
 */
const isNullObject = (target) => JSON.stringify(target) == '{}'

const errorHandle = (err, options = {}) => {
    const message = err instanceof Array ? err[0].msg : err.msg || err.message
    console.error(err)
    $store.dispatch('showTcComAlert', { message, options })
}

const gridMetaUtil = {
    /**
     * 그리드 부가정보 객체 조정 fields
     * @param {object} GRID_META 그리드 부가정보(메타)
     */
    adjustFields(GRID_META) {
        return GRID_META.map((arr) => {
            const field = {}

            field.fieldName = arr.fieldName
            field.dataType = arr.dataType

            if (arr.fieldDatetimeFormat)
                field.datetimeFormat = arr.fieldDatetimeFormat

            return field
        })
    },

    /**
     * 그리드 부가정보 객체 조정 columns
     * @param {object} GRID_META 그리드 부가정보(메타)
     */
    adjustColumns(GRID_META) {
        return GRID_META.map((arr) => {
            const column = Object.assign({}, arr)
            column.name = arr.fieldName
            column.type = arr.type || 'data'
            column.dataType = column.dataType || ValueType.TEXT

            if (arr.columnDatetimeFormat)
                column.datetimeFormat = arr.columnDatetimeFormat
            return column
        })
    },

    /**
     * 그리드 부가정보 객체 조정 layout
     */
    adjustLayout(GRID_META, GRID_META_GROUP) {
        const layout = []
        var preGroup = ''

        // layout 만들기
        GRID_META.map((arr) => {
            if (!_.isEmpty(preGroup) && preGroup != arr.group) {
                GRID_META_GROUP[preGroup].name = preGroup
                layout.push(GRID_META_GROUP[preGroup])
            }
            if (_.isEmpty(arr.group)) {
                preGroup = ''
                layout.push(arr.fieldName)
            } else {
                if (preGroup != arr.group) {
                    preGroup = arr.group
                }
                GRID_META_GROUP[arr.group].items.push(arr.fieldName)
            }
        })

        if (!_.isEmpty(preGroup)) {
            GRID_META_GROUP[preGroup].name = preGroup
            layout.push(GRID_META_GROUP[preGroup])
        }

        return layout
    },

    /**
     * 그리드 편집옵션이 셀렉트박스 일 경우, 항목생성
     * @param {array} GRID_HEADER 그리드 헤더정보
     * @param {object} xlsData 엑셀정보
     * @property {array} xlsData.data 엑셀데이터
     */
    editorValueLabel(prop) {
        return {
            value: searchSelector[prop]
                .map((arr) => arr.value)
                .filter((arr) => arr != 0),
            label: searchSelector[prop]
                .map((arr) => arr.label)
                .filter((arr) => arr != '전체'),
        }
    },

    /**
     * 엑셀데이터를 그리드 데이터로 변환
     * @param {array} GRID_HEADER 그리드 헤더정보
     * @param {object} xlsData 엑셀정보
     * @property {array} xlsData.data 엑셀데이터
     */
    xlsToGridData(GRID_HEADER, xlsData) {
        return xlsData.data.map((arr) => {
            let prop = {}
            Object.keys(arr).forEach((fieldName) => {
                GRID_HEADER.columns.some((column) => {
                    const status =
                        column.header && column.header.text == fieldName

                    if (status) {
                        prop[column.fieldName] = arr[fieldName].toString()
                    }

                    return status
                })
            })
            return prop
        })
    },

    /**
     * 그리드 내보내기 - Excel
     */
    exportExcelInGrid(gridMeta, data = [], opts = {}) {
        /**
         * options
         * @reference https://docs.realgrid.com/refs/grid-export-options
         */
        return new Promise((resolve, reject) => {
            const disposalDOM = document.createElement('div') // check
            disposalDOM.id = `disposalGrid${moment(new Date()).format(
                'YYYYMMDDhhmmss'
            )}`

            const dataProvider = new LocalDataProvider(false)
            const gridView = new GridView(disposalDOM)

            const options = Object.assign(
                {
                    type: 'excel',
                    target: 'local',
                    fileName: 'gridExportSample.xlsx',
                    showProgress: true,
                    progressMessage: '엑셀 내보내기중',
                    indicator: 'hidden',
                    header: 'visible',
                    footer: 'hidden',
                    compatibility: true, // true: MS Excel, false: MS Excel 2007
                    allColumns: false,
                    allItems: false,
                    // hideColumns: [],
                    // exportLayout: [],
                    // onlyCheckedItems: Boolean,
                    done: () => {
                        dataProvider.destroy()
                        resolve(options)
                    },
                    error: (err) => {
                        reject(err)
                    },
                },
                opts
            )

            gridView.setDataSource(dataProvider)
            gridView.setColumns(gridMeta.columns)

            dataProvider.setFields(gridMeta.fields)
            dataProvider.setRows(data)

            gridView.exportGrid(options)
        })
    },
}

/**
 * 파일 조작
 */
const fileHandler = {
    /**
     * 파일 읽기
     * @param {binary} files 대상파일
     */
    loadFile(files) {
        if (!files) {
            $store.dispatch('showTcComAlert', {
                message: '선택된 파일이 없습니다.',
            })
        }

        if (files.name.match(/(.xlsx|.xls)$/g)) {
            return this.loadExcel(files).catch(errorHandle)
        }
    },

    /**
     * 엑셀파일 읽기
     * @param {binary} files 대상파일
     */
    loadExcel(files) {
        function getSheetHeaders(sheet) {
            const headerRegex = new RegExp("^([A-Za-z]+)1='(.*)$")

            const cells = XLSX.utils.sheet_to_formulae(sheet)
            return cells
                .filter((item) => headerRegex.test(item))
                .map((item) => item.split("='")[1])
        }

        function fixdata(data) {
            var o = '',
                l = 0,
                w = 10240
            for (; l < data.byteLength / w; ++l)
                o += String.fromCharCode.apply(
                    null,
                    new Uint8Array(data.slice(l * w, l * w + w))
                )
            o += String.fromCharCode.apply(
                null,
                new Uint8Array(data.slice(l * w))
            )
            return o
        }

        return new Promise((resolve, reject) => {
            const reader = new FileReader()

            reader.addEventListener('load', (e) => {
                const data = e.target.result

                const arr = fixdata(data)
                const xlsData = XLSX.read(btoa(arr), {
                    type: 'base64',
                    cellText: true,
                    cellDates: true,
                })

                const firstSheetName = xlsData.SheetNames[0]
                const targetSheet = xlsData.Sheets[firstSheetName]

                const header = getSheetHeaders(targetSheet)
                const xlsDataJson = XLSX.utils.sheet_to_json(targetSheet)

                // JSON 으로 보안위배 확인
                // if (CommonUtil.checkJsonStrDocSecurity(xlsDataJson)) {
                //     reject({
                //         msg: `문서보안 엑셀 파일입니다.\n확인 후 다시 업로드해주세요.`,
                //     })
                // }

                resolve({
                    header: header,
                    data: xlsDataJson,
                })
            })

            reader.addEventListener('error', (err) => {
                reject(err)
            })

            reader.readAsArrayBuffer(files)
        })
    },
}

/**
 * 카멜케이스 표기 변환
 * @param {string} str 문자
 */
function toCamelCase(str) {
    return str
        .toLowerCase()
        .replace(/[^a-zA-Z0-9]+(.)/g, (m, chr) => chr.toUpperCase())
}

/**
 * 파스칼 표기 변환
 * @param {string} str 문자
 */
function toPascalCase(str) {
    return (' ' + str).toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g, (m, chr) => {
        return chr.toUpperCase()
    })
}

/**
 * 객체비교
 * @param {object} origin 원본객체
 * @param {object} target 대상객체
 */
function isEqualsArray(origin, target) {
    if (!origin) return false

    if (target.length != origin.length) return false

    for (var i = 0, l = target.length; i < l; i++) {
        if (target[i] instanceof Array && origin[i] instanceof Array) {
            if (!target[i].equals(origin[i])) return false
        } else if (target[i] != origin[i]) {
            return false
        }
    }
    return true
}

/**
 * 문자 바이트 계산
 * @param {string} str 문자
 */
function stringByteLength(str) {
    return new Blob([str]).size
}

export {
    getTodayDate,
    getCalcDays,
    distanceDate,
    convertDate,
    isSameDate,
    isNullObject,
    isEqualsArray,
    filter,
    errorHandle,
    searchSelector,
    gridMetaUtil,
    fileHandler,
    toCamelCase,
    toPascalCase,
    stringByteLength,
}
