<template>
    <div>
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="거래처목록"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :isPageCnt="true"
                @excelDownBtn="this.excelDown"
            />
            <TCRealGrid
                id="gridList"
                ref="gridList"
                :fields="view.fields"
                :columns="view.columns"
                :isGridReSize="true"
            />
            <TCComPaging
                :totalPage="paging1.totalPageCnt"
                :apiFunc="pageMove"
                :rowCnt="paging1.pageSize"
                @input="pageSizeChange"
            />
        </div>
        <br />
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader2"
                ref="gridHeader2"
                gridTitle="거래처이력"
                :gridObj="this.gridObj2"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :isPageCnt="true"
                @excelDownBtn="this.excelDown2"
            />
            <TCRealGrid
                id="grid2"
                ref="grid2"
                :fields="view2.fields"
                :columns="view2.columns"
                :isGridReSize="true"
            />
            <TCComPaging
                :totalPage="paging2.totalPageCnt"
                :apiFunc="pageMove2"
                :rowCnt="paging2.pageSize"
                @input="pageSizeChange2"
            />
        </div>

        <DetailPopup
            v-if="localDialogShow"
            ref="popup"
            :parentParam="this.ifYn ? dtlParam2 : dtlParam"
            :dialogShow.sync="localDialogShow"
        />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/tDealcoMgmt/helpers'
import {
    GRID_HEADER,
    GRID_HIST_HEADER,
} from '@/const/grid/bas/prm/basPrmDealcoMgmtHeader'
import { CommonGrid } from '@/utils'

import DetailPopup from './PopupContainer.vue'
import attachedFileApi from '@/api/common/attachedFile'

import _ from 'lodash'
import CommonMixin from '@/mixins'
import { msgTxt } from '@/const/msg.Properties'

export default {
    mixins: [CommonMixin],
    components: {
        DetailPopup,
    },
    data() {
        return {
            dtlParam: {
                ifYn: '',
                dealcoCd: '',
                hstSeq: '',
                isHst: false,
            },
            dtlParam2: {
                ifYn: '',
                dealcoCd: '',
                sktAgencyCd: '',
                sktSubCd: '',
                sktChnlCd: '',
                isHst: false,
            },
            ifYn: false, // true 인터페이스 / false : 기본
            activePage: 1, // 현재페이지
            rowCnt: 30,
            gridData: this.GridSetData(),
            localDialogShow: false,
            gridObj: {},
            gridHeaderObj: {},
            view: GRID_HEADER,
            layout: GRID_HEADER.layout,
            activePage2: 1, // 현재페이지
            rowCnt2: 30,
            gridData2: this.GridSetData2(),
            gridObj2: {},
            gridHeader2Obj: {},
            view2: GRID_HIST_HEADER,
            layout2: GRID_HIST_HEADER.layout,
        }
    },
    async mounted() {
        // grid
        this.gridObj = this.$refs.gridList
        this.gridHeaderObj = this.$refs.gridHeader

        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.setGridState(true)
        this.gridObj.gridView.setRowIndicator({
            visible: true,
            headText: 'No',
        })
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.displayOptions.selectionStyle = 'even'

        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            if (typeof clickData.itemIndex !== 'undefined') {
                let ifYn = grid.getValue(clickData.itemIndex, 'ifYn')
                this.initDtlParams(ifYn)
                if (_.isEqual(ifYn, 'Y')) {
                    let data = {}
                    data.ifYn = 'Y'
                    data.sktAgencyCd = grid.getValue(
                        clickData.itemIndex,
                        'sktAgencyCd'
                    )
                    data.sktSubCd = grid.getValue(
                        clickData.itemIndex,
                        'sktSubCd'
                    )
                    data.sktChnlCd = grid.getValue(
                        clickData.itemIndex,
                        'sktChnlCd'
                    )
                    data.isHst = false

                    this.ifYn = true
                    this.dtlParam2 = data
                } else {
                    let data = {}
                    data.ifYn = 'N'
                    data.dealcoCd = grid.getValue(
                        clickData.itemIndex,
                        'dealcoCd'
                    )
                    data.hstSeq = grid.getValue(clickData.itemIndex, 'hstSeq')
                    data.isHst = false
                    this.dtlParam = data
                    this.ifYn = false
                }

                this.detailPopup()
            }
        }
    },
    computed: {
        ...serviceComputed,
        resultList1: {
            get() {
                return this.resultList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        resultList2: {
            get() {
                return this.resultList_2
            },
        },
        paging2: {
            get() {
                return this.paging_2
            },
        },
        initPaging2: {
            get() {
                return this.initPaging_2
            },
        },
        saveAction1: {
            get() {
                return this.saveAction
            },
        },
        searchParam: {
            get() {
                return this.searchParams
            },
        },
    },
    methods: {
        ...serviceMethods,
        //페이지 표시 행의수 변경처리
        initDtlParams(ifYn) {
            console.log('initDtlParams ->', ifYn)
            if (_.isEqual(ifYn, 'N')) {
                this.dtlParam2 = {
                    ifYn: '',
                    dealcoCd: '',
                    sktAgencyCd: '',
                    sktSubCd: '',
                    sktChnlCd: '',
                    isHst: false,
                }
            } else {
                this.dtlParam = {
                    ifYn: '',
                    dealcoCd: '',
                    hstSeq: '',
                    isHst: false,
                }
            }
        },
        async pageMove(page) {
            console.log('pageMove', page)
            //Page Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageNum: page },
            })
            this.$emit('Refresh', '') //next paging api call
        },
        async pageSizeChange(pageSize) {
            console.log('pageSizeChange', pageSize)
            //PageSize change Move
            this.rowCnt = pageSize
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'initPaging',
                value: { ...this.paging, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'refreshPaging',
                value: '1',
            })
            if (this.paging.totalDataCnt > 0) this.$emit('Refresh', '') //refresh paging api call
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            //Grid Row 가져올때 페이지정보 Setting
            this.gridHeaderObj.setPageCount(this.paging)
        },
        /* 엑셀다운로드 */
        excelDown() {
            // if (_.isEmpty(this.searchParam.dealcoGrpCd)) {
            //     this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다')
            // } else {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/prm/dealcoMgmtNewExcelLst',
                this.searchParam
            )
            // }
        },

        async pageMove2(page) {
            console.log('pageMove2', page)
            //Page Move
            await this.defaultAssign_({
                key: 'paging_2',
                value: { ...this.paging2, pageNum: page },
            })
            this.$emit('Refresh', '') //next paging api call
        },
        async pageSizeChange2(pageSize) {
            console.log('pageSizeChange2', pageSize)
            //PageSize change Move
            this.rowCnt2 = pageSize
            await this.defaultAssign_({
                key: 'paging_2',
                value: { ...this.paging2, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'initPaging_2',
                value: { ...this.paging2, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'refreshPaging',
                value: '2',
            })
            if (this.paging2.totalDataCnt > 0) this.$emit('Refresh', '') //refresh paging api call
        },
        SetPaging2() {
            this.gridData2 = this.GridSetData2() //초기화
            this.gridData2.totalPage = this.paging2.totalPageCnt // 총페이지수
            //Grid Row 가져올때 페이지정보 Setting
            this.$refs.gridHeader2.setPageCount(this.paging2)
        },
        /* 엑셀다운로드 */
        excelDown2() {
            if (_.isEmpty(this.searchParam.dealcoGrpCd)) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다')
            } else {
                attachedFileApi.downLoadFile(
                    '/api/v1/backend-long/resource/bas/prm/dealcoHstExcelList',
                    this.searchParam
                )
            }
        },

        detailPopup() {
            this.localDialogShow = true
        },

        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        //GridSet Init
        GridSetData2: function () {
            return new CommonGrid(0, this.rowCnt2, '', '') //totalPage, rowPerPage, saveRows, delRows
        },

        searchDataHstLst() {
            let data1

            this.getBasPrmDealcoMgmtHstLst_()
                .then((data) => {
                    data1 = data
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    if (data1.gridList === null) {
                        console.log(
                            msgTxt.MSG_00039.replace(/%s/g, '거래처 이력')
                        )
                    }
                })
        },
    },
    watch: {
        resultList1(val, oldVal) {
            console.log('resultList1 watched: ', val, oldVal, this.pageSize)
            this.$refs.gridList.setRows(this.resultList)
        },
        paging1() {
            this.SetPaging()
        },
        resultList2(val, oldVal) {
            console.log('resultList2 watched: ', val, oldVal, this.pageSize)
            this.$refs.grid2.setRows(this.resultList2)
        },
        paging2() {
            this.SetPaging2()
        },
    },
}
</script>
