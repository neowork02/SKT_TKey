import { ValueType } from 'realgrid'

export const UPD_SUB_MAP_HEADER = {
    fields: [
        {
            fieldName: 'templetSeq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'templetCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'templetNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'titleNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'calYearMonth',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstrUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'phyFileNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zipFileNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'regDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mapYn',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'mapYn',
            fieldName: 'mapYn',
            header: {
                text: '매핑여부',
            },
            editable: false,
        },
        {
            name: 'templetNm',
            fieldName: 'templetNm',
            header: {
                text: '업로드구분',
            },
            editable: false,
        },
        {
            name: 'calYearMonth',
            fieldName: 'calYearMonth',
            header: {
                text: '정산월',
            },
            editable: false,
        },
        {
            name: 'titleNm',
            fieldName: 'titleNm',
            header: {
                text: '제목',
            },
            editable: false,
            styleCallback() {
                const ret = { styleName: 'left-column underLine' }
                return ret
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            header: {
                text: '등록자',
            },
            editable: false,
        },
        {
            name: 'regDtm',
            fieldName: 'regDtm',
            header: {
                text: '등록일자',
            },
            editable: false,
        },
    ],
}

export const UPD_SUB_MAP_DTL_HEADER = {
    fields: [
        {
            fieldName: 'templetSeq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'templetCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'templetNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'calYearMonth',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'salePlcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tkeyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pcode',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'idSubagency',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mapYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstrUserId',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'mapYn',
            fieldName: 'mapYn',
            lookupDisplay: true,
            // editor: {
            //     type: 'dropdown',
            //     dropDownCount: 10,
            //     domainOnly: true,
            //     textReadOnly: true,
            // },
            // values: ['Y', 'N'],
            // labels: ['Y', 'N'],
            editable: false,
            header: {
                text: '매핑여부',
            },
        },
        {
            name: 'salePlcNm',
            fieldName: 'salePlcNm',
            header: {
                text: '판매점명',
            },
            editable: false,
        },
        {
            name: 'tkeyNm',
            fieldName: 'tkeyNm',
            header: {
                text: 'T.Key판매점명',
            },
            editable: false,
        },
        {
            name: 'pcode',
            fieldName: 'pcode',
            header: {
                text: 'PCODE',
            },
            editable: false,
        },
        {
            name: 'templetNm',
            fieldName: 'templetNm',
            header: {
                text: '업로드',
            },
            editable: false,
        },
        {
            name: 'calYearMonth',
            fieldName: 'calYearMonth',
            header: {
                text: '정산월',
            },
            editable: false,
        },
    ],
}
