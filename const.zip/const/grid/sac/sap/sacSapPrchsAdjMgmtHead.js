import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orglvl', // 조직레벨
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'adjStCd', // 조정상태코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'adjStNm', // 조정상태명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDtm', // 매입일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wrtDt', // 전기일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsClCd', // 코드(매입구분)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsClNm', // 코드명(매입구분)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', // 정산처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', // 정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품 (단말기 모델)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsQty', // 수량
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prchsAmt', // 매입가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'splyPrc', // 공급가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt', // 부가세
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rmks', // 조정사유
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId', // 요청자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDtm', // 요청일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inClCd', // 입고구분 코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inClNm', // 입고구분 코드명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payCondCd', // 결제조건 코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payCondNm', // 결제조건 코드명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsShopCd', // 매입처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoCd', // 매입처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoNm', // 매입처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxClCd', // 세금구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxClNm', // 세금구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxBilId', // 발행ID (세금계산서)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxBilSeq', // 발행순번(세금계산서)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refId', // 참고ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refSeq', // 참고순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgRefId', // 원참고ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgRefSeq', // 원참고순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'evdDt', // 증빙일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cfmId', // 승인자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cfmDtm', // 승인일시
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        // {
        //     name: 'adjStNm',
        //     fieldName: 'adjStNm',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: '상태',
        // },
        {
            name: 'prchsDtm',
            fieldName: 'prchsDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'wrtDt',
            fieldName: 'wrtDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전기일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'prchsClNm',
            fieldName: 'prchsClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입구분',
        },
        {
            name: 'accShopCd',
            fieldName: 'accShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처매장코드',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처명',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'prchsQty',
            fieldName: 'prchsQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '수량',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'prchsAmt',
            fieldName: 'prchsAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입가',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '공급가',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '부가세',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '조정사유',
        },
        {
            name: 'reqUserId',
            fieldName: 'reqUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '요청자',
        },
        {
            name: 'reqDtm',
            fieldName: 'reqDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '요청일시',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'inClNm',
            fieldName: 'inClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입고구분',
        },
        {
            name: 'payCondNm',
            fieldName: 'payCondNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '결제조건',
        },
        {
            name: 'prchsShopCd',
            fieldName: 'prchsShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처매장코드',
        },
        {
            name: 'prchsDealcoCd',
            fieldName: 'prchsDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처',
        },
        {
            name: 'prchsDealcoNm',
            fieldName: 'prchsDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처명',
        },
        {
            name: 'taxClNm',
            fieldName: 'taxClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '세금구분',
        },
        {
            name: 'taxBilId',
            fieldName: 'taxBilId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '발행ID',
        },
        {
            name: 'taxBilSeq',
            fieldName: 'taxBilSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '발행순번',
        },
        {
            name: 'refId',
            fieldName: 'refId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '참고ID',
        },
        {
            name: 'refSeq',
            fieldName: 'refSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '참고순번',
        },
        {
            name: 'orgRefId',
            fieldName: 'orgRefId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '원참고ID',
        },
        {
            name: 'orgRefSeq',
            fieldName: 'orgRefSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '원참고순번',
        },
        {
            name: 'evdDt',
            fieldName: 'evdDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '증빙일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        // {
        //     name: 'cfmId',
        //     fieldName: 'cfmId',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: '승인자',
        // },
        // {
        //     name: 'cfmDtm',
        //     fieldName: 'cfmDtm',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: '승인일시',
        //     textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        // },
    ],
    layout: [
        // 'adjStNm',
        'prchsDtm',
        'wrtDt',
        'prchsClNm',
        'accShopCd',
        'accDealcoCd',
        'accDealcoNm',
        'prodNm',
        'prchsQty',
        'prchsAmt',
        'splyPrc',
        'vatAmt',
        'rmks',
        'reqUserId',
        'reqDtm',
        'inClNm',
        'payCondNm',
        'prchsShopCd',
        'prchsDealcoCd',
        'prchsDealcoNm',
        'taxClNm',
        {
            name: '세금계산서',
            direction: 'horizontal',
            items: ['taxBilId', 'taxBilSeq'],
        },
        'refId',
        'refSeq',
        'orgRefId',
        'orgRefSeq',
        'evdDt',
        // 'cfmId',
        // 'cfmDtm',
    ],
}
