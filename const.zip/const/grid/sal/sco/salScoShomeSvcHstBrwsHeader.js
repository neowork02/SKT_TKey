import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'svcTypNm', //개통유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm2', //사업담당
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm3', //사업팀
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'newOrgNm', //매출조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeyAgencyNm', //대리점
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeySubNm', //서브점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'salePlcNm', //판매처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'salePlc', //판매처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'iotSvcMgmtNum', //서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cntrctMgmtNum', //계약관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'allotYnNm', //결제유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixAmt', //확정여신가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'astAmt', //보조금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleAmt', //수납대상금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prodCd', //모델코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', //모델
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum', //일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', //비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm', //처리자정보_최초처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId', //처리자정보_최초처리자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', //처리자정보_변경처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', //처리자정보_변경처리자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgDtm', //_매출일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smhSaleNo', //_스마트홈판매관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smhSaleChgSeq', //_스마트홈판매변경순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgClNm', //_판매변경구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opDt', //_IF일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opTm', //_IF일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seq', //_IF순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm', //_조직트리
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', //_서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cntrctNum', //_IOT계약번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ifRecTypGb', //_IF전문유형구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ifOpStCd', //_IF전문처리상태코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tblNm', //_테이블명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bfOld', //_이전체크
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'afNew', //_이후체크
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'svcTypNm',
            fieldName: 'svcTypNm',
            type: 'data',
            header: {
                text: '개통유형',
                excelName: '개통유형',
            },
            editable: false,
            visible: true,
            width: '150',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'orgNm2',
            fieldName: 'orgNm2',
            type: 'data',
            header: {
                text: '사업담당',
                excelName: '사업담당',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'orgNm3',
            fieldName: 'orgNm3',
            type: 'data',
            header: {
                text: '사업팀',
                excelName: '사업팀',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'newOrgNm',
            fieldName: 'newOrgNm',
            type: 'data',
            header: {
                text: '매출조직',
                excelName: '매출조직',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'ukeyAgencyNm',
            fieldName: 'ukeyAgencyNm',
            type: 'data',
            header: {
                text: '대리점',
                excelName: '대리점',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'ukeySubNm',
            fieldName: 'ukeySubNm',
            type: 'data',
            header: {
                text: '서브점명',
                excelName: '서브점명',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'salePlcNm',
            fieldName: 'salePlcNm',
            type: 'data',
            header: {
                text: '판매처',
                excelName: '판매처',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'salePlc',
            fieldName: 'salePlc',
            type: 'data',
            header: {
                text: '판매처코드',
                excelName: '판매처코드',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'iotSvcMgmtNum',
            fieldName: 'iotSvcMgmtNum',
            type: 'data',
            header: {
                text: '서비스관리번호',
                excelName: '서비스관리번호',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'cntrctMgmtNum',
            fieldName: 'cntrctMgmtNum',
            type: 'data',
            header: {
                text: '계약관리번호',
                excelName: '계약관리번호',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'allotYnNm',
            fieldName: 'allotYnNm',
            type: 'data',
            header: {
                text: '결제유형',
                excelName: '결제유형',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'fixAmt',
            fieldName: 'fixAmt',
            type: 'data',
            header: {
                text: '확정여신가',
                excelName: '확정여신가',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'astAmt',
            fieldName: 'astAmt',
            type: 'data',
            header: {
                text: '보조금',
                excelName: '보조금',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'saleAmt',
            fieldName: 'saleAmt',
            type: 'data',
            header: {
                text: '수납대상금액',
                excelName: '수납대상금액',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            header: {
                text: '모델코드',
                excelName: '모델코드',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            header: {
                text: '모델',
                excelName: '모델',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            header: {
                text: '일련번호',
                excelName: '일련번호',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            header: {
                text: '비고',
                excelName: '비고',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            header: {
                text: '최초처리일시', //'처리자정보_최초처리일시',
                excelName: '처리자정보_최초처리일시',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            type: 'data',
            header: {
                text: '최초처리자', //'처리자정보_최초처리자',
                excelName: '처리자정보_최초처리자',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            header: {
                text: '변경처리일시', //'처리자정보_변경처리일시',
                excelName: '처리자정보_변경처리일시',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            header: {
                text: '변경처리자', //'처리자정보_변경처리자',
                excelName: '처리자정보_변경처리자',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            header: {
                text: '_매출일자',
                excelName: '_매출일자',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'smhSaleNo',
            fieldName: 'smhSaleNo',
            type: 'data',
            header: {
                text: '_스마트홈판매관리번호',
                excelName: '_스마트홈판매관리번호',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'smhSaleChgSeq',
            fieldName: 'smhSaleChgSeq',
            type: 'data',
            header: {
                text: '_스마트홈판매변경순번',
                excelName: '_스마트홈판매변경순번',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'saleChgClNm',
            fieldName: 'saleChgClNm',
            type: 'data',
            header: {
                text: '_판매변경구분명',
                excelName: '_판매변경구분명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            header: {
                text: '_IF일자',
                excelName: '_IF일자',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'opTm',
            fieldName: 'opTm',
            type: 'data',
            header: {
                text: '_IF일시',
                excelName: '_IF일시',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            header: {
                text: '_IF순번',
                excelName: '_IF순번',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            header: {
                text: '_조직트리',
                excelName: '_조직트리',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            header: {
                text: '_서비스관리번호',
                excelName: '_서비스관리번호',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'cntrctNum',
            fieldName: 'cntrctNum',
            type: 'data',
            header: {
                text: '_IOT계약번호',
                excelName: '_IOT계약번호',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'ifRecTypGb',
            fieldName: 'ifRecTypGb',
            type: 'data',
            header: {
                text: '_IF전문유형구분',
                excelName: '_IF전문유형구분',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'ifOpStCd',
            fieldName: 'ifOpStCd',
            type: 'data',
            header: {
                text: '_IF전문처리상태코드',
                excelName: '_IF전문처리상태코드',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'tblNm',
            fieldName: 'tblNm',
            type: 'data',
            header: {
                text: '_테이블명',
                excelName: '_테이블명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'bfOld',
            fieldName: 'bfOld',
            type: 'data',
            header: {
                text: '_이전체크',
                excelName: '_이전체크',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'afNew',
            fieldName: 'afNew',
            type: 'data',
            header: {
                text: '_이후체크',
                excelName: '_이후체크',
            },
            editable: false,
            visible: false,
            width: '150',
        },
    ],
}
