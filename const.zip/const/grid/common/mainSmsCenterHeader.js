import { ValueType } from 'realgrid'

export const GRID_C_HEADER = {
    fields: [
        {
            fieldName: 'commCdVal',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'commCdValNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'commCdVal',
            fieldName: 'commCdVal',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'commCdVal',
            },
        },

        {
            name: 'commCdValNm',
            fieldName: 'commCdValNm',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'commCdValNm',
            },
        },
    ],
}
