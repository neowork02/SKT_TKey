import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        // {
        //     fieldName: 'pagingSeq',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hstSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'oldOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'origin',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procStNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        // {
        //     name: 'pagingSeq',
        //     fieldName: 'pagingSeq',
        //     header: {
        //         text: 'No.',
        //     },
        //     width: 40,
        //     editable: false,
        // },
        {
            name: 'origin',
            fieldName: 'origin',
            header: {
                text: 'origin',
            },
            visible: false,
        },
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: '체크',
            },
            visible: false,
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            header: {
                text: '매장코드',
            },
            editable: false,
            visible: true,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            header: {
                text: '거래처코드',
            },
            editable: false,
            visible: true,
        },
        {
            name: 'hstSeq',
            fieldName: 'hstSeq',
            header: {
                text: '이력순번',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            header: {
                text: '거래처명',
            },
            editable: false,
        },
        {
            name: 'oldOrgCd',
            fieldName: 'oldOrgCd',
            header: {
                text: '구조직코드',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            header: {
                text: '조직코드',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'lvOrgCd',
            fieldName: 'lvOrgCd',
            header: {
                text: '레벨0조직코드',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            header: {
                text: '대리점코드',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            header: {
                text: 'SKT서브점코드',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'procStNm',
            fieldName: 'procStNm',
            header: {
                text: '분류',
            },
            editable: false,
            visible: true,
        },
    ],
}
