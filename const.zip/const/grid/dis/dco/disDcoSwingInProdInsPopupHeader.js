import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT, //체크여부
        },
        // {
        //     fieldName: 'seq',
        //     dataType: ValueType.TEXT, //번호
        // },
        {
            fieldName: 'inoutSchdDt',
            dataType: ValueType.TEXT, //입고예정일
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사명
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT, //제조사코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //모델코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //시작일련번호
        },
        {
            fieldName: 'toSerNum',
            dataType: ValueType.TEXT, //종료일련번호
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, //오류내용
        },
        {
            fieldName: 'errorClCd',
            dataType: ValueType.TEXT, //오류내용
        },
        {
            fieldName: 'reflYn',
            dataType: ValueType.TEXT, //반영여부
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //모델구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분명
        },
        {
            fieldName: 'opDt',
            dataType: ValueType.TEXT, //처리일자
        },
        {
            fieldName: 'opTm',
            dataType: ValueType.TEXT, //if처리일자
        },
        {
            fieldName: 'rgstSeq',
            dataType: ValueType.TEXT, //등록순번
        },
        {
            fieldName: 'inoutClCd',
            dataType: ValueType.TEXT, //입출고구분코드
        },
        {
            fieldName: 'inoutClNm',
            dataType: ValueType.TEXT, //입출고구분명
        },
        {
            fieldName: 'inoutPlcCd',
            dataType: ValueType.TEXT, //입출고처코드
        },
        {
            fieldName: 'inoutPlcNm',
            dataType: ValueType.TEXT, //입출고처명
        },
        {
            fieldName: 'eqpClCd',
            dataType: ValueType.TEXT, //단말기구분코드
        },
        {
            fieldName: 'eqpClNm',
            dataType: ValueType.TEXT, //단말기구분명
        },
        {
            fieldName: 'sknRnpTypCd',
            dataType: ValueType.TEXT, //SKN수불유형코드
        },
        {
            fieldName: 'sknOpClCd',
            dataType: ValueType.TEXT, //SKN처리구분코드
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.TEXT, //종료일련번호
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '체크여부',
                showTooltip: false,
            },
            visible: false,
        },
        // {
        //     name: 'seq',
        //     fieldName: 'seq',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '번호',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'inoutSchdDt',
            fieldName: 'inoutSchdDt',
            type: 'data',
            header: {
                text: '입고예정일',
                showTooltip: false,
            },
            // datetimeFormat: 'yyyy-MM-dd',
            // editor: {
            //     type: 'date',
            //     textReadOnly: false,
            //     mask: {
            //         editMask: '9999-99-99',
            //         includedFormat: true,
            //     },
            // },
        },
        {
            name: 'mfactCd',
            fieldName: 'mfactCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사명',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
            visible: false,
        },

        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '시작일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'toSerNum',
            fieldName: 'toSerNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '종료일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류내용',
                showTooltip: false,
            },
        },
        {
            name: 'errorClCd',
            fieldName: 'errorClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'reflYn',
            fieldName: 'reflYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반영여부',
                showTooltip: false,
            },
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분명',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일자',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'opTm',
            fieldName: 'opTm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'if처리일자',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'rgstSeq',
            fieldName: 'rgstSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록순번',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'inoutClCd',
            fieldName: 'inoutClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입출고구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'inoutClNm',
            fieldName: 'inoutClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입출고구분명',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'inoutPlcCd',
            fieldName: 'inoutPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입출고처코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'inoutPlcNm',
            fieldName: 'inoutPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입출고처명',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'eqpClCd',
            fieldName: 'eqpClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'eqpClNm',
            fieldName: 'eqpClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분명',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'sknRnpTypCd',
            fieldName: 'sknRnpTypCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKN수불유형코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'sknOpClCd',
            fieldName: 'sknOpClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKN처리구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'inQty',
            fieldName: 'inQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '종료일련번호',
                showTooltip: false,
            },
            visible: false,
        },
    ],
}
