import api from '@/api/biz/bas/prm/basPrmEtcDealcoMgmt'
import types from './mutation-types'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },
    async getEtcDealcoMgmtLst2_({ state, commit }) {
        let resultData
        let searchParams = state.searchParams
        searchParams.pageSize = state.initPaging.pageSize
        searchParams.pageNum = state.paging.pageNum

        await api
            .getEtcDealcoMgmtLst2_({ searchParams })
            .then((data) => {
                let resultList = []
                let paging = state.initPaging
                if (data !== undefined) {
                    resultList = data.gridList
                    paging = data.pagingDto
                }

                commit(types.DEFAULT_ASSIGN, {
                    key: 'resultList',
                    value: resultList,
                })
                commit(types.DEFAULT_ASSIGN, {
                    key: 'paging',
                    value: paging,
                })
                resultData = data
            })
            .catch((error) => {
                throw error
            })

        return resultData
    },
    async rgstBasAdmEtcDealcoMgmt_({ state }) {
        let result = 0
        let params = state.params
        await api
            .rgstBasAdmEtcDealcoMgmt_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        console.log('result -> ', result)
        return result
    },
    async uptBasAdmEtcDealcoMgmt_({ state }) {
        let result = 0
        let params = state.params
        await api
            .uptBasAdmEtcDealcoMgmt_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
}
