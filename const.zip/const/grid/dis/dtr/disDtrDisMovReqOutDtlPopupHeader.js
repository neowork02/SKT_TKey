import { ValueType } from 'realgrid'

export const DisDtrDisMovReqOutDtlPopupGRID_HEADER = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnFixYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
            editable: false,
            width: '100',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
            editable: false,
            width: '200',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
            editable: false,
            width: '100',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
            editable: false,
            width: '100',
        },
        {
            name: 'asgnFixYn',
            fieldName: 'asgnFixYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '선택',
            },
            renderer: {
                type: 'check',
                editable: true,
                trueValues: 'Y',
                falseValues: 'N',
            },
            styleCallback: function (grid, dataCell) {
                var asgnStCd = grid.getValue(
                    dataCell.index.itemIndex,
                    'asgnStCd'
                )
                var ret = {}
                if (asgnStCd === '03' || asgnStCd === '04') {
                    ret.renderer = {
                        editable: false,
                    }
                }
                return ret
            },
        },
        {
            name: 'reqMgmtNo',
            fieldName: 'reqMgmtNo',
            type: 'data',
            visible: false,
        },
        {
            name: 'asgnSeq',
            fieldName: 'asgnSeq',
            visible: false,
            type: 'data',
        },
        {
            name: 'asgnStCd',
            fieldName: 'asgnStCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            visible: false,
            type: 'data',
        },
    ],
}
