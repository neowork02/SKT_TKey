<template>
    <v-app id="app">
        <div>
            <router-view />
            <!-- alert, confirm, exception 필요시 v-if에 computed 사용 -->
            <TCComBaseAlert v-if="getTcComAlertShow" />
            <TCComConfirm v-if="getTcComConfirmShow" />
            <TCComExceptionDialog v-if="getExceptionShow" />
            <!-- Rest API 로딩 컴포넌트 -->
            <TCComLoadingBar v-model="getApiLoading" />
            <TCComSnackbar />
        </div>
    </v-app>
</template>
<script>
export default {
    name: 'App',
    computed: {
        getApiLoading() {
            return this.$store.getters.apiLoading
        },
        getTcComAlertShow() {
            return this.$store.getters.tcComAlertShow
        },
        getTcComConfirmShow() {
            return this.$store.getters.tcComConfirmShow
        },
        getExceptionShow() {
            return this.$store.getters['exception/getException'].show
        },
    },
    created() {
        this.$draggableDialogs()
    },
}
</script>

<style lang="scss">
@import '~@/styles/overrides.sass';
@import '~vuetify/src/styles/styles.sass';
// css style
//main.js에서 선언되어 중복사용으로 주석처리
// @import '~@/assets/style/style.css';
</style>
