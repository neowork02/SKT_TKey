<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">메뉴검색</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- //Search_line 1 -->
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="searchForm.menuNm"
                                    labelName="메뉴"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :eRequired="true"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div2">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            @click="onSearch"
                                        />
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-5 -->
                        </div>
                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="basAdmQuickMenuGridHeader"
                            ref="basAdmQuickMenuGridHeader"
                            :gridObj="gridObj"
                        />
                        <TCRealGrid
                            id="basAdmQuickMenuGrid"
                            ref="basAdmQuickMenuGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { BAS_ADM_QUICK_MENU_HEADER } from '@/const/grid/bas/adm/basAdmQuickSearchMenuHeader'
import basAdmQuickApi from '@/api/biz/bas/adm/basAdmQuickSearch'

import { prototype } from '@/views/prototype/js/prototype'
import CommonMixin from '@/mixins'
import _ from 'lodash'
export default {
    name: 'basAdmQuickSearchMenuPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },

    data() {
        return {
            //Paging Class init
            gridData: this.gridSetData(),
            headerText: '',
            objAuth: {},
            view: BAS_ADM_QUICK_MENU_HEADER,
            content: '',
            gridObj: {},
            gridHeaderObj: {},
            forms: new prototype(),
            searchForm: {
                menuNm: '',
            },
        }
    },
    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.basAdmQuickMenuGrid
        this.gridHeaderObj = this.$refs.basAdmQuickMenuGridHeader
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.initGrid()
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchForm.menuNm =
                    value['menuNm'] == undefined ? '' : value['menuNm']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        //GridSetData
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(-1, -1, 10, 0, '')
        },
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false)

            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
            this.init()
        },
        init() {
            console.log('init1')
            if (_.isEmpty(this.searchForm.menuNm)) return
            console.log('init2')
            this.onSearch()
        },
        getQuickSearchMenu() {
            basAdmQuickApi.getQuickSearchMenu(this.searchForm).then((res) => {
                console.log('res ', res)
                this.gridObj.setRows(res)
            })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('메뉴를 선택해주세요.', {
                    //header: '사용자',
                    size: '500',
                    confirmLabel: 'OK',
                })

                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },

        onSearch() {
            if (_.isEmpty(this.searchForm.menuNm)) {
                this.showTcComAlert('메뉴를 입력하세요.', {
                    //header: '내부거래처',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            this.getQuickSearchMenu()
        },

        onEnterKey() {
            this.onSearch()
        },
    },
}
</script>
