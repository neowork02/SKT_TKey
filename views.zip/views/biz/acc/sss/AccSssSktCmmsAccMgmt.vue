<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: SKT수수료정산관리
 * 설명: SKT수수료정산관리 조회,승인요청,상세 
 * 작성자: P180190
 * 작성일: 2022.06.20
------------------------------------------------>
<template>
    <div class="content">
        <h1>SKT수수료 정산관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onConfrim"
                    :disabled="onConfrimDisabled"
                    v-show="onConfrimDisplay"
                    >승인요청</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="init()"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSearch"
                    >조회</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div5">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        :eRequired="true"
                        v-model="accYm_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="구분"
                        :itemList="calcuItemsMain"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        v-show="srchPsErpGrpCdDisabled"
                        @change="srchPsErpGrpCdChange"
                        v-model="searchFormData.srchPsErpGrpCd"
                    ></TCComComboBox>
                    <TCComComboBox
                        labelName="구분"
                        :itemList="calcuItemsSub"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        v-show="srchSettlOperClCdDisabled"
                        v-model="searchFormData.srchSettlOperClCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="searchOrgAgencyParam.agencyNm"
                        :codeVal.sync="searchOrgAgencyParam.agencyCd"
                        labelName="대리점"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onOrgAgencyEnterKey"
                        @appendIconClick="onOrgAgencyIconClick"
                        @input="onOrgAgencyInput"
                    />
                    <BasBcoOrgAgencysPopup
                        v-if="showBcoOrgAgencys"
                        :parentParam="searchOrgAgencyParam"
                        :rows="resultOrgAgencyRows"
                        :dialogShow.sync="showBcoOrgAgencys"
                        @confirm="onOrgAgencyReturnData"
                    />
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCComTab
                :tab.sync="tab.tabSync1"
                :items="items"
                :itemName="itemName"
                :objAuth="objAuth"
                sliderSize="8"
                @change="onActiveTabChange"
                @click="onActiveTabClick"
                :cKey="0"
            >
                <template #Template1>
                    <TCRealGridHeader
                        id="gridHeader"
                        ref="gridHeader"
                        gridTitle="SKT수수료정산 목록"
                        :gridObj="gridObj"
                        :isExceldown="true"
                        @excelDownBtn="downloadExcelAll(0)"
                    >
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid"
                        ref="grid"
                        :fields="view.fields"
                        :columns="view.columns"
                        :styles="gridStyle"
                    />
                </template>
                <template #Template2>
                    <TCRealGridHeader
                        id="gridHeader1"
                        ref="gridHeader1"
                        gridTitle="SKT수수료정산(조직별) 목록"
                        :gridObj="gridObj1"
                        :isPageRows="true"
                        :isNextPage="true"
                        :isPageCnt="true"
                        :isExceldown="true"
                        @excelDownBtn="downloadExcelAll(1)"
                    >
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :fields="view1.fields"
                        :columns="view1.columns"
                        :styles="gridStyle"
                        @hook:mounted="tabGridMounted"
                    />
                    <TCComPaging
                        :totalPage="gridData.totalPage"
                        :apiFunc="getSktCmmsOrgList"
                        :rowCnt="rowCnt1"
                        @input="chgRowCnt1"
                    />
                </template>
            </TCComTab>
            <!-- //popup 영역 -->
            <AccSssSktCmmsAccMgmtDtl
                v-if="popup.adjustDtl.showBool === true"
                ref="popup"
                :dialogShow.sync="popup.adjustDtl.showBool"
                :popupParams.sync="popupParams"
                @confirm="onReAccSssSktCmmsAccMgmtDtl"
            />
        </div>
    </div>
</template>
<script>
import _ from 'lodash'
// import commonApi from '@/api/common/prototype'
import { CommonGrid, CommonUtil } from '@/utils'
// import commonApi from '@/api/common/commonCode'
import moment from 'moment'
import { AccUtil } from '@/views/biz/acc'
//====================상세팝업====================
import AccSssSktCmmsAccMgmtDtl from '@/views/biz/acc/sss/AccSssSktCmmsAccMgmtDtl'
//====================조직별대리점팝업====================
import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
//====================//조직별대리점팝업====================
import sktCmmApi from '@/api/biz/acc/sss/AccSssSktCmmsAccMgmt'
import {
    GRID_HEADER,
    GRID_HEADER1,
} from '@/const/grid/acc/sss/AccSssSktCmmsAccMgmtGrid'
import CommonMixin from '@/mixins'
export default {
    name: 'AccSssSktCmmsAccMgmt',
    title: 'SKT수수료정산관리',
    components: {
        BasBcoOrgAgencysPopup,
        AccSssSktCmmsAccMgmtDtl,
    },
    mixins: [CommonMixin],
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,
            view1: GRID_HEADER1,

            //Grid
            objAuth: {},
            tabDefault: {},
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            gridObj1: {},
            gridHeaderObj1: {},
            srchPsErpGrpCdDisabled: true,
            srchSettlOperClCdDisabled: false,
            onConfrimDisplay: true,

            //tab
            tab: {
                nowIndex: 0,
                tabSync1: 0,
            },
            items: ['Template1', 'Template2'],
            itemName: ['SKT수수료정산관리', 'SKT수수료정산관리(조직별)'],

            /*그리드 스타일*/
            gridStyle: {
                height: '330px', //그리드 높이 조절
            },
            // 버튼 비활성화
            onConfrimDisabled: true,

            searchForms: {},
            rowData: '',
            // rowCnt: 15,
            rowCnt1: 15,

            accYm_: moment(new Date()).format('YYYY-MM'),
            accYm: moment(new Date()).format('YYYY-MM'),

            //요청 파라미터
            searchFormData: {
                srchAccYm: '',
                srchPsErpGrpCd: '',
                srchSettlOperClCd: '',
                srchAgencyCd: '',
                srchFlag: '',
                srchAccDealcoCd: '',
                srchExcelTyp: '',
                srchExcelNm: '',
                pageSize: '',
                pageNum: 1,
            },
            //처리구분
            //tab0 선택할 경우
            calcuItemsMain: [
                {
                    commCdVal: 'T10',
                    commCdValNm: '[T10](월)위탁수수료-확정',
                },
                {
                    commCdVal: 'T13',
                    commCdValNm: '[T13](월)위탁수수료-조정',
                },
            ],
            //tab1 선택할 경우
            calcuItemsSub: [
                {
                    commCdVal: '01',
                    commCdValNm: '추정금액산정',
                },
                {
                    commCdVal: '02',
                    commCdValNm: '정산금액산정(확정)',
                },
                {
                    commCdVal: '03',
                    commCdValNm: '조정금액산정',
                },
            ],

            /* popup영역 */
            //====================조직별대리점팝업관련====================
            showBcoOrgAgencys: false, // 조직별대리점 팝업 오픈 여부
            searchOrgAgencyParam: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            },
            resultOrgAgencyRows: [], // 조직별대리점 팝업 오픈 여부
            //====================//조직별대리점팝업관련==================

            popupParams: {},
            dtlParam: {},
            popup: {
                adjustDtl: {
                    showBool: false,
                },
            },

            //  엑셀다운로드 유형
            excelTypNum: ['01', '02', '03', '04', '05', '06', '07', '08', '09'],
            excelTypNm: [
                'SKT수수료정산관리(조직별)_추정확정_CASE1_',
                'SKT수수료정산관리(조직별)_추정확정_CASE2_',
                'SKT수수료정산관리(조직별)_추정확정_CASE3_',
                'SKT수수료정산관리(조직별)_추정확정_외상매출금_',
                'SKT수수료정산관리(조직별)_조정_CASE1_',
                'SKT수수료정산관리(조직별)_조정_CASE2_',
                'SKT수수료정산관리(조직별)_조정_CASE3_',
                'SKT수수료정산관리(조직별)_조정_CASE4_',
                'SKT수수료정산관리(조직별)_조정_외상매출금_',
            ],
        }
    },
    mounted() {
        // 첫번째 그리드 세팅
        this.grid = this.$refs.grid
        this.gridHeader = this.$refs.gridHeader
        this.grid.setGridState(false, false, true, true)
        // this.grid.gridView.setRowIndicator({
        //     visible: true,
        //     headText: '번호',
        // })
        this.$refs.grid.gridView.setColumnLayout(this.view.layout) //그리드 Header Layout 세팅하기
        this.grid.gridView.displayOptions.selectionStyle = 'rows'
        this.grid.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.grid.gridView.onCellDblClicked = this.onCellDblClicked

        //  PS&M사용자일 경우 승인요청버튼 보임
        if (this.orgInfo.orgCdLvl0 == 'O00000') {
            this.onConfrimDisplay = true
        } else {
            this.onConfrimDisplay = false
        }

        //  일반대리점 접속시 대리점코드/명 Set
        if (this.orgInfo.orgCdLvl0 != 'O00000') {
            this.searchOrgAgencyParam.agencyCd = this.userInfo.sktAgencyCd
            this.searchOrgAgencyParam.agencyNm = this.userInfo.sktAgencyNm
        }
    },
    computed: {},
    watch: {},
    created() {
        this.gridData = this.gridSetData()
    },
    methods: {
        // 초기화
        init: function () {
            this.accYm_ = moment(new Date()).format('YYYY-MM')
            this.searchForms = {}
            this.searchFormData = {
                srchPsErpGrpCd: '',
                srchSettlOperClCd: '',
            }
            this.$refs.grid.setRows([])
            this.$refs.grid1.setRows([])
            this.searchOrgAgencyParam = {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            }
            this.resultOrgAgencyRows = []
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
        },

        // 입력한 정산월이 당월 정산대상월보다 작을경우
        // 액셀업로드데이터 삭제버튼 Disable ::::: excelDel()

        gridSetData(rowCnt1) {
            return new CommonGrid(0, rowCnt1, '', '')
        },

        //페이지 표시 행의수 변경처리
        chgRowCnt1(val) {
            this.rowCnt1 = val
        },

        //===================== //내부거래처(거래종료확인) methods ================================

        //===================== //내부거래처(권한조직) methods ================================

        //===================== 조직별 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getOrgAgencyList() {
            basBcoOrgAgencysApi
                .getOrgAgencyList(this.searchOrgAgencyParam)
                .then((res) => {
                    console.log('getOrgAgencyList then : ', res)
                    // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                    // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                    if (res.length === 1) {
                        this.searchOrgAgencyParam.agencyCd = _.get(
                            res[0],
                            'agencyCd'
                        )
                        this.searchOrgAgencyParam.agencyNm = _.get(
                            res[0],
                            'agencyNm'
                        )
                    } else {
                        this.resultOrgAgencyRows = res
                        this.showBcoOrgAgencys = true
                    }
                })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onOrgAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            // if (!_.isEmpty(this.searchOrgAgencyParam.agencyNm)) {
            //     this.getOrgAgencyList()
            // } else {
            this.showBcoOrgAgencys = true
            // }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onOrgAgencyEnterKey() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 대리점명이 빈값이면 알림창 오픈
            // if (_.isEmpty(this.searchOrgAgencyParam.agencyNm)) {
            //     this.showTcComAlert('대리점명을 입력해주세요.')
            //     return
            // }
            // 대리점 정보 조회
            // this.getOrgAgencyList()
            this.showBcoOrgAgencys = true
        },
        // 대리점 TextField Input 이벤트 처리
        onOrgAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.searchOrgAgencyParam.agencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onOrgAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchOrgAgencyParam.agencyCd = _.get(retrunData, 'agencyCd')
            this.searchOrgAgencyParam.agencyNm = _.get(retrunData, 'agencyNm')
        },
        //===================== //조직별대리점팝업관련 methods ================================

        //================================================
        // :::: 전체 조회 ::::
        // getSktCmmsIncenAccList
        // getSktCmmsOrgList
        //================================================
        onSearch: function () {
            const srchAccYm = this.accYm_
            if (_.isEmpty(srchAccYm)) {
                this.showTcComAlert('정산월을 확인하세요.')
            } else {
                this.searchFormData.srchAccYm = CommonUtil.onlyNumber(
                    this.accYm_
                )
                this.searchForms.pageNum = 1
                this.searchFormData.srchAgencyCd =
                    this.searchOrgAgencyParam.agencyCd
                this.searchFormData.pageSize = this.rowCnt1
                this.searchForms = { ...this.searchFormData }
                if (this.tab.nowIndex == 0) {
                    this.getSktCmmsAccList(this.searchForms)
                    console.log('수수료정산관리 전체조회 ::::::: 시작')
                }
                if (this.tab.nowIndex == 1) {
                    this.getSktCmmsOrgList(this.searchForms.pageNum)
                    console.log('수수료정산관리(조직) 전체조회 ::::::: 시작')
                }
            }
        },
        getSktCmmsAccList() {
            sktCmmApi.getSktCmmsAccList(this.searchForms).then((res) => {
                if (res) {
                    console.log('수수료정산관리(조직) 전체조회 ::::::: ', res)
                    this.grid.setRows(res.gridList)
                    this.grid.setGridIndicator()
                    console.log('수수료정산관리 전체조회 ::::::: 끝')
                } else {
                    this.showTcComAlert('검색 정보를 불러오지 못했습니다.')
                }
            })
        },
        getSktCmmsOrgList(page) {
            this.searchForms.pageNum = page
            sktCmmApi.getSktCmmsOrgList(this.searchForms).then((res) => {
                if (res) {
                    console.log('수수료정산관리(조직) 전체조회 ::::::: ', res)
                    this.gridObj1.setRows(res.gridList)
                    this.gridObj1.setGridIndicator(res.pagingDto)
                    this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj1.setPageCount(res.pagingDto)
                    console.log('수수료정산관리(조직) 전체조회 ::::::: 끝')
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },
        //================================================
        // 선택한 row 승인요청 :::: requestEaprv
        //================================================
        onConfrim: function () {
            console.log(this.userInfo)

            var reqList = this.$refs.grid.gridView.getCheckedItems(true)
            if (reqList == null || reqList.length == 0) {
                this.showTcComAlert(
                    '승인요청 대상 대리점을 선택 후 재처리하십시오.'
                )
                return
            } else {
                for (var i = 0; i < reqList.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(reqList[i])
                    console.log(row)
                    // 이미 확정처리가 되어 있는 건 :: fix_yn
                    if (row['fixSplyPrc'] == 0) {
                        console.log(row['fixSplyPrc'])
                        this.showTcComAlert(
                            '미확정 대리점이 있습니다.[' +
                                row['agencyCd'] +
                                '(' +
                                row['agencyNm'] +
                                ')' +
                                ']\n 승인요청은 확정후에 가능합니다.'
                        )
                        return
                    }
                    if (
                        row['aprvStatCd'] == '01' || //요청중
                        row['aprvStatCd'] == 'C' || //승인완료
                        row['aprvStatCd'] == 'P' || //진행중
                        row['aprvStatCd'] == 'PD'
                    ) {
                        //준비중
                        this.showTcComAlert(
                            '승인이 진행중이거나 완료된 대리점이 있습니다.\n[' +
                                row['agencyCd'] +
                                '(' +
                                row['agencyNm'] +
                                ')]'
                        )
                        return
                    }
                }
                // 선택한 row push 승인요청
                // list 초기화
                this.searchForms.reqList = []
                this.searchForms.accYm = CommonUtil.onlyNumber(this.accYm_)
                for (i = 0; i < reqList.length; i++) {
                    var rowData = this.$refs.grid.gridView.getValues(reqList[i])
                    rowData.accDt = AccUtil.dateToFormat(
                        new Date(rowData.accDt),
                        'YYYYMMDD'
                    )
                    rowData.sktTrmsDtm = AccUtil.dateToFormat(
                        new Date(rowData.sktTrmsDtm),
                        'YYYYMMDD'
                    )
                    this.searchForms.reqList.push(rowData)
                }

                sktCmmApi.requestEaprv(this.searchForms).then((resultData) => {
                    if (resultData == undefined) {
                        this.showTcComAlert('승인요청 처리실패하였습니다.')
                        return
                    } else {
                        this.showTcComAlert('승인요청 처리되었습니다.')
                        this.onSearch()
                    }
                })
            }
        },
        //================================================
        // 상세 페이지 POPUP
        //================================================
        onCellDblClicked() {
            this.grid.gridView.onCellDblClicked = (grid, clickData) => {
                this.popup.adjustDtl.showBool = true
                this.popup.adjustDtl.popupParams = rowData
                var rowData = grid.getValues(clickData.itemIndex)
                this.popupParams.srchAccYm = rowData.accYm
                this.popupParams.accYm = rowData.accYm
                // this.popupParams.accYm_ = this.accYm_
                this.popupParams.agencyNm = rowData.agencyNm
                this.popupParams.agencyCd = rowData.agencyCd
                this.popupParams.psErpGrpNm = rowData.psErpGrpNm
                this.popupParams.psErpGrpCd = rowData.psErpGrpCd
                this.popupParams.fixYn = rowData.fixYn
                this.popupParams.srchAccDealcoNm = 'SK텔레콤(주)'
                this.popupParams.srchAccDealcoCd = '10001'
                this.popupParams.erpTrmsDtm = rowData.erpTrmsDtm
                this.popupParams.sktTrmsDtm = rowData.sktTrmsDtm
                this.popupParams.flag = rowData.flag
                // this.popupParams.accDealcoCd = rowData.accDealcoCd
            }
        },

        //================================================
        // EXCEL DOWNLOAD
        //================================================

        downloadExcelAll: function (tabIndex) {
            this.searchFormData.srchAccYm = CommonUtil.onlyNumber(this.accYm_)
            this.searchFormData.srchAgencyCd =
                this.searchOrgAgencyParam.agencyCd
            // 탭선택에 따른 엑셀다운로드 버튼 로직
            if (tabIndex == 0) {
                sktCmmApi
                    .downloadSktCmmsAccListExcel(this.searchFormData)
                    .then((res) => {
                        console.log('엑셀다운로드 ::::::: ', res)
                    })
                    .catch((err) => {
                        console.log('err::::', err)
                    })
            }
            if (tabIndex == 1) {
                this.searchFormData.srchExcelTyp = '00'
                this.searchFormData.srchExcelNm = 'SKT수수료정산관리(조직별)_'
                sktCmmApi.downloadSktCmmsOrgListExcel(this.searchFormData)
                // .then((res) => {
                //     console.log('엑셀다운로드 ::::::: ', res)
                // })
                // .catch((err) => {
                //     console.log('err::::', err)
                // })

                //  CASE별 엑셀다운로드
                var endInx = 0
                var excelTyp = ''
                if (_.isEmpty(this.searchFormData.srchSettlOperClCd)) {
                    //  전체
                    endInx = 9
                    excelTyp = 'A'
                } else if (this.searchFormData.srchSettlOperClCd != '03') {
                    //  추정/확정
                    endInx = 4
                    excelTyp = 'B'
                } else {
                    //  조정
                    endInx = 9
                    excelTyp = 'C'
                }

                for (var i = 0; i < endInx; i++) {
                    if (excelTyp == 'A' || excelTyp == 'B') {
                        //  구분 : 전체 또는 추정/확정
                        this.searchFormData.srchExcelTyp = this.excelTypNum[i]
                        this.searchFormData.srchExcelNm = this.excelTypNm[i]
                    } else {
                        //  구분 : 조정
                        this.searchFormData.srchExcelTyp =
                            this.excelTypNum[i + 4]
                        this.searchFormData.srchExcelNm = this.excelTypNm[i + 4]
                    }
                    sktCmmApi.downloadSktCmmsOrgListExcel(this.searchFormData)
                    // .then((res) => {
                    //     console.log('엑셀다운로드 ::::::: ', res)
                    // })
                    // .catch((err) => {
                    //     console.log('err::::', err)
                    // })
                }
            }
        },

        onActiveTabChange(tabIdx) {
            console.log('onActiveTabChange: ', tabIdx)
        },
        //탭 변경에 따른 승인버튼 숨김 및 구분 콤보박스 변경
        onActiveTabClick(tabIndex) {
            this.tab.nowIndex = tabIndex
            if (tabIndex == 0) {
                this.srchPsErpGrpCdDisabled = true
                this.srchSettlOperClCdDisabled = false
                if (this.orgInfo.orgCdLvl0 == 'O00000') {
                    this.onConfrimDisplay = true
                }
            }
            if (tabIndex == 1) {
                this.srchPsErpGrpCdDisabled = false
                this.srchSettlOperClCdDisabled = true
                if (this.orgInfo.orgCdLvl0 == 'O00000') {
                    this.onConfrimDisplay = false
                }
            }
        },
        //구분 선택에 따른 승인요청버튼 활성화 비활성화
        //전체: 클릭불가 그외: 클릭가능
        srchPsErpGrpCdChange() {
            if (
                this.searchFormData.srchPsErpGrpCd == 'T10' ||
                this.searchFormData.srchPsErpGrpCd == 'T13'
            ) {
                this.onConfrimDisabled = false
            } else {
                this.onConfrimDisabled = true
            }

            this.onSearch()
        },
        // 탭선택시 마운트, SKT수수료정산관리(조직) 그리드 세팅
        tabGridMounted() {
            this.gridObj1 = this.$refs.grid1
            this.gridHeaderObj1 = this.$refs.gridHeader1
            this.gridObj1.setGridState(false, false, false, true) //footer 나오게
            this.gridObj1.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj1.gridView.setColumnLayout(this.view1.layout)
        },

        // 팝업 닫으면 부모페이지 재조회
        onReAccSssSktCmmsAccMgmtDtl(retVal) {
            if (retVal) {
                console.log('retrunData: ', retVal)
                // this.accYm_ = retVal
                this.onSearch()
            }
        },
    },
}
</script>
