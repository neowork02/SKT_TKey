export default {
    //alert message
    alertShow: false,
    alertHeaderText: '',
    alertBodyText: '',
    loadingShow: false,
    snackbar: false,
    snackbarText: '',
    //paging
    paging: {
        pageNum: 1, //fix
        pageSize: 0,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging: {
        pageNum: 1, //fix
        pageSize: 9999,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    saveAction: false,
    saveDoneA: false,
    saveDoneB: false,
    saveOrgAction: false,
    saveOrgDone: false,
    searchOrg: '',
    moveStore: '',
    refeshDealco: false,
    currentOrg: '',
    actOrg: '',
    beforeSaveOrgAction: false,

    commDropDown: {},

    commCdIds: [],
    resultList: [],
    resultListAll: [],
    resultListOrg: [],

    saveDataAdd: [],
    saveDataDel: [],

    searchParams: {},
}
