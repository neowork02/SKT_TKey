<template>
    <TCComDialog :dialogShow="activeOpen" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">게시판 수정</p>
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3_3">
                                <div class="arrayType">
                                    <div class="formitem div3">
                                        <TCComInput
                                            v-model="regPopUp.bbsTypeNm"
                                            labelName="게시판구분"
                                            :objAuth="objAuth"
                                            :disabled="true"
                                        ></TCComInput>
                                    </div>
                                    <div class="col0">
                                        <TCComCheckBox
                                            :objAuth="objAuth"
                                            v-model="formParam.noticeYn"
                                            :itemList="[
                                                {
                                                    commCdVal: 'Y',
                                                    commCdValNm: '',
                                                },
                                            ]"
                                        />
                                    </div>
                                    <div class="formitem div3">
                                        <div class="col0">
                                            <span class="basicTxt mgl-5">
                                                <span class="color-red"
                                                    >공지글</span
                                                >
                                                (체크하면 리스트 최상단에 나오게
                                                됩니다.)</span
                                            >
                                        </div>
                                    </div>

                                    <div class="col0">
                                        <TCComCheckBox
                                            :objAuth="objAuth"
                                            v-model="formParam.smsSendYn"
                                            :disabled="bfSmsSendYnDis"
                                            :itemList="[
                                                {
                                                    commCdVal: 'Y',
                                                    commCdValNm: '',
                                                },
                                            ]"
                                        />
                                    </div>
                                    <div class="formitem div3">
                                        <div class="col0">
                                            <span class="basicTxt mgl-5">
                                                <span class="color-red"
                                                    >문자전송</span
                                                >
                                                ({{ smsSendMsg }})</span
                                            >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <div class="arrayType">
                                    <!-- <div class="colTxtarea">
                                        <TCComTextArea
                                            v-model="formParam.dealcoNm"
                                            labelName="대상조직"
                                            class="boxtype"
                                            v-show="showStore"
                                            :eRequired="true"
                                            :disabled="true"
                                            :rows="5"
                                        />
                                    </div>
                                    <div class="col0 colbtn">
                                        <em>
                                            <TCComButton
                                                :Vuetify="false"
                                                eClass="btn_xs btn_ty05"
                                                @click="onStore"
                                                v-show="showStorebtn"
                                                labelName="선택"
                                            />
                                        </em>
                                    </div>
                                    <StorePopup
                                        v-if="showBbsStoreMgmt === true"
                                        :parentParam.sync="ckParam"
                                        ref="popup"
                                        :dialogShow.sync="showBbsStoreMgmt"
                                        @confirm="onStroeReturnData"
                                    /> -->
                                    <div class="formitem div3">
                                        <TCComInputSearchText
                                            v-model="regPopUp.orgNm"
                                            :codeVal.sync="regPopUp.orgCd"
                                            labelName=" 대상조직"
                                            placeholder="선택해주세요"
                                            :disabledAfter="true"
                                            :objAuth="objAuth"
                                            @enterKey="onAuthOrgTreeEnterKey"
                                            @appendIconClick="
                                                onAuthOrgTreeIconClick
                                            "
                                            @input="onAuthOrgTreeInput"
                                            :eRequired="true"
                                        />
                                        <BasBcoAuthOrgTreesPopup
                                            v-if="showBcoAuthOrgTrees"
                                            :parentParam="regPopUp"
                                            :rows="resultAuthOrgTreeRows"
                                            :dialogShow.sync="
                                                showBcoAuthOrgTrees
                                            "
                                            @confirm="onAuthOrgTreeReturnData"
                                        />
                                    </div>
                                    <div class="formitem div4">
                                        <TCComMultiComboBox
                                            labelName="권한그룹"
                                            v-model="ckParam.userGrpNm"
                                            :codeVal.sync="ckParam.userGrpCd"
                                            :itemList="userGrpNmList"
                                            :objAuth="objAuth"
                                            itemText="userGrpNm"
                                            itemValue="userGrpCd"
                                            label="미선택시 전체"
                                            @input="onIdClear"
                                        ></TCComMultiComboBox>
                                    </div>
                                    <div class="formitem div4">
                                        <TCComMultiComboBox
                                            labelName="정책그룹"
                                            v-model="ckParam.grpNm"
                                            :codeVal.sync="ckParam.grpNo"
                                            :objAuth="objAuth"
                                            :itemList="grpCdList"
                                            itemText="grpNm"
                                            itemValue="grpNo"
                                            label="미선택시 전체"
                                            @input="onIdClear"
                                        ></TCComMultiComboBox>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <div class="arrayType">
                                    <div class="colTxtarea">
                                        <TCComTextArea
                                            v-model="ckParam.userNm"
                                            labelName="대상아이디"
                                            class="boxtype"
                                            v-show="showUser"
                                            :disabled="true"
                                            :rows="4"
                                        />
                                    </div>
                                    <div class="col0 colbtn">
                                        <em>
                                            <TCComButton
                                                :Vuetify="false"
                                                eClass="btn_xs btn_ty05"
                                                @click="onUser"
                                                v-show="showUserbtn"
                                                labelName="선택"
                                            />
                                        </em>
                                        <em>
                                            <TCComButton
                                                :Vuetify="false"
                                                eClass="btn_xs btn_ty05"
                                                @click="allCheck"
                                                v-show="showAllUserbtn"
                                                labelName="전체"
                                            />
                                        </em>
                                    </div>
                                    <UserPopup
                                        v-if="showBbsUserMgmt === true"
                                        :parentParam="regPopUp"
                                        ref="popup"
                                        :dialogShow.sync="showBbsUserMgmt"
                                        @confirm="onUserReturnData"
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="regPopUp.textTitle"
                                    labelName="제목"
                                    :disabled="disableEl"
                                    :eRequired="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="regPopUp.bbsDtl"
                                    labelName="내용"
                                    class="boxtype"
                                    :rows="13"
                                    :disabled="disableEl"
                                    :eRequired="true"
                                />
                            </div>
                        </div>
                    </div>
                    <!-- 파일첨부 그리드 -->
                    <AttachedBoardFileAdd
                        gridId="modifyFileGrid"
                        ref="attachedFile"
                        :fileList="fileSearchList1"
                        @file-change="onFileAddChange1"
                        gridHeight="40px"
                    ></AttachedBoardFileAdd>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <div class="right">
                            <TCComButton
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onClick"
                                v-show="showUpdateBtn"
                                >저장</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="dtlClick"
                                v-show="showDeleteBtn"
                                >삭제</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onClose"
                                >목록</TCComButton
                            >
                        </div>
                    </div>

                    <!-- Close BTN(화면 우측 상단 X표시)-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

// 화면 하단 버튼 정렬
<style lang="scss" scoped>
// .btn_area_bottom::v-deep {
//     display: block;
//     float: none;
//     overflow: hidden;

//     .left {
//         float: left;
//     }

//     .right {
//         float: right;
//     }
// }
</style>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import _ from 'lodash'
import AttachedBoardFileAdd from '@/components/common/AttachedBoardFileAdd'
import BasBbsModifyApi from '@/api/biz/bas/bbs/basBbsMgmt'
//import StorePopup from '@/views/biz/bas/bbs/BasBbsStorePopMgmt'
import UserPopup from '@/views/biz/bas/bbs/BasBbsUserPopMgmt'
//import _ from 'lodash'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'

//====================//내부조직팝업(권한)팝업====================
//====================정책그룹====================
import polIctApi from '@/api/biz/bas/bbs/basBbsMgmt'
//====================//정책그룹====================
//====================권한그룹====================
import userGrpApi from '@/api/biz/bas/bbs/basBbsMgmt'
//====================//권한그룹====================

export default {
    name: 'BasBbsModify',
    mixins: [CommonMixin],
    components: { UserPopup, AttachedBoardFileAdd, BasBcoAuthOrgTreesPopup },
    props: {
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            checkbox: true,
            objAuth: {},
            showUpdateBtn: true,
            showDeleteBtn: true,
            disableEl: false,
            showBbsStoreMgmt: false,
            showBbsUserMgmt: false,
            showStorebtn: true,
            showUserbtn: true,
            showStore: true,
            showUser: true,
            showAllUserbtn: true,
            admAppendFileList: [],
            formData1: new FormData(),
            fileSearchList1: [],
            itemListAdmin: [
                {
                    value: 'D',
                    text: '도매(단가표)게시판',
                },
                {
                    value: 'S',
                    text: '소매게시판',
                },
                {
                    value: 'B',
                    text: '대형게시판',
                },
            ],
            inputValue2: '20',
            regPopUp: {
                noticeYn: '',
                smsSendYn: '',
                bfSmsSendYn: '',
                bbsTypeCd: '',
                bbsTypeNm: '',
                textTitle: '',
                bbsDtl: '',
                insUserId: '',
                dealcoNm: '', // 매장명
                dealcoCd: '', // 매장코드
                userNm: '', // 사용자명
                userId: '', // 사용자아이디
                screenId: 'BASBBS00001',
                docId: '',
                bbsNo: '',
                grpNo: '', //정책그룹
                grpNm: '', //정책그룹
                userGrpNm: '', //권한그룹
                userGrpCd: '', //권한그룹
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                delYn: '',
                __rowState: '',
            },
            ckParam: {
                userGrpNm: [],
                userGrpCd: [],
                grpNm: [],
                grpNo: [],
                userNm: '',
                userId: '',
            },
            formParam: {
                noticeYn: [],
                smsSendYn: [],
                dealcoCd: [],
                dealcoNm: [],
                userId: [],
                userNm: [],
            },
            searchParam: {
                deal_status_list: '', // 거래상태리스트
                sknDlvDealCoCd: '',
                dealcoGrpCd: '',
                acntNo: '',
                dealcoClCd1: '',
                dealcoClCd2: '',
                dealcoNm: '',
                dealcoCd: '',
                bizNo: '',
                sktChnlCd: '',
                accDealcoCd: '',
                repUserNm: '',
                searchGb: '',
                dtmFrom: '',
                dtmTo: '',
                catId: '',
                dealStatus: [],
                dealEndYn: '',
                lastMrtg: [],
                searchTarget: '',
                spClsBizClCd: '',
                maDirectYn: '',
                orgCd: '',
                orgLvl: '',
                srchValue: '',
            },
            userGrpNmList: [],
            grpCdList: [],
            //====================//공통기능==================
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부

            headerText: '',
            //====================//내부조직팝업(권한)팝업관련==================
            bfSmsSendYnDis: false,
            smsSendMsg: '체크시 대상아이디 문자전송',
        }
    },
    async mounted() {
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)
        // 정책그룹 호출
        await polIctApi.getCommCodeList(this.regPopUp).then((resultData) => {
            let groupArr = [
                /*{ grpNo: '', grpNm: '전체' }*/
            ] //정책그룹
            //this.regPopUp.commCdValNm = resultData[0].commCdValNm
            resultData.forEach((v) => {
                groupArr.push(v)
            })
            this.grpCdList = groupArr
        })

        // 권한그룹 호출
        await userGrpApi.getUserGrpList(this.regPopUp).then((result) => {
            let userGrpArr = [
                /*{ userGrpCd: '', userGrpNm: '전체' }*/
            ] //권한그룹

            result.forEach((v) => {
                userGrpArr.push(v)
            })
            this.userGrpNmList = userGrpArr
        })
        this.searchBoard()
        // console.log('grpNo', this.regPopUp.grpNo)
        // console.log('grpNm', this.regPopUp.grpNm)
        // console.log('userGrpCd', this.regPopUp.userGrpCd)
        // console.log('userGrpNm', this.regPopUp.userGrpNm)
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        /*
        userGrpCd: function () {
            return this.ckParam.userGrpNm
        },
        */
    },
    watch: {
        popupParams: {
            handler: function (value) {
                this.popupParams = value
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        /*
        userGrpCd(val) {
            alert(val)
        },
        */
    },
    methods: {
        onClose() {
            this.activeOpen = false
        },
        allCheck() {
            this.ckParam.userNm = '전체'
        },
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            let stLvl = this.orgInfo.orgLvl
            let lvlCd = ''
            for (let i = stLvl; i <= 3; i++) {
                if (i == 3) {
                    lvlCd += i + ''
                } else {
                    lvlCd += i + ','
                }
            }
            this.regPopUp.sLvlList = lvlCd
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.regPopUp)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.regPopUp.orgCd = _.get(res[0], 'orgCd')
                        this.regPopUp.orgNm = _.get(res[0], 'orgNm')
                        this.regPopUp.orgLevel = _.get(res[0], 'vLevel')
                        this.regPopUp.searchCoClOrgCd = _.get(
                            res[0],
                            'orgCdLvl0'
                        )
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            this.onIdClear()
            let stLvl = this.orgInfo.orgLvl

            let lvlCd = ''
            for (let i = stLvl; i <= 3; i++) {
                if (i == 3) {
                    lvlCd += i + ''
                } else {
                    lvlCd += i + ','
                }
            }

            this.regPopUp.sLvlList = lvlCd
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.regPopUp.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        onAuthOrgTreeEnterKey() {
            this.onIdClear()
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.regPopUp.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
                return false
            }

            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.regPopUp.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            this.regPopUp.orgCd = _.get(returnData, 'orgCd')
            this.regPopUp.orgNm = _.get(returnData, 'orgNm')
            this.regPopUp.orgLvl = _.get(returnData, 'orgLvl')
        },
        async onClick() {
            if (this.ckParam.userNm == '전체') {
                this.ckParam.userId = '-1'
            }

            this.regPopUp.noticeYn =
                String(this.formParam.noticeYn) == undefined
                    ? ''
                    : String(this.formParam.noticeYn)
            this.regPopUp.smsSendYn =
                String(this.formParam.smsSendYn) == undefined
                    ? ''
                    : String(this.formParam.smsSendYn)
            this.regPopUp.noticeYn =
                this.noticeYn == 'undefined' ? '' : this.regPopUp.noticeYn
            this.regPopUp.smsSendYn =
                this.regPopUp.smsSendYn == 'undefined'
                    ? ''
                    : this.regPopUp.smsSendYn
            this.regPopUp.dealcoNm =
                String(this.formParam.dealcoNm) == undefined
                    ? ''
                    : String(this.formParam.dealcoNm)
            this.regPopUp.dealcoCd =
                String(this.formParam.dealcoCd) == undefined
                    ? ''
                    : String(this.formParam.dealcoCd)
            this.regPopUp.userId =
                String(this.ckParam.userId) == undefined
                    ? ''
                    : String(this.ckParam.userId)
            this.regPopUp.userNm =
                String(this.ckParam.userNm) == undefined
                    ? ''
                    : String(this.ckParam.userNm)
            String(this.ckParam.userId) == 'undefined'
                ? ''
                : String(this.ckParam.userId)
            this.regPopUp.userNm =
                String(this.ckParam.userNm) == 'undefined'
                    ? ''
                    : String(this.ckParam.userNm)

            //##권한, 정책 셋팅
            let userGrpNm = String(this.ckParam.userGrpNm)
            if (!userGrpNm) {
                userGrpNm = ''
            } else {
                if (',' == userGrpNm.substring(0, 1)) {
                    userGrpNm = userGrpNm.substring(1, userGrpNm.length)
                }

                let spUserGrpNm = userGrpNm.split(',')

                if (5 < spUserGrpNm.length) {
                    this.showTcComAlert(
                        '권한그룹은 최대 5개까지 선택가능합니다. <br> 현재: ' +
                            spUserGrpNm.length +
                            ' 선택'
                    )
                    return
                }
            }

            let grpNm = String(this.ckParam.grpNm)
            if (!grpNm) {
                grpNm = ''
            } else {
                if (',' == grpNm.substring(0, 1)) {
                    grpNm = grpNm.substring(1, grpNm.length)
                }

                let spGrpNm = grpNm.split(',')

                if (5 < spGrpNm.length) {
                    this.showTcComAlert(
                        '정책그룹은 최대 5개까지 선택가능합니다. <br> 현재: ' +
                            spGrpNm.length +
                            ' 선택'
                    )
                    return
                }
            }

            if ('undefined' == userGrpNm) {
                userGrpNm = ''
            }
            if ('undefined' == grpNm) {
                grpNm = ''
            }

            this.regPopUp.userGrpNm = userGrpNm
            this.regPopUp.grpNm = grpNm

            /*
            if (this.regPopUp.bbsTypeCd == '대리점공지사항') {
                this.regPopUp.bbsTypeCd = 'N'
            } else
            */

            //alert(this.regPopUp.bbsTypeCd)
            /*
            if (this.regPopUp.bbsTypeCd == '도매') {
                this.regPopUp.bbsTypeCd = 'D'
            } else if (this.regPopUp.bbsTypeCd == '소매') {
                this.regPopUp.bbsTypeCd = 'S'
            } else if (this.regPopUp.bbsTypeCd == '대형') {
                this.regPopUp.bbsTypeCd = 'B'
            } else {
                this.regPopUp.bbsTypeCd = ''
            }
            */

            //alert(String(this.ckParam.userNm))
            //alert(String(this.regPopUp.smsSendYn))
            //alert(this.regPopUp.bfSmsSendYn)

            if (_.isEmpty(this.regPopUp.orgNm)) {
                this.showTcComAlert(' 대상조직을 입력해주세요', {
                    header: '필수 입력',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            if (_.isEmpty(this.regPopUp.textTitle)) {
                this.showTcComAlert('제목을 입력해주세요', {
                    header: '필수 입력',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            if (_.isEmpty(this.regPopUp.bbsDtl)) {
                this.showTcComAlert('내용을 입력해주세요', {
                    header: '필수 입력',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }

            let smsMsg = ''
            if (
                '전체' == String(this.ckParam.userNm) &&
                'Y' == String(this.regPopUp.smsSendYn) &&
                'Y' != this.regPopUp.bfSmsSendYn
            ) {
                smsMsg =
                    '대상아이디가 전체일때는 \n 문자전송이 되지 않습니다. \n'
            }
            //alert(smsMsg)
            //this.formParam = this.regPopUp
            //this.formParam = this.regPopUp.__rowState = 'updated'
            this.regPopUp.__rowState = 'updated'
            this.regPopUp.bbsNo = this.popupParams.bbsNo

            console.log(this.regPopUp.userGrpCd)

            await this.showTcComConfirm(smsMsg + '저장하시겠습니까?').then(
                (confirm) => {
                    if (confirm) {
                        //  첨부파일 저장
                        BasBbsModifyApi.saveAttachFile(this.formData1).then(
                            (resultData) => {
                                //this.showTcComAlert('저장되었습니다.')
                                if (resultData != null) {
                                    this.regPopUp.docId = resultData[0].docId
                                }

                                //  문의상세내용 저장
                                BasBbsModifyApi.getBasBbsUpdateMgmt(
                                    this.regPopUp
                                ).then((resultData) => {
                                    console.log(resultData)
                                    this.showTcComAlert('수정되었습니다.')
                                    this.$emit('confirm', true)
                                    this.onClose()
                                })
                            }
                        )
                    }
                }
            )
        },
        async dtlClick() {
            this.regPopUp.noticeYn = String(this.formParam.noticeYn)
            this.regPopUp.smsSendYn = String(this.formParam.smsSendYn)
            this.regPopUp.dealcoNm = String(this.formParam.dealcoNm)
            this.regPopUp.dealcoCd = String(this.formParam.dealcoCd)
            this.regPopUp.userId = String(this.ckParam.userId)
            this.regPopUp.userNm = String(this.ckParam.userNm)
            this.formParam = this.regPopUp
            this.formParam.__rowState = 'deleted'
            this.formParam.delYn = 'Y'
            this.formParam.bbsNo = this.popupParams.bbsNo
            await this.showTcComConfirm('삭제하시겠습니까?').then((confirm) => {
                if (confirm) {
                    BasBbsModifyApi.getBasBbsDeleteMgmt(this.formParam).then(
                        (resultData) => {
                            if (resultData != null) {
                                console.log('resultData', resultData)
                            }
                            this.showTcComAlert('삭제되었습니다.')
                            this.$emit('confirm', true)
                            this.onClose()
                        }
                    )
                }
            })
        },
        async searchBoard() {
            await BasBbsModifyApi.getBasBbsDetailMgmt(this.popupParams).then(
                (resultData) => {
                    console.log(resultData)
                    this.regPopUp.bbsTypeCd = resultData[0].bbsTypeCd
                    this.regPopUp.bbsNo = resultData[0].bbsNo
                    this.regPopUp.textTitle = resultData[0].textTitle
                    this.regPopUp.bbsDtl = resultData[0].bbsDtl
                    this.regPopUp.insUserId = resultData[0].insUserId
                    this.formParam.dealcoNm = resultData[0].dealcoNm
                    this.formParam.dealcoCd = resultData[0].dealcoCd
                    /*
                    this.ckParam.userNm = resultData[0].userNm
                    this.ckParam.userId = resultData[0].userId
                    */
                    this.regPopUp.userId = resultData[0].userId
                    this.regPopUp.orgCd = resultData[0].orgCd
                    this.regPopUp.orgNm = resultData[0].orgNm
                    this.regPopUp.grpNm = resultData[0].grpNo
                    this.regPopUp.bfSmsSendYn = resultData[0].bfSmsSendYn
                    this.regPopUp.orgLvl = resultData[0].orgLvl
                    //과거 SMS보낸이력이 있을경우 재수정불가
                    if ('Y' == this.regPopUp.bfSmsSendYn) {
                        this.bfSmsSendYnDis = true
                        this.smsSendMsg = '문자메세지 전송완료건. 재전송불가'
                    }

                    // this.regPopUp.grpNm = resultData[0].grpNm
                    //this.regPopUp.userGrpNm = resultData[0].userGrpCd
                    this.ckParam.userGrpNm = resultData[0].userGrpCd.split(',')
                    this.ckParam.grpNm = resultData[0].grpNo.split(',')

                    this.ckParam.userNm =
                        resultData[0].userNm !== null &&
                        resultData[0].userNm !== undefined
                            ? resultData[0].userNm.split(',')
                            : []

                    this.ckParam.userId =
                        resultData[0].userId !== null &&
                        resultData[0].userId !== undefined
                            ? resultData[0].userId.split(',')
                            : []

                    // this.regPopUp.userGrpCd = resultData[0].userGrpCd
                    // console.log('grpNo', this.regPopUp.grpNo)
                    // console.log('grpNm', this.regPopUp.grpNm)
                    // console.log('userGrpCd', this.regPopUp.userGrpCd)
                    // console.log('userGrpNm', this.regPopUp.userGrpNm)
                    if (_.isEmpty(this.ckParam.userNm)) {
                        this.ckParam.userNm = '전체'
                    }
                    this.regPopUp.docId = resultData[0].docId
                    if (resultData[0].noticeYn === 'Y') {
                        this.formParam.noticeYn = [resultData[0].noticeYn]
                    }

                    if (resultData[0].smsSendYn === 'Y') {
                        this.formParam.smsSendYn = [resultData[0].smsSendYn]
                    }
                    if (this.regPopUp.bbsTypeCd == 'N') {
                        //this.showStorebtn = false
                        this.showUserbtn = false
                        //this.showStore = false
                        this.showUser = false
                        this.showAllUserbtn = false
                    }
                    if (this.userInfo.userId != this.regPopUp.insUserId) {
                        this.showUpdateBtn = false
                        this.showDeleteBtn = false
                        this.disableEl = true
                        //this.showStorebtn = false
                        this.showUserbtn = false
                        this.showAllUserbtn = false
                    }
                    if (this.regPopUp.bbsTypeCd == 'N') {
                        this.regPopUp.bbsTypeNm = '대리점공지사항'
                    } else if (this.regPopUp.bbsTypeCd == 'D') {
                        this.regPopUp.bbsTypeNm = '도매'
                    } else if (this.regPopUp.bbsTypeCd == 'S') {
                        this.regPopUp.bbsTypeNm = '소매'
                    } else if (this.regPopUp.bbsTypeCd == 'B') {
                        this.regPopUp.bbsTypeNm = '대형'
                    }

                    BasBbsModifyApi.getAttachFile(this.regPopUp).then((res) => {
                        this.fileSearchList1 = []
                        res.forEach((item) => {
                            this.fileSearchList1.push({
                                screenId: item.screenId,
                                docId: item.docId,
                                name: item.fileNm,
                                size: item.fileSize,
                                filePathNm: item.filePathNm,
                                fileType: item.fileType,
                            })
                        })
                        this.$refs.attachedFile.init()
                    })
                }
            )
        },
        onFileAddChange1(files) {
            this.formData1 = new FormData()
            const addFileLength = files.addFile.length

            _.forEach(files.addFile, (item, index) => {
                this.formData1.append('files', item.file)
                this.formData1.append(
                    `admAppendFileList[${index}].fileNm`,
                    CommonUtil.getFileName(item.file.name)
                )
                this.formData1.append(
                    `admAppendFileList[${index}].fileType`,
                    CommonUtil.getExtensionName(item.file.name)
                )
                this.formData1.append(
                    `admAppendFileList[${index}].screenId`,
                    'BASBBS00001'
                )
                this.formData1.append(
                    `admAppendFileList[${index}].docId`,
                    this.regPopUp.docId === undefined ? '' : this.regPopUp.docId
                )
                this.formData1.append(
                    `admAppendFileList[${index}].__rowState`,
                    'created'
                )
            })
            _.forEach(files.delFile, (item, index) => {
                this.formData1.append(
                    `admAppendFileList[${index + addFileLength}].filePathNm`,
                    item.filePathNm
                )
                this.formData1.append(
                    `admAppendFileList[${index + addFileLength}].fileType`,
                    item.fileType
                )
                this.formData1.append(
                    `admAppendFileList[${index + addFileLength}].screenId`,
                    item.screenId
                )
                this.formData1.append(
                    `admAppendFileList[${index + addFileLength}].docId`,
                    item.docId
                )
                this.formData1.append(
                    `admAppendFileList[${index + addFileLength}].__rowState`,
                    'deleted'
                )
            })
        },
        chkData() {
            this.regPopUp = this.list
        },
        // async onStore() {

        //     this.showBbsStoreMgmt = true
        // },
        async onUser() {
            if (_.isEmpty(this.regPopUp.orgCd)) {
                this.showTcComAlert(' 대상조직을 입력해주세요', {
                    header: '필수 입력',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }

            //##권한, 정책 셋팅
            let userGrpNm = String(this.ckParam.userGrpNm)
            if (!userGrpNm) {
                userGrpNm = ''
            } else {
                if (',' == userGrpNm.substring(0, 1)) {
                    userGrpNm = userGrpNm.substring(1, userGrpNm.length)
                }

                let spUserGrpNm = userGrpNm.split(',')

                if (5 < spUserGrpNm.length) {
                    this.showTcComAlert(
                        '권한그룹은 최대 5개까지 선택가능합니다. 현재:' +
                            spUserGrpNm.length
                    )
                    return
                }
            }

            let grpNm = String(this.ckParam.grpNm)
            if (!grpNm) {
                grpNm = ''
            } else {
                if (',' == grpNm.substring(0, 1)) {
                    grpNm = grpNm.substring(1, grpNm.length)
                }

                let spGrpNm = grpNm.split(',')

                if (5 < spGrpNm.length) {
                    this.showTcComAlert(
                        '정책그룹은 최대 5개까지 선택가능합니다. 현재:' +
                            spGrpNm.length
                    )
                    return
                }
            }

            // if (_.isEmpty(this.regPopUp.userGrpNm)) {
            //     this.showTcComAlert('권한그룹을 입력해주세요', {
            //         header: '필수 입력',
            //         size: '500',
            //         confirmLabel: 'OK',
            //     })
            //     return
            // }
            console.log('userNm', this.ckParam.userNm)
            console.log('userId', this.ckParam.userId)

            if ('undefined' == userGrpNm) {
                userGrpNm = ''
            }
            if ('undefined' == grpNm) {
                grpNm = ''
            }

            this.regPopUp.userGrpNm = userGrpNm
            this.regPopUp.grpNm = grpNm

            this.showBbsUserMgmt = true
        },
        onStroeReturnData(retrunData) {
            var rowData = []
            var rowData1 = []
            if (retrunData.length) {
                for (let i = 0; i < retrunData.length; i++) {
                    rowData[i] = retrunData[i].dealcoNm
                    rowData1[i] = retrunData[i].dealcoCd
                    //console.log('::::::::::', rowData)
                    this.formParam.dealcoNm = rowData
                    this.formParam.dealcoCd = rowData1
                }
            }
        },
        onUserReturnData(retrunData) {
            var rowData = []
            var rowData1 = []
            if (retrunData.length) {
                for (let i = 0; i < retrunData.length; i++) {
                    rowData[i] = retrunData[i].userNm
                    rowData1[i] = retrunData[i].userId
                    this.ckParam.userNm = rowData
                    this.ckParam.userId = rowData1
                }
            }
        },
        onIdClear() {
            let eType = event.type ?? ''

            if ('click' == eType) {
                this.ckParam.userNm = ['전체']
                this.ckParam.userId = ['-1']
            }
        },
    },
}
</script>
