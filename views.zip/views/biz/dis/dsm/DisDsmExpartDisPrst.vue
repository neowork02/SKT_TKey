<!-----------------------------------------------
 * 업무그룹명: 교품재고관리
 * 서브업무명: 교품재고현황
 * 설명: 교품재고현황을 조회한다.
 * 작성자: P179890
 * 작성일: 2022.04.18
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>교품 재고 현황</h1>
        <!-- // Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left"></li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="조회기간"
                        :eRequired="true"
                        :calType="calType"
                        v-model="setDate"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        @enterKey="onAuthOrgTreeIconClick"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :objAuth="this.objAuth"
                        :eRequired="true"
                        v-model="reqParam.orgNm"
                        :codeVal="reqParam.orgId"
                        :disabledAfter="true"
                        :disabled="searchDisable"
                    >
                    </TCComInputSearchText>
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="reqParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="보유처"
                        @enterKey="onDealcoIconClick"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                        :objAuth="this.objAuth"
                        v-model="reqParam.outPlcNm"
                        :codeVal="reqParam.outPlcId"
                        :disabledAfter="true"
                        :disabled="searchDisable"
                    >
                    </TCComInputSearchText>
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchDealcoParam"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="제조사"
                        @enterKey="onOutDealIconClick"
                        @appendIconClick="onOutDealIconClick"
                        @input="onOutDealcoInput"
                        :objAuth="this.objAuth"
                        v-model="reqParam.mfactNm"
                        :codeVal="reqParam.mfactId"
                        :disabledAfter="true"
                    >
                    </TCComInputSearchText>
                    <BasBcoOutDealsPopup
                        v-if="showBcoOutDeals"
                        :parentParam="searchOutDealParam"
                        :rows="resultOutDealRows"
                        :dialogShow.sync="showBcoOutDeals"
                        @confirm="onOutDealReturnData"
                    />
                </div>
                <!-- //item 1-4 -->
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00010"
                        labelName="상품구분"
                        :objAuth="this.objAuth"
                        v-model="reqParam.prodCl"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00090"
                        labelName="불량구분"
                        :objAuth="this.objAuth"
                        v-model="reqParam.badYn"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                        :filterFunc="filterBadYn"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-2 -->
                <!-- item 2-3 -->
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="출고여부"
                        v-model="reqParam.outYn"
                        :objAuth="this.objAuth"
                        :itemList="outYnItems"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-3 -->
                <!-- item 2-4 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00100"
                        labelName="재고상태"
                        :objAuth="this.objAuth"
                        v-model="reqParam.disSt"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-4 -->
            </div>
            <!-- //Search_line 2 -->
            <template>
                <div class="btn_def">
                    <v-btn
                        plain
                        class="btn_ty_exp"
                        v-bind:class="{
                            ' btn_ty_exp_active ': active,
                        }"
                        @click="active = !active"
                    >
                    </v-btn>
                </div>
            </template>
            <v-expand-transition>
                <div class="toggleWrap" v-show="active">
                    <!-- Search_line 3 -->
                    <div class="searchform">
                        <!-- item 3-1 -->
                        <div class="formitem div4">
                            <TCComInputSearchText
                                labelName="모델"
                                @enterKey="onProdsIconClick"
                                @appendIconClick="onProdsIconClick"
                                @input="reqParam.prodCd = ''"
                                :objAuth="this.objAuth"
                                v-model="reqParam.prodNm"
                                :codeVal="reqParam.prodCd"
                                :disabledAfter="true"
                            >
                            </TCComInputSearchText>
                            <BasBcoProdsPopup
                                v-if="basBcoProdsShow === true"
                                :dialogShow.sync="basBcoProdsShow"
                                :parentParam="searchProdForm"
                                :rows="resultProdsRows"
                                @confirm="onProdsReturnData"
                            />
                        </div>
                        <!-- //item 3-1 -->
                        <!-- item 3-2 -->
                        <div class="formitem div4">
                            <TCComInput
                                labelName="일련번호"
                                :appendIconShow="false"
                                :appendIconClass="''"
                                :codeIDView="false"
                                :objAuth="this.objAuth"
                                v-model="reqParam.serNum"
                            >
                            </TCComInput>
                        </div>
                        <!-- //item 3-2 -->
                        <div class="formitem div2"></div>
                    </div>
                    <!-- //Search_line 3 -->
                </div>
            </v-expand-transition>
        </div>
        <!-- //Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="교품 재고 현황"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="this.exportGridBtn"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDisDsmExpartDisPrsts"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
        <!-- //gridWrap -->
    </div>
</template>

<!--style scoped>
</style-->
<script>
import { DisDsmExpartDisPrst_GRID_HEADER } from '@/const/grid/dis/dsm/disDsmExpartDisPrstHeader.js'
import restApi from '@/api/biz/dis/dsm/disDsmExpartDisPrst.js'
import attachedFileApi from '@/api/common/attachedFile'
import { CommonGrid, CommonUtil, CommonMsg } from '@/utils'
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//====================//외부거래처(제조사,매입처,배송사 등) 팝업====================
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================
//====================내부거래처(권한조직)====================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처(권한조직)==================

export default {
    name: 'DisDsmExpartDisPrst',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoOutDealsPopup,
        BasBcoProdsPopup,
        BasBcoDealcosPopup,
    },
    data() {
        return {
            //====================내부조직팝업(권한)팝업====================
            authOrgParam: {},
            showBcoAuthOrgTrees: false,
            resultAuthOrgTreeRows: [],
            //====================//내부조직팝업(권한)팝업====================
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '2X', // 거래처그룹
                dealcoClCd1: '20', // 거래처구분
            },
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            resultProdsRows: [],
            searchProdForm: {
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
                prodClCd: '', //상품구분
                sktOperYn: '', //skt운영여부
                useYn: '', //사용여부
            },
            //====================//상품팝업관련==================
            //====================내부거래처(권한 조직))====================
            basBcoDealcoShow: false,
            searchDealcoParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY',
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC',
            },
            resultDealcoRows: [],
            //====================//내부거래처(권한 조직)==================
            searchDisable: false,
            active: false,
            alertHeadTxt: '교품재고현황',
            alertBodyTxt: '',
            view: DisDsmExpartDisPrst_GRID_HEADER,
            gridData: {},
            calType: 'DP',
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            searchForms: {},
            indicatorOpt: { sort: 'ASC' },
            excelParam: {},
            gridStyle: {
                height: '350px', //그리드 높이 조절
            },
            rowCnt: 15,
            reqParam: {
                // 요청파라미터
                fromDt: '', // 시작 조회일자
                toDt: '', // 종료 조회일자
                orgId: '', // 조직코드
                orgNm: '', // 조직명
                orgLevel: '', // 조직레벨
                orgCdLvl0: '', //레벨0조직코드
                outPlcId: '', // 보유처(출고처)
                outPlcNm: '', // 보유처명(출고처)
                mfactNm: '', // 제조사명
                mfactId: '', // 제조사
                prodCd: '', // 모델코드
                prodNm: '', // 모델코드
                serNum: '', // 일련번호
                prodCl: '', // 상품구분
                outYn: '', // 출고여부
                badYn: '', // 불량구분
                disSt: '', // 재고상태
                supOrg: '',
            },
            outYnItems: [
                // 출고여부
                { commCdValNm: '전체', commCdVal: '' },
                { commCdValNm: 'Y', commCdVal: 'Y' },
                { commCdValNm: 'N', commCdVal: 'N' },
            ],
        }
    },
    watch: {},
    computed: {
        setDate: {
            get() {
                return [this.reqParam.fromDt, this.reqParam.toDt]
            },
            set(val) {
                this.reqParam.fromDt = val[0]
                this.reqParam.toDt = val[1]
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.reqParam.basMth = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchDealcoParam.basDay = CommonUtil.onlyNumber(
                    val[1]
                ).substr(0, 8)
                return val
            },
        },
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(true)
        this.init()
    },
    methods: {
        init() {
            //검색영역
            this.reqParam.fromDt = moment(new Date()).format('YYYY-MM-01') // 조회시작일
            this.reqParam.toDt = moment(new Date()).format('YYYY-MM-DD') // 조회종료일
            // 세션정보 set
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['outPlcId'] = this.userInfo['dealcoCd']
                this.reqParam['outPlcNm'] = this.userInfo['dealcoNm']
                this.reqParam['orgId'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLevel'] = this.orgInfo['orgLvl']
                this.reqParam['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.searchDisable = true
            } else {
                this.searchDisable = false
            }
            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
            this.gridData.totalPage = 0
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        //Grid ExcelDown
        exportGridBtn: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }

            this.excelParam = { ...this.reqParam }
            this.excelParam.fromDt = CommonUtil.onlyNumber(
                this.excelParam.fromDt
            )
            this.excelParam.toDt = CommonUtil.onlyNumber(this.excelParam.toDt)

            if (this.excelParam.orgLevel == '0') {
                this.excelParam.orgId = ''
            }
            if (this.excelParam.orgLevel == '1') {
                this.excelParam.supOrg = this.excelParam.orgId
                this.excelParam.orgId = ''
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dsm/disDsmExpartDisPrstExcels',
                this.excelParam
            )
        },
        //조회 버튼 이벤트
        searchBtn: function () {
            if (!this.isValidChk()) {
                return false
            }
            //첫 조회시 표시할 행의 갯수
            this.searchForms = { ...this.reqParam }
            this.searchForms.pageSize = this.rowCnt
            this.searchForms.pageNum = 1 //첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.searchForms.fromDt = CommonUtil.onlyNumber(
                this.searchForms.fromDt
            )
            this.searchForms.toDt = CommonUtil.onlyNumber(this.searchForms.toDt)

            if (this.searchForms.orgLevel == '0') {
                this.searchForms.orgId = ''
            }
            if (this.searchForms.orgLevel == '1') {
                this.searchForms.supOrg = this.searchForms.orgId
                this.searchForms.orgId = ''
            }
            this.getDisDsmExpartDisPrsts(this.searchForms.pageNum)
        },
        getDisDsmExpartDisPrsts(page) {
            this.searchForms.pageNum = page
            //교품 재고 현황 리스트 조회
            restApi.getDisDsmExpartDisPrsts(this.searchForms).then((res) => {
                this.gridObj.setRows(res.gridList)
                this.gridObj.setGridIndicator(res.pagingDto, this.indicatorOpt) //순번이 필요한경우 계산하는 함수
                this.gridData = this.gridSetData() //초기화
                this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수

                //Grid Row 가져올때 총건수 Setting
                this.gridHeaderObj.setPageCount(res.pagingDto)
            })
        },
        clearPage() {
            // CommonUtil 페이지 초기화 함수
            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            this.init()
        },
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        isValidChk() {
            // validation 체크
            if (_.isEmpty(this.reqParam.fromDt)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '조회시작일'))
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.fromDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }

            if (_.isEmpty(this.reqParam.toDt)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '조회종료일'))
                return false
            }

            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.toDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }

            if (
                this.reqParam.fromDt.substr(0, 7) !==
                this.reqParam.toDt.substr(0, 7)
            ) {
                this.openAlert('시작일자와 종료일자을 동일한 월로 지정하세요.')
                return false
            }

            if (
                this.reqParam.fromDt.replaceAll('-', '') >
                this.reqParam.toDt.replaceAll('-', '')
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_01026'))
                return false
            }
            if (_.isEmpty(this.reqParam.orgId)) {
                this.openAlert(CommonMsg.getMessage('MSG_00121', '조직;조회'))
                return false
            }
            return true
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        // 불량구분comboBox filter
        filterBadYn(items) {
            return items.filter(
                (item) =>
                    item['commCdVal'] === '01' || item['commCdVal'] === '02'
            )
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.authOrgParam)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.orgId = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLevel = _.get(res[0], 'orgLvl')
                        this.reqParam.orgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            this.authOrgParam['orgNm'] = this.reqParam['orgNm']
            this.authOrgParam['orgCd'] = this.reqParam['orgId']
            this.authOrgParam['orgLvl'] = this.reqParam['orgLevel']
            if (!_.isEmpty(this.reqParam.orgNm)) {
                // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
                this.getAuthOrgTreeList()
            } else {
                // 그 이외는 내부조직팝업(권한) 팝업 오픈
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            if (
                !_.isEmpty(this.reqParam.orgId) &&
                this.reqParam.orgId != returnData.orgCd
            ) {
                this.reqParam.outPlcId = ''
                this.reqParam.outPlcNm = ''
            }
            this.reqParam.orgId = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.orgLevel = _.get(returnData, 'orgLvl')
            this.reqParam.orgCdLvl0 = _.get(returnData, 'orgCdLvl0')
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            // 보유처 초기화
            this.reqParam.orgId = ''
            this.reqParam.orgLevel = ''
            this.reqParam.orgCdLvl0 = ''
            this.reqParam.outPlcId = ''
            this.reqParam.outPlcNm = ''
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.mfactId = _.get(res[0], 'dealcoCd')
                        this.reqParam.mfactNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        // 외부거래처 TextField 돋보기 Icon 이벤트 처리
        onOutDealIconClick() {
            this.searchOutDealParam['dealcoCd'] = this.reqParam['mfactId']
            this.searchOutDealParam['dealcoNm'] = this.reqParam['mfactNm']
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            if (!_.isEmpty(this.reqParam.mfactNm)) {
                // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
                this.getOutDealList()
            } else {
                // 그 이외는 외부거래처 팝업 오픈
                this.showBcoOutDeals = true
            }
        },
        // 외부거래처 TextField 엔터키 이벤트 처리
        onOutDealEnterKey() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.mfactNm)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '제조사'))
                return
            }
            this.searchOutDealParam['dealcoCd'] = this.reqParam['mfactId']
            this.searchOutDealParam['dealcoNm'] = this.reqParam['mfactNm']
            // 외부거래처 정보 조회
            this.getOutDealList()
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(returnData) {
            this.reqParam.mfactId = _.get(returnData, 'dealcoCd')
            this.reqParam.mfactNm = _.get(returnData, 'dealcoNm')
        },
        onOutDealcoInput() {
            this.reqParam.mfactId = ''
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                if (res.length === 1) {
                    this.reqParam.prodCd = _.get(res[0], 'prodCd')
                    this.reqParam.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            this.searchProdForm['prodCd'] = this.reqParam['prodCd']
            this.searchProdForm['prodNm'] = this.reqParam['prodNm']
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.reqParam.prodNm)) {
                this.getProdsList()
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(returnData) {
            this.reqParam.prodCd = _.get(returnData, 'prodCd')
            this.reqParam.prodNm = _.get(returnData, 'prodNm')
        },
        //===================== //상품팝업관련 methods ================================
        //===================== 내부거래처(권한조직)) methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcoParam)
                .then((res) => {
                    if (res.length === 1) {
                        // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                        this.reqParam.outPlcId = _.get(res[0], 'dealcoCd')
                        this.reqParam.outPlcNm = _.get(res[0], 'dealcoNm')
                    } else {
                        // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        // 내부거래처(권한조직) TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            if (_.isEmpty(this.reqParam.orgId)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                return
            }
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.searchDealcoParam['orgCd'] = this.reqParam['orgId']
            this.searchDealcoParam['orgNm'] = this.reqParam['orgNm']
            this.searchDealcoParam['orgLvl'] = this.reqParam['orgLevel']
            this.searchDealcoParam['dealcoCd'] = this.reqParam['outPlcId']
            this.searchDealcoParam['dealcoNm'] = this.reqParam['outPlcNm']

            if (!_.isEmpty(this.reqParam['outPlcNm'])) {
                // 내부거래처조회
                this.getDealcosList()
            } else {
                // 팝업오픈
                this.basBcoDealcoShow = true
            }
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.reqParam.outPlcId = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            this.reqParam.outPlcId = _.get(returnData, 'dealcoCd')
            this.reqParam.outPlcNm = _.get(returnData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================
    },
}
</script>
