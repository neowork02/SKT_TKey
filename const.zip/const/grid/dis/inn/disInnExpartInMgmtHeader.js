import { ValueType } from 'realgrid'

export const DisInnExpartInMgmtGRID_HEADER = {
    fields: [
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inSchdDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'inClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inFixStatus',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inFixQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inClCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
            width: '380',
        },
        {
            name: 'prchsDealcoNm',
            fieldName: 'prchsDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매입처',
                showTooltip: false,
            },
            width: '170',
        },
        {
            name: 'inDealSktCd',
            fieldName: 'inDealSktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            width: '130',
        },
        {
            name: 'inDealcoCd',
            fieldName: 'inDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처',
                showTooltip: false,
            },
            width: '170',
        },
        {
            name: 'inSchdDt',
            fieldName: 'inSchdDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                datetimeFormat: 'yyyy-MM-dd',
            },
            width: '120',
        },
        {
            name: 'inClNm',
            fieldName: 'inClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고구분',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inFixStatus',
            fieldName: 'inFixStatus',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고상태',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inQty',
            fieldName: 'inQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고수량',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inFixQty',
            fieldName: 'inFixQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '확정수량',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inMgmtNo',
            fieldName: 'inMgmtNo',
            visible: false,
            type: 'data',
        },
        {
            name: 'inClCd',
            fieldName: 'inClCd',
            visible: false,
            type: 'data',
        },
    ],
}
